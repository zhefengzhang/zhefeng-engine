#pragma once

#include <EffekseerRenderer.RenderStateBase.h>

namespace cce {

class RenderState : public EffekseerRenderer::RenderStateBase {
public:
    RenderState();
    ~RenderState();
    void Update(bool forced);
};

}