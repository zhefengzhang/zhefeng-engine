
#pragma once

#include <Effekseer.h>
#include <Effekseer/Model/ProceduralModelGenerator.h>
#include <Effekseer/Material/Effekseer.MaterialFile.h>
#include <EffekseerRendererCommon/EffekseerRenderer.CommonUtils.h>

#if CC_EFFEKSSER_IMPORTOR
#include <EffekseerMaterialCompiler/OpenGL/EffekseerMaterialCompilerGL.h>
#endif

#include <EffekseerRenderer.Renderer.h>
#include <EffekseerRenderer.ModelRendererBase.h>
#include <EffekseerRenderer.StandardRenderer.h>

#include <functional>
#include <map>
#include <string>

namespace cce {
std::string&    UTF16ToUTF8(std::u16string src);
std::u16string& UTF8ToUTF16(std::string src);
}
