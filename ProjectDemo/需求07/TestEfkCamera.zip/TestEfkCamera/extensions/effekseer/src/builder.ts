import { BuildPlugin } from "../@types/packages/builder/@types";

export function load() {

}

export function unload() {

}

export const configs: BuildPlugin.Configs = {
    '*': {
        hooks: './hooks',
        options: {}
    },
};