System.register(["__unresolved_0", "cc", "__unresolved_1", "cc/env"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, Asset, ModelRenderer, Node, Texture2D, Prefab, EFKRender, EDITOR, _dec, _dec2, _dec3, _dec4, _dec5, _dec6, _dec7, _dec8, _dec9, _dec10, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _descriptor5, _descriptor6, _descriptor7, _crd, ccclass, property, executeInEditMode, EFKComponent;

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'transform-class-properties is enabled and runs after the decorators transform.'); }

  function _reportPossibleCrUseOfEFKRender(extras) {
    _reporterNs.report("EFKRender", "./efk_render", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
      Asset = _cc.Asset;
      ModelRenderer = _cc.ModelRenderer;
      Node = _cc.Node;
      Texture2D = _cc.Texture2D;
      Prefab = _cc.Prefab;
    }, function (_unresolved_2) {
      EFKRender = _unresolved_2.EFKRender;
    }, function (_ccEnv) {
      EDITOR = _ccEnv.EDITOR;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "1d189MYptBN74HAnWl02Xv/", "efk_component", undefined);

      __checkObsolete__(['_decorator', 'Asset', 'ModelRenderer', 'renderer', 'Node', 'Texture2D', 'Prefab']);

      ({
        ccclass,
        property,
        executeInEditMode
      } = _decorator);

      _export("EFKComponent", EFKComponent = (_dec = ccclass('EFKComponent'), _dec2 = property({
        type: Asset,
        serializable: true
      }), _dec3 = property({
        type: Asset,
        readonly: false
      }), _dec4 = property({
        type: Asset,
        readonly: false
      }), _dec5 = property({
        type: [Texture2D],
        readonly: false
      }), _dec6 = property({
        type: Asset,
        readonly: false
      }), _dec7 = property({
        type: Prefab,
        readonly: false
      }), _dec8 = property({
        tooltip: '播放結束後, 自動銷毀該節點'
      }), _dec9 = property({
        tooltip: '是否重複播放 efk 特效'
      }), _dec10 = property({
        serializable: true
      }), _dec(_class = executeInEditMode(_class = (_class2 = class EFKComponent extends ModelRenderer {
        constructor() {
          super(...arguments);

          _initializerDefineProperty(this, "_efk", _descriptor, this);

          _initializerDefineProperty(this, "efkModels", _descriptor2, this);

          _initializerDefineProperty(this, "efkTextures", _descriptor3, this);

          _initializerDefineProperty(this, "efkMats", _descriptor4, this);

          _initializerDefineProperty(this, "efkConfig", _descriptor5, this);

          _initializerDefineProperty(this, "autoDestroy", _descriptor6, this);

          _initializerDefineProperty(this, "_repeat", _descriptor7, this);

          this._frameCount = 0;
        }

        set efk(efk) {
          this._efk = efk;
          this.onChange();
        }

        get efk() {
          return this._efk;
        }

        set efkRepeat(b) {
          this.setRpeat(b);
        }

        get efkRepeat() {
          return this._repeat;
        }

        play() {
          this._frameCount = (_crd && EFKRender === void 0 ? (_reportPossibleCrUseOfEFKRender({
            error: Error()
          }), EFKRender) : EFKRender).play(this);
          (_crd && EFKRender === void 0 ? (_reportPossibleCrUseOfEFKRender({
            error: Error()
          }), EFKRender) : EFKRender).setWorldMatrix(this);
        }

        setSpeed(v) {
          (_crd && EFKRender === void 0 ? (_reportPossibleCrUseOfEFKRender({
            error: Error()
          }), EFKRender) : EFKRender).setSpeed(this, v);
        }

        setPause(b) {
          (_crd && EFKRender === void 0 ? (_reportPossibleCrUseOfEFKRender({
            error: Error()
          }), EFKRender) : EFKRender).setPause(this, b);
        }

        setRpeat(b) {
          this._repeat = b;

          if (EDITOR && b) {
            this.play();
          }
        }

        stop() {
          (_crd && EFKRender === void 0 ? (_reportPossibleCrUseOfEFKRender({
            error: Error()
          }), EFKRender) : EFKRender).stop(this);
        }

        getFrameCount() {
          return this._frameCount;
        }

        setFramePosition(n) {
          (_crd && EFKRender === void 0 ? (_reportPossibleCrUseOfEFKRender({
            error: Error()
          }), EFKRender) : EFKRender).setFrame(this, n);
        }

        update() {
          (_crd && EFKRender === void 0 ? (_reportPossibleCrUseOfEFKRender({
            error: Error()
          }), EFKRender) : EFKRender).setWorldMatrix(this);

          this._detachFromScene();
        }

        onRestore() {
          if (this.enabledInHierarchy) {
            this._attachToScene();
          }
        }

        onRemovingCallback() {
          this.scheduleOnce(() => {
            if (this._repeat) {
              this.play();
            } else {
              this.node.emit('efk_remove');
            }
          });
        }

        onChange() {
          if (this.node.active && this.enabled) {
            this._frameCount = (_crd && EFKRender === void 0 ? (_reportPossibleCrUseOfEFKRender({
              error: Error()
            }), EFKRender) : EFKRender).play(this);
            (_crd && EFKRender === void 0 ? (_reportPossibleCrUseOfEFKRender({
              error: Error()
            }), EFKRender) : EFKRender).setWorldMatrix(this);
          }
        }

        onLoad() {
          (_crd && EFKRender === void 0 ? (_reportPossibleCrUseOfEFKRender({
            error: Error()
          }), EFKRender) : EFKRender).load(this);

          if (!EDITOR) {
            if (this.autoDestroy === true) {
              this.node.once('efk_remove', () => this.node.destroy());
            }
          }
        }

        onEnable() {
          this._frameCount = (_crd && EFKRender === void 0 ? (_reportPossibleCrUseOfEFKRender({
            error: Error()
          }), EFKRender) : EFKRender).play(this);
          (_crd && EFKRender === void 0 ? (_reportPossibleCrUseOfEFKRender({
            error: Error()
          }), EFKRender) : EFKRender).setWorldMatrix(this);
          this.node.on(Node.EventType.TRANSFORM_CHANGED, this._updateEfkWorldMatrix, this);

          this._attachToScene();
        }

        onDisable() {
          (_crd && EFKRender === void 0 ? (_reportPossibleCrUseOfEFKRender({
            error: Error()
          }), EFKRender) : EFKRender).stop(this);
          this.node.off(Node.EventType.TRANSFORM_CHANGED, this._updateEfkWorldMatrix, this);

          this._detachFromScene();
        }

        onDestroy() {
          (_crd && EFKRender === void 0 ? (_reportPossibleCrUseOfEFKRender({
            error: Error()
          }), EFKRender) : EFKRender).unload(this.efk.name);

          this._detachFromScene();
        }

        _updateEfkWorldMatrix() {
          (_crd && EFKRender === void 0 ? (_reportPossibleCrUseOfEFKRender({
            error: Error()
          }), EFKRender) : EFKRender).setWorldMatrix(this);
        }

        _addModel(model) {
          if (!model) return;
          model.node = model.transform = this.node;
          model.visFlags = this.visibility;

          this._models.push(model);

          var renderScene = this._getRenderScene();

          renderScene.addModel(model);
        }

        _attachToScene() {// const renderScene = this._getRenderScene();
          // this._models.forEach((model) => {
          //     renderScene.addModel(model);
          // });
        }

        _detachFromScene() {
          var renderScene = this._getRenderScene();

          this._models.forEach(model => {
            renderScene.removeModel(model);
          });

          this._models.length = 0;
        }

      }, (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "_efk", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _applyDecoratedDescriptor(_class2.prototype, "efk", [_dec3], Object.getOwnPropertyDescriptor(_class2.prototype, "efk"), _class2.prototype), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "efkModels", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return [];
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "efkTextures", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return [];
        }
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "efkMats", [_dec6], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return [];
        }
      }), _descriptor5 = _applyDecoratedDescriptor(_class2.prototype, "efkConfig", [_dec7], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor6 = _applyDecoratedDescriptor(_class2.prototype, "autoDestroy", [_dec8], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return false;
        }
      }), _applyDecoratedDescriptor(_class2.prototype, "efkRepeat", [_dec9], Object.getOwnPropertyDescriptor(_class2.prototype, "efkRepeat"), _class2.prototype), _descriptor7 = _applyDecoratedDescriptor(_class2.prototype, "_repeat", [_dec10], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return false;
        }
      })), _class2)) || _class) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=8a8f367011b8edf51653febd1601df836f5f983a.js.map