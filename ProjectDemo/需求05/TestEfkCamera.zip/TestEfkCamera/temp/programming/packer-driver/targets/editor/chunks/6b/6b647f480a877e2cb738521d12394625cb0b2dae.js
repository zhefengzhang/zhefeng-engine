System.register(["__unresolved_0", "cc", "__unresolved_1"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, Component, Asset, Material, EFKRender, _dec, _dec2, _dec3, _dec4, _class, _class2, _descriptor, _descriptor2, _descriptor3, _crd, ccclass, property, executeInEditMode, EFKConfig;

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'transform-class-properties is enabled and runs after the decorators transform.'); }

  function _reportPossibleCrUseOfEFKRender(extras) {
    _reporterNs.report("EFKRender", "./efk_render", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      Asset = _cc.Asset;
      Material = _cc.Material;
    }, function (_unresolved_2) {
      EFKRender = _unresolved_2.EFKRender;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "ed1490AFYpEyooyp9qX4doU", "efk_config", undefined);

      __checkObsolete__(['_decorator', 'director', 'Component', 'Asset', 'Material', 'Director']);

      ({
        ccclass,
        property,
        executeInEditMode
      } = _decorator);

      _export("EFKConfig", EFKConfig = (_dec = ccclass('EFKConfig'), _dec2 = property({
        type: [Material],
        readonly: false
      }), _dec3 = property({
        type: [Material],
        readonly: false
      }), _dec4 = property({
        type: Asset,
        readonly: false
      }), _dec(_class = executeInEditMode(_class = (_class2 = class EFKConfig extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "spriteMats", _descriptor, this);

          _initializerDefineProperty(this, "modelMats", _descriptor2, this);

          _initializerDefineProperty(this, "wasm", _descriptor3, this);
        }

        // constructor() {
        //     super();
        //     director.once(Director.EVENT_BEFORE_SCENE_LAUNCH, () => {
        //         EFKRender.setup(this.spriteMats.concat(this.modelMats), 0.2);
        //     });
        // }
        onLoad() {
          if ((_crd && EFKRender === void 0 ? (_reportPossibleCrUseOfEFKRender({
            error: Error()
          }), EFKRender) : EFKRender).isInit() === true) return; // efk 基礎資源不做釋放

          let wasm = this.wasm;
          let defaultMtls = this.spriteMats.concat(this.modelMats);
          defaultMtls.forEach(mtl => mtl.addRef());
          wasm.addRef();
          (_crd && EFKRender === void 0 ? (_reportPossibleCrUseOfEFKRender({
            error: Error()
          }), EFKRender) : EFKRender).setup(defaultMtls, 0.2);
        }

      }, (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "spriteMats", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return [null, null, null, null, null, null];
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "modelMats", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return [null, null, null, null, null, null];
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "wasm", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      })), _class2)) || _class) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=6b647f480a877e2cb738521d12394625cb0b2dae.js.map