System.register(["__unresolved_0", "cc", "__unresolved_1", "cc/env", "__unresolved_2"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, Material, director, Director, EFKModel, EDITOR, NATIVE, EFKMaterial, _crd, FORCE_NATIVE, g_isUnloadImmediately, g_isInit, g_isClearMask, g_stepmode, g_cameras, g_effects, g_textures, g_textures_refs, g_materials, g_materials_refs, g_effects_loader, g_effects_refs, g_models_refs, g_tex_slot, g_material_slot, g_model_slot, g_component, g_magnification, EFKRender;

  function hash(str) {
    if (Array.prototype.reduce) {
      return Math.abs(str.split("").reduce(function (a, b) {
        a = (a << 5) - a + b.charCodeAt(0);
        return a & a;
      }, 0));
    }

    var hash = 0;
    if (str.length === 0) return hash;

    for (var i = 0; i < str.length; i++) {
      var character = str.charCodeAt(i);
      hash = (hash << 5) - hash + character;
      hash = hash & hash;
    }

    return Math.abs(hash);
  }

  function prepare(com) {
    g_tex_slot = -1;
    g_material_slot = -1;
    g_model_slot = -1;
    g_component = com;
  }

  function setSpeed(com, v) {
    if (!g_isInit) {
      console.assert(false, 'effekseer not init!');
      return;
    } // console.log("efk ==> speed ", v);


    com = com;
    efk.effekseer.setSpeed(com.efkHandle, v);
  }

  function setPause(com, b) {
    if (!g_isInit) {
      console.assert(false, 'effekseer not init!');
      return;
    }

    com = com;
    efk.effekseer.setPaused(com.efkHandle, b);
  }

  function setFrame(com, n) {
    if (!g_isInit) {
      console.assert(false, 'effekseer not init!');
      return;
    }

    g_stepmode = true;
    com = com;
    efk.effekseer.updateHandleToMoveToFrame(com.efkHandle, n);
  }

  function setWorldMatrix(com) {
    if (!g_isInit) {
      console.assert(false, 'effekseer not init!');
      return;
    }

    com = com;
    var modelM = new Float32Array(JSON.parse(com.node.worldMatrix.toString()));
    efk.effekseer.setMatrix(com.efkHandle, modelM);
  }

  function stop(com) {
    if (!g_isInit) {
      console.assert(false, 'effekseer not init!');
      return;
    }

    com = com;
    delete g_effects[hash(com.uuid)];

    if (com.efkHandle !== undefined) {
      // console.log("efk ==> stop ", com.efkHandle);
      efk.effekseer.stopEffect(com.efkHandle);
      com.efkHandle = undefined;
    }
  }

  function unload(src) {
    if (!g_isInit) {
      console.assert(false, 'effekseer not init!');
      return;
    }

    var effect = g_effects_loader[src];

    if (effect === undefined) {
      return;
    }

    g_effects_refs[effect] -= 1;
    console.log("U " + src + " " + g_effects_refs[effect]);

    if (g_effects_refs[effect] == 0 && g_isUnloadImmediately) {
      delete g_effects_loader[src];
      efk.effekseer.unloadResources(effect);
    }
  }

  function load(com) {
    if (!g_isInit) {
      console.assert(false, 'effekseer not init!');
      return;
    }

    g_stepmode = false;
    com = com;

    if (!com.efk) {
      return;
    }

    stop(com); // 预先加载状态

    prepare(com); // 编辑器不使用缓存，这样重新导入 efk, 资源就会刷新

    if (EDITOR) {
      // console.log("efk ==> load ", com.efk.name);
      com.efkEffect = efk.effekseer.loadEffectOnMemory(com.efk._nativeAsset, com.efk.name, g_magnification);
      return;
    } // 加载特效


    if (g_effects_loader[com.efk.name]) {
      com.efkEffect = g_effects_loader[com.efk.name];
    } else {
      g_effects_loader[com.efk.name] = com.efkEffect = efk.effekseer.loadEffectOnMemory(com.efk._nativeAsset, com.efk.name, g_magnification);
      g_effects_refs[com.efkEffect] = 0;
    } // 引用计数


    g_effects_refs[com.efkEffect] += 1;
    console.log("A " + com.efk.name + " " + g_effects_refs[com.efkEffect]);
  }

  function play(com) {
    if (!g_isInit) {
      console.assert(false, 'effekseer not init!');
      return;
    }

    g_stepmode = false;
    com = com;

    if (!com.efk) {
      return;
    }

    if (com.efkHandle !== undefined) {
      efk.effekseer.setRemovingCallback(com.efkHandle, function () {});
      stop(com);
    } // 计算 hash 值，用于特效对象匹配


    var hash_key = hash(com.uuid);
    g_effects[hash_key] = com;
    com.efkHandle = efk.effekseer.playEffect(com.efkEffect, com.node.position.x, com.node.position.y, com.node.position.z);
    efk.effekseer.setUserData(com.efkHandle, hash_key);
    efk.effekseer.setScale(com.efkHandle, 1, 1, 1); // console.log("efk ==> play ", com.efkHandle);
    // 获取位偏移

    var renderid = com.node.layer.toString(2).indexOf("1");
    efk.effekseer.setLayer(com.efkHandle, renderid);
    efk.effekseer.setRemovingCallback(com.efkHandle, comPtr => {
      var comp = g_effects[comPtr];

      if (comp) {
        console.log("Remove: ", hash_key, com.efk.name);
        comp.onRemovingCallback();
      }
    });
    return efk.effekseer.getFrameCount(com.efkEffect);
  }

  function drawSprite(param, infoBuffer, cam, renderid) {
    var comp = g_effects[param.ComPtr];
    var uniforms = new Float32Array(infoBuffer.buffer, infoBuffer.byteOffset + param.UniformBufferOffset);
    var material = (_crd && EFKMaterial === void 0 ? (_reportPossibleCrUseOfEFKMaterial({
      error: Error()
    }), EFKMaterial) : EFKMaterial).check(param, uniforms, null, cam, renderid, 0);
    var model = (_crd && EFKModel === void 0 ? (_reportPossibleCrUseOfEFKModel({
      error: Error()
    }), EFKModel) : EFKModel).drawSprite(param.VertexBufferStride, param.VertexBufferOffset, param.ElementCount, material, material.parent.hash
    /* param.MaterialPtr */
    );

    comp._addModel(model);
  }

  function drawModel(param, infoBuffer, cam, renderid) {
    var comp = g_effects[param.ComPtr];
    var uniforms = new Float32Array(infoBuffer.buffer, infoBuffer.byteOffset + param.UniformBufferOffset);
    var count = param.ElementCount;

    for (var element = 0; element < count; ++element) {
      // 参数为 29 个浮点数, 查看 c++ 代码定义 ModelParameter1
      var model_params_float_count = 29;
      var model_params_offset = element * (Float32Array.BYTES_PER_ELEMENT * model_params_float_count);
      var models = new Float32Array(infoBuffer.buffer, infoBuffer.byteOffset + param.VertexBufferOffset + model_params_offset); // 执行绘制渲染

      var material = (_crd && EFKMaterial === void 0 ? (_reportPossibleCrUseOfEFKMaterial({
        error: Error()
      }), EFKMaterial) : EFKMaterial).check(param, uniforms, models, cam, renderid, element);

      var _model = (_crd && EFKModel === void 0 ? (_reportPossibleCrUseOfEFKModel({
        error: Error()
      }), EFKModel) : EFKModel).drawModel(param.ModelPtr, models[24], material, param.MaterialPtr);

      comp._addModel(_model);
    }
  }

  function enableExternalTexture(render_id, backgroud) {
    var depthTex = efk.effekseer.enableDepthTexture(render_id);
    var bgTex = efk.effekseer.enableBackGroundTexture(render_id);
    g_textures[bgTex] = backgroud.targetTexture;
    console.warn("no support");
  }

  function updateCamera(render_id, icam) {
    if (!g_isInit) {
      return;
    } // 更新渲染组


    var projM = new Float32Array(JSON.parse(icam.matProj.toString()));
    efk.effekseer.setProjectionMatrix(render_id, projM);
    var camM = new Float32Array(JSON.parse(icam.matView.clone().invert().toString()));
    efk.effekseer.setCameraMatrix(render_id, camM);
  }

  function renderCamera(renderid, cam) {
    // 更新粒子 (步进计算)
    efk.effekseer.render(renderid); // 填充粒子几何数据

    var model_count = efk.effekseer.renderStrideBufferCount();

    for (var ii = 0; ii < model_count; ++ii) {
      var stride = efk.effekseer.renderStrideBufferParameter(ii);
      (_crd && EFKModel === void 0 ? (_reportPossibleCrUseOfEFKModel({
        error: Error()
      }), EFKModel) : EFKModel).updateMesh(stride.Stride, stride.Ptr);
    } // 绘制粒子


    var count = efk.effekseer.renderParameterCount();
    if (0 >= count) return; // 材质属性更新

    var nbuf = efk.effekseer.renderInfoBuffer();
    var infoBuffer = new Float32Array(nbuf.buffer, nbuf.byteOffset); // 开始绘制

    for (var i = 0; i < count; ++i) {
      // if (i != 2) continue;
      var param = efk.effekseer.renderParameter(i);

      if (param.RenderMode !== 0) {
        drawModel(param, infoBuffer, cam, renderid);
      } else {
        drawSprite(param, infoBuffer, cam, renderid);
      }
    }
  }

  function render() {
    if (FORCE_NATIVE) {
      // @ts-ignore
      var batchs = efk.EFKRenderN.render(g_cameras, g_stepmode);

      var _loop = function _loop() {
        var models = batchs[comPtr];
        var comp = g_effects[comPtr];
        models.forEach(model => {
          comp._addModel(model);
        });
      };

      for (var comPtr in batchs) {
        _loop();
      }

      return;
    } // 重置模型


    (_crd && EFKModel === void 0 ? (_reportPossibleCrUseOfEFKModel({
      error: Error()
    }), EFKModel) : EFKModel).reset(); // 清除材质

    (_crd && EFKMaterial === void 0 ? (_reportPossibleCrUseOfEFKMaterial({
      error: Error()
    }), EFKMaterial) : EFKMaterial).reset(); // 更新帧时间 (这个不影响粒子播放时长)

    if (g_stepmode) {
      // 进入单步模式
      efk.effekseer.update(0);
    } else {
      // 正常刷新
      efk.effekseer.updateTime(1);
      efk.effekseer.update(1);
    }

    var editor_camera = null;

    if (EDITOR) {
      var _director$getScene;

      var cameraList = (_director$getScene = director.getScene()) == null || (_director$getScene = _director$getScene.renderScene) == null ? void 0 : _director$getScene.cameras;
      editor_camera = cameraList.filter(cam => {
        return cam.name == 'Editor Camera';
      })[0];
    } // 遍历所有分组


    for (var renderid = 0; renderid < g_cameras.length; ++renderid) {
      if (!g_cameras[renderid]) continue;

      if (EDITOR) {
        // 更新渲染组
        var projM = new Float32Array(JSON.parse(editor_camera.matProj.toString()));
        efk.effekseer.setProjectionMatrix(renderid, projM);
        var camM = new Float32Array(JSON.parse(editor_camera.matView.clone().invert().toString()));
        efk.effekseer.setCameraMatrix(renderid, camM);
        renderCamera(renderid, editor_camera);
      } else {
        renderCamera(renderid, g_cameras[renderid]);
      }
    }
  }

  function setup(defaultMats, magnification) {
    if (g_isInit) {
      return;
    }

    g_isInit = true;
    g_magnification = magnification;

    if (FORCE_NATIVE) {
      // @ts-ignore
      efk.EFKMaterialN.setInternals(defaultMats);
    } else {
      // 材质数据
      (_crd && EFKMaterial === void 0 ? (_reportPossibleCrUseOfEFKMaterial({
        error: Error()
      }), EFKMaterial) : EFKMaterial).config(g_textures, g_materials, defaultMats);
    } // 初始化 efk 库


    efk.effekseer.init(8192, 8192, 1, 0, 1, 1); // 加载纹理

    efk.effekseer.setTextureLoaderEvent((key, src) => {
      g_tex_slot++;

      if (null == g_textures[key]) {
        g_textures[key] = g_component.efkTextures[g_tex_slot];
        g_textures_refs[key] = 0;
      }

      g_textures_refs[key] += 1;

      if (FORCE_NATIVE) {
        // @ts-ignore
        efk.EFKMaterialN.setTexture(key, g_textures[key], false);
      }

      console.log('IMG: ', src, g_tex_slot, key);
    }, (id, key) => {
      console.log('DEL: ', id);
      g_textures_refs[key] -= 1;

      if (g_textures_refs[key] > 0) {
        return;
      }

      delete g_textures_refs[key];

      if (FORCE_NATIVE) {
        // @ts-ignore
        efk.EFKMaterialN.setTexture(key, g_textures[key], true);
      }

      delete g_textures[key];
    }); // 加载材质

    efk.effekseer.setMaterialLoaderEvent((key, src) => {
      g_material_slot++;

      if (null == g_materials[key]) {
        g_materials[key] = [];
        g_materials_refs[key] = 0;
      }

      g_materials_refs[key] += 1;
      var origin = g_component._materials[g_material_slot];
      var matSprite = new Material();
      matSprite.initialize({
        effectAsset: origin.effectAsset,
        effectName: origin.effectName,
        technique: efk.RendererMode.Sprite
      });
      g_materials[key][efk.RendererMode.Sprite] = matSprite;
      var matModel = new Material();
      matModel.initialize({
        effectAsset: origin.effectAsset,
        effectName: origin.effectName,
        technique: efk.RendererMode.Model
      });

      if (FORCE_NATIVE) {
        // @ts-ignore
        efk.EFKMaterialN.setCumstom(key, [matSprite, matModel], false);
      } else {
        g_materials[key][efk.RendererMode.Model] = matModel;
      }

      console.log('MAT: ', src, g_material_slot, key);
      return g_component.efkMats[g_material_slot]._nativeAsset;
    }, (src, key) => {
      g_materials_refs[key] -= 1;

      if (g_materials_refs[key] > 0) {
        return;
      }

      delete g_materials_refs[key];

      if (FORCE_NATIVE) {
        // @ts-ignore
        efk.EFKMaterialN.setCumstom(key, g_materials[key], true);
      } else {
        g_materials[key].forEach(mat => {
          mat.destroy();
        });
        delete g_materials[key];
      }

      console.log('DEL: ', src);
    }, (key, shader, type) => {}); // 加载模型

    efk.effekseer.setModelLoaderEvent((key, src) => {
      g_model_slot++;

      if (null == g_models_refs[key]) {
        g_models_refs[key] = 0;
      }

      g_models_refs[key] += 1;
      console.log('MOD: ', src, g_model_slot, key);
      return g_component.efkModels[g_model_slot]._nativeAsset;
    }, (key, model) => {
      for (var i = 0; i < model.getFrameCount(); ++i) {
        if (FORCE_NATIVE) {
          // @ts-ignore
          efk.EFKModelN.addModel(key, model.getVertecies(i), model.getFaces(i), i);
        } else {
          (_crd && EFKModel === void 0 ? (_reportPossibleCrUseOfEFKModel({
            error: Error()
          }), EFKModel) : EFKModel).addModel(key, model.getVertecies(i), model.getFaces(i), i);
        }
      }
    }, (key, src) => {
      g_models_refs[key] -= 1;

      if (g_models_refs[key] > 0) {
        return;
      }

      delete g_models_refs[key];

      if (FORCE_NATIVE) {
        // @ts-ignore
        efk.EFKModelN.removeModel(key);
      } else {
        (_crd && EFKModel === void 0 ? (_reportPossibleCrUseOfEFKModel({
          error: Error()
        }), EFKModel) : EFKModel).removeModel(key);
      }

      console.log('DEL: ', src);
    }); // 注册帧更新事件

    if (null != globalThis.efk_render_call) {
      director.off(Director.EVENT_AFTER_UPDATE, globalThis.efk_render_call);
      director.off(Director.EVENT_BEFORE_UPDATE, globalThis.efk_render_clean);
      director.off('efk-clear-cache', globalThis.efk_clear_cache);
    }

    globalThis.efk_render_call = () => {
      render();
    };

    director.on(Director.EVENT_AFTER_UPDATE, globalThis.efk_render_call);

    globalThis.efk_render_clean = () => {
      clearCacheImmediately();
    };

    director.on(Director.EVENT_BEFORE_UPDATE, globalThis.efk_render_clean);

    globalThis.efk_clear_cache = () => {
      clearCache();
    };

    director.on('efk-clear-cache', globalThis.efk_clear_cache);
  }

  function resume() {
    g_stepmode = false;
  }

  function clearCacheImmediately() {
    if (!g_isClearMask) {
      return;
    }

    g_isClearMask = false;

    for (var src in g_effects_loader) {
      var effect = g_effects_loader[src];

      if (g_effects_refs[effect] <= 0) {
        efk.effekseer.unloadResources(effect);
        delete g_effects_loader[src];
      }
    }

    if (FORCE_NATIVE) {
      // @ts-ignore
      efk.EFKMaterialN.clearCache();
    } else {
      (_crd && EFKMaterial === void 0 ? (_reportPossibleCrUseOfEFKMaterial({
        error: Error()
      }), EFKMaterial) : EFKMaterial).clearCache();
    }
  }

  function clearCache() {
    g_isClearMask = true;
  }

  function isInit() {
    return g_isInit;
  }

  function _reportPossibleCrUseOfEFKModel(extras) {
    _reporterNs.report("EFKModel", "./efk_model", _context.meta, extras);
  }

  function _reportPossibleCrUseOfEFKMaterial(extras) {
    _reporterNs.report("EFKMaterial", "./efk_material", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      Material = _cc.Material;
      director = _cc.director;
      Director = _cc.Director;
    }, function (_unresolved_2) {
      EFKModel = _unresolved_2.EFKModel;
    }, function (_ccEnv) {
      EDITOR = _ccEnv.EDITOR;
      NATIVE = _ccEnv.NATIVE;
    }, function (_unresolved_3) {
      EFKMaterial = _unresolved_3.EFKMaterial;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "8b7dc8ldQtGF6KQut5CnmhC", "efk_render", undefined);

      __checkObsolete__(['Node', 'Asset', 'Camera', 'Material', 'ModelRenderer', 'Texture2D', 'renderer', 'director', 'BufferAsset', 'Director', 'EffectAsset', 'Gradient']);

      FORCE_NATIVE = NATIVE && true;
      g_isUnloadImmediately = EDITOR || false;
      g_isInit = false;
      g_isClearMask = false;
      g_stepmode = false;
      g_cameras = [];
      g_effects = {};
      g_textures = {};
      g_textures_refs = {};
      g_materials = {};
      g_materials_refs = {};
      g_effects_loader = {};
      g_effects_refs = {};
      g_models_refs = {};
      g_tex_slot = -1;
      g_material_slot = -1;
      g_model_slot = -1;
      g_component = null;
      g_magnification = 1.0;

      _export("EFKRender", EFKRender = {
        // for render status control
        setup,
        resume,
        load,
        unload,
        updateCamera,
        enableExternalTexture,
        clearCache,
        isInit,
        // for play effect
        play,
        stop,
        setFrame,
        setSpeed,
        setPause,
        setWorldMatrix,
        cameras: g_cameras
      });

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=05bd4764c42e12e1a1608b9f668e75552f1c7a11.js.map