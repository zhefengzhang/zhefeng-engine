﻿#include "ModelLoader.h"

namespace Effekseer
{

ModelRef ModelLoader::Load(const char16_t* path)
{
	return nullptr;
}

ModelRef ModelLoader::Load(const void* data, int32_t size)
{
	return nullptr;
}

void ModelLoader::Unload(ModelRef data)
{
}

} // namespace Effekseer