
#include "./renderstate.h"

namespace cce {

RenderState::RenderState() {
}

RenderState::~RenderState() {
}

void RenderState::Update(bool forced) {
    m_active = m_next;
}

}