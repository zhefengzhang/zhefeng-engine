#include "Effekseer.MaterialCompiler.h"

namespace Effekseer
{

}