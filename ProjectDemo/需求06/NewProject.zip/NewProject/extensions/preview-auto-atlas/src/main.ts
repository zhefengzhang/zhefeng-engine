import { AssetInfo } from "../@types/packages/asset-db/@types/public";
var fs = require( "fs" );

/**
 * @en Registration method for the main process of Extension
 * @zh 为扩展的主进程的注册方法
 */
export const methods: { [ key: string ]: ( ...any: any ) => any } = {
    async RefreshAtlas()
    {
        console.log( "RefreshAtlas start!!" );
        let atlasConfigs: AssetInfo[] = await Editor.Message.request( "asset-db", "query-assets", {
            pattern: "db://assets/**/**",
            importer: 'auto-atlas',
        } );
        for ( let i = 0; i < atlasConfigs.length; i++ )
        {
            let atlasConfig = atlasConfigs[ i ];
            if ( Object.keys( atlasConfig.subAssets ).length === 0 )
            {
                let destPath = atlasConfig.library[ '.json' ];

                let url = atlasConfig.url;
                let dirIndex = url.lastIndexOf( "/" );
                let dirUrl = url.slice( 0, dirIndex );
                let spriteFrameFormat = dirUrl + "/**/**";
                let spriteFrames = await Editor.Message.request( "asset-db", "query-assets", {
                    pattern: spriteFrameFormat,
                    importer: 'sprite-frame',
                } );

                var data = fs.readFileSync( destPath );
                var pacConfig = JSON.parse( data.toString() );
                pacConfig.content.spriteFrames = [];
                for ( let j = 0; j < spriteFrames.length; j++ )
                {
                    let itemFrame = spriteFrames[ j ];
                    pacConfig.content.spriteFrames.push( itemFrame.displayName );
                    pacConfig.content.spriteFrames.push( itemFrame.uuid );
                }
                fs.writeFileSync( destPath, JSON.stringify( pacConfig ) );
            }
        }
        console.log( "RefreshAtlas end!!" );
    }
};

/**
 * @en Hooks triggered after extension loading is complete
 * @zh 扩展加载完成后触发的钩子
 */
export const load = function () { };

/**
 * @en Hooks triggered after extension uninstallation is complete
 * @zh 扩展卸载完成后触发的钩子
 */
export const unload = function () { };



