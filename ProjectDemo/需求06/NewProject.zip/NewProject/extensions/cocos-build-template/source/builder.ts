
import { BuildPlugin } from '../@types';

export const load: BuildPlugin.load = function() {
    console.debug('cocos-build-template load');
};

export const unload: BuildPlugin.load = function() {
    console.debug('cocos-build-template unload');
};

export const configs: BuildPlugin.Configs = {
    '*': {
        hooks: './hooks',
        options: {        
        },
        verifyRuleMap: {
            ruleTest: {
                message: 'i18n:cocos-build-template.ruleTest_msg',
                func(val, option) {
                    if (val === 'cocos') {
                        return true;
                    }
                    return false;
                },
            },
        },
    },
};

export const assetHandlers: BuildPlugin.AssetHandlers = './asset-handlers';
