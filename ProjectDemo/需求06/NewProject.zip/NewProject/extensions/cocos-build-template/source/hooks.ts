import { IBuildTaskOption, BuildHook } from '../@types';
import { Platform } from "../@types/packages/builder/@types/public/options";
import fs from 'fs';
import path from 'path';

interface IOptions
{
    commonTest1: number;
    commonTest2: 'opt1' | 'opt2';
    webTestOption: boolean;
}

const PACKAGE_NAME = 'cocos-build-template';

export let CurrentBuildPlatform: Platform = null;

interface ITaskOptions extends IBuildTaskOption
{
    packages: {
        'cocos-plugin-template': IOptions;
    };
}

function log(...arg: any[])
{
    return console.log(`[${PACKAGE_NAME}] `, ...arg);
}

export const throwError: BuildHook.throwError = true;

export const load: BuildHook.load = async function ()
{
    log('load');
};

export const onBeforeBuild: BuildHook.onBeforeBuild = async function (options)
{
    CurrentBuildPlatform = options.platform;
    log(`onBeforeBuild 暫存platform : ${CurrentBuildPlatform}`);
};

export const onBeforeCompressSettings: BuildHook.onBeforeCompressSettings = async function (options, result)
{
    log('onBeforeCompressSettings');
};

export const onAfterCompressSettings: BuildHook.onAfterCompressSettings = async function (options, result)
{
    log('onAfterCompressSettings');
};

export const onAfterBuild: BuildHook.onAfterBuild = async function (options, result)
{
    log('onAfterBuild');

    //編譯完成後讀取 setting.json file
    let VRNVersionPath = path.join(result.dest, 'assets/VRNServer');

    let bundleSetting = fs.readFileSync(result.paths.settings).toString('utf8');
    let bundleStudent = JSON.parse(bundleSetting);

    //ios 版本關鍵字調整VRN
    fs.writeFileSync(VRNVersionPath, JSON.stringify(bundleStudent.assets.bundleVers));
    log(`Create ${VRNVersionPath} Done`);

    VRNProcess(result.dest, bundleStudent.assets.bundleVers);
}

export const unload: BuildHook.unload = async function ()
{
    log(`unload`);
};

//ios 版本關鍵字調整VRN
function VRNProcess(resultDest: string, bundleVers: Object)
{
    log("VRNProcess resultDest->", resultDest);
    log("VRNProcess bundleVers->", bundleVers);
    for (let [bundleKey, bundleVer] of Object.entries(bundleVers))
    {
        //native 
        let ccConfigPath = path.join(resultDest, 'assets', 'assets', bundleKey, "cc.config." + bundleVer + ".json");
        //web
        let ConfigPath = path.join(resultDest, 'assets', bundleKey, "config." + bundleVer + ".json");

        //讀取 cc.config
        if (fs.existsSync(ccConfigPath) || fs.existsSync(ConfigPath))
        {
            let VRNFilePath = fs.existsSync(ccConfigPath) == true ? ccConfigPath : ConfigPath;
            let ccConfig = fs.readFileSync(VRNFilePath).toString('utf8');
            let ccConfigStudent = JSON.parse(ccConfig);

            //階段一改名 versions -> VRN
            ccConfigStudent.VRN = ccConfigStudent.versions;

            //階段二移除 versions
            // delete ccConfigStudent.versions;

            fs.writeFileSync(VRNFilePath, JSON.stringify(ccConfigStudent));
            log("VRNProcess", VRNFilePath, "success");
        }
    }
}
