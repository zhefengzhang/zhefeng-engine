import { AssetHandlers } from '../@types';
import { CurrentBuildPlatform } from "./hooks"
import { copy } from 'fs-extra';

/**
 * cocos 3.4.3 測試結果:
 * 若在 web mobile 打包 只會有 png 與 jpg
 * 若在 android 平台打包 pvrtc 不會進來
 * 以經驗來看 平台不能使用的壓縮方式 會進不來
 * 
 * input 參數 tasks 會把 同樣壓縮格式的貼圖打成一整包傳入
 */
export const compressTextures: AssetHandlers.compressTextures = async (tasks) =>
{
    if (tasks.length > 0)
    {
        console.log(`==== compress textures platform : ${CurrentBuildPlatform}, format : ${tasks[0].format} , count : ${tasks.length} ====`);
    }

    // ios平台 進行 純複製流程
    for (let i = 0; i < Array.from(tasks).length; i++)
    {
        const task = Array.from(tasks)[i];

        let extName = ".png";
        if (task.format.startsWith(`pvrtc`))
        {
            extName = ".pvr";
        }
        else if (task.format.startsWith(`etc`))
        {
            extName = ".pkm";
        }
        else if (task.format.startsWith(`astc`) && task.format == 'astc_8x8')
        {
            extName = ".astc";
        }
        else if (task.format === `png`)
        {
            extName = ".png";
        }
        else if (task.format === `jpg`)
        {
            extName = ".jpg";
        }
        else
        {
            continue;
        }
        let pos = task.dest.lastIndexOf(".");
        if (pos >= 0)
        {
            task.dest = task.dest.substring(0, pos < 0 ? task.dest.length : pos) + extName;
        }

        await copy(task.src, task.dest);

        tasks.splice(i, 1);
        i--;
    }
}