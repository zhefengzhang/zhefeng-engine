
// clang-format off

#include "cocos/bindings/manual/jsb_conversions.h"
#include "cocos/bindings/manual/jsb_global.h"

#include "bindings/auto/jsb_assets_auto.h"
#include "bindings/auto/jsb_scene_auto.h"

#include "./jsb_effekseer_manual.h"

#ifndef JSB_ALLOC
#define JSB_ALLOC(kls, ...) new (std::nothrow) kls(__VA_ARGS__)
#endif

#ifndef JSB_FREE
#define JSB_FREE(ptr) delete ptr
#endif

#if CC_DEBUG
static bool js_effekseer_getter_return_true(se::State& s) // NOLINT(readability-identifier-naming)
{
    s.rval().setBoolean(true);
    return true;
}
SE_BIND_PROP_GET(js_effekseer_getter_return_true)
#endif
se::Object* __jsb_cce_ShaderEx_proto = nullptr; // NOLINT
se::Class* __jsb_cce_ShaderEx_class = nullptr;  // NOLINT

static bool js_effekseer_ShaderEx_GetType(se::State& s) // NOLINT(readability-identifier-naming)
{
    auto* cobj = SE_THIS_OBJECT<cce::ShaderEx>(s);
    // SE_PRECONDITION2(cobj, false, "Invalid Native Object");
    if (nullptr == cobj) return true;
    const auto& args = s.args();
    size_t argc = args.size();
    CC_UNUSED bool ok = true;
    if (argc == 0) {
        auto result = static_cast<int>(cobj->GetType());
        ok &= nativevalue_to_se(result, s.rval(), nullptr /*ctx*/);
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        SE_HOLD_RETURN_VALUE(result, s.thisObject(), s.rval());
        return true;
    }
    SE_REPORT_ERROR("wrong number of arguments: %d, was expecting %d", (int)argc, 0);
    return false;
}
SE_BIND_FUNC(js_effekseer_ShaderEx_GetType)

static bool js_effekseer_ShaderEx_getFS(se::State& s) // NOLINT(readability-identifier-naming)
{
    auto* cobj = SE_THIS_OBJECT<cce::ShaderEx>(s);
    // SE_PRECONDITION2(cobj, false, "Invalid Native Object");
    if (nullptr == cobj) return true;
    const auto& args = s.args();
    size_t argc = args.size();
    CC_UNUSED bool ok = true;
    if (argc == 0) {
        std::string& result = cobj->getFS();
        ok &= nativevalue_to_se(result, s.rval(), nullptr /*ctx*/);
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        SE_HOLD_RETURN_VALUE(result, s.thisObject(), s.rval());
        return true;
    }
    SE_REPORT_ERROR("wrong number of arguments: %d, was expecting %d", (int)argc, 0);
    return false;
}
SE_BIND_FUNC(js_effekseer_ShaderEx_getFS)

static bool js_effekseer_ShaderEx_getUniform(se::State& s) // NOLINT(readability-identifier-naming)
{
    auto* cobj = SE_THIS_OBJECT<cce::ShaderEx>(s);
    // SE_PRECONDITION2(cobj, false, "Invalid Native Object");
    if (nullptr == cobj) return true;
    const auto& args = s.args();
    size_t argc = args.size();
    CC_UNUSED bool ok = true;
    if (argc == 1) {
        HolderType<int, false> arg0 = {};
        ok &= sevalue_to_native(args[0], &arg0, s.thisObject());
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        char* result = cobj->getUniform(arg0.value());
        ok &= nativevalue_to_se(result, s.rval(), nullptr /*ctx*/);
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        SE_HOLD_RETURN_VALUE(result, s.thisObject(), s.rval());
        return true;
    }
    SE_REPORT_ERROR("wrong number of arguments: %d, was expecting %d", (int)argc, 1);
    return false;
}
SE_BIND_FUNC(js_effekseer_ShaderEx_getUniform)

static bool js_effekseer_ShaderEx_getUniformCount(se::State& s) // NOLINT(readability-identifier-naming)
{
    auto* cobj = SE_THIS_OBJECT<cce::ShaderEx>(s);
    // SE_PRECONDITION2(cobj, false, "Invalid Native Object");
    if (nullptr == cobj) return true;
    const auto& args = s.args();
    size_t argc = args.size();
    CC_UNUSED bool ok = true;
    if (argc == 0) {
        int32_t result = cobj->getUniformCount();
        ok &= nativevalue_to_se(result, s.rval(), nullptr /*ctx*/);
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        SE_HOLD_RETURN_VALUE(result, s.thisObject(), s.rval());
        return true;
    }
    SE_REPORT_ERROR("wrong number of arguments: %d, was expecting %d", (int)argc, 0);
    return false;
}
SE_BIND_FUNC(js_effekseer_ShaderEx_getUniformCount)

static bool js_effekseer_ShaderEx_getVS(se::State& s) // NOLINT(readability-identifier-naming)
{
    auto* cobj = SE_THIS_OBJECT<cce::ShaderEx>(s);
    // SE_PRECONDITION2(cobj, false, "Invalid Native Object");
    if (nullptr == cobj) return true;
    const auto& args = s.args();
    size_t argc = args.size();
    CC_UNUSED bool ok = true;
    if (argc == 0) {
        std::string& result = cobj->getVS();
        ok &= nativevalue_to_se(result, s.rval(), nullptr /*ctx*/);
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        SE_HOLD_RETURN_VALUE(result, s.thisObject(), s.rval());
        return true;
    }
    SE_REPORT_ERROR("wrong number of arguments: %d, was expecting %d", (int)argc, 0);
    return false;
}
SE_BIND_FUNC(js_effekseer_ShaderEx_getVS)

SE_DECLARE_FINALIZE_FUNC(js_cce_ShaderEx_finalize)

static bool js_effekseer_ShaderEx_constructor(se::State& s) // NOLINT(readability-identifier-naming) constructor_overloaded.c
{
    //#1 cce::ShaderEx: is_skip_construtor True
    se::ScriptEngine::getInstance()->evalString("throw new Error(\"cce::ShaderEx constructor is skipped\")");
    return false;
}
SE_BIND_CTOR(js_effekseer_ShaderEx_constructor, __jsb_cce_ShaderEx_class, js_cce_ShaderEx_finalize)

static bool js_cce_ShaderEx_finalize(se::State& s) // NOLINT(readability-identifier-naming)
{
    return true;
}
SE_BIND_FINALIZE_FUNC(js_cce_ShaderEx_finalize)

bool js_register_effekseer_ShaderEx(se::Object* obj) // NOLINT(readability-identifier-naming)
{
    auto* cls = se::Class::create("ShaderEx", obj, nullptr, _SE(js_effekseer_ShaderEx_constructor));

#if CC_DEBUG
    cls->defineStaticProperty("isJSBClass", _SE(js_effekseer_getter_return_true), nullptr);
#endif
    cls->defineFunction("GetType", _SE(js_effekseer_ShaderEx_GetType));
    cls->defineFunction("getFS", _SE(js_effekseer_ShaderEx_getFS));
    cls->defineFunction("getUniform", _SE(js_effekseer_ShaderEx_getUniform));
    cls->defineFunction("getUniformCount", _SE(js_effekseer_ShaderEx_getUniformCount));
    cls->defineFunction("getVS", _SE(js_effekseer_ShaderEx_getVS));
    cls->defineFinalizeFunction(_SE(js_cce_ShaderEx_finalize));
    cls->install();
    JSBClassType::registerClass<cce::ShaderEx>(cls);

    __jsb_cce_ShaderEx_proto = cls->getProto();
    __jsb_cce_ShaderEx_class = cls;


    se::ScriptEngine::getInstance()->clearException();
    return true;
}
se::Object* __jsb_cce_ModelEx_proto = nullptr; // NOLINT
se::Class* __jsb_cce_ModelEx_class = nullptr;  // NOLINT

static bool js_effekseer_ModelEx_getFaces(se::State& s) // NOLINT(readability-identifier-naming)
{
    auto* cobj = SE_THIS_OBJECT<cce::ModelEx>(s);
    // SE_PRECONDITION2(cobj, false, "Invalid Native Object");
    if (nullptr == cobj) return true;
    const auto& args = s.args();
    size_t argc = args.size();
    CC_UNUSED bool ok = true;
    if (argc == 1) {
        HolderType<int, false> arg0 = {};
        ok &= sevalue_to_native(args[0], &arg0, s.thisObject());
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        std::vector<unsigned char> result = cobj->getFaces(arg0.value());
        ok &= nativevalue_to_se(result, s.rval(), nullptr /*ctx*/);
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        SE_HOLD_RETURN_VALUE(result, s.thisObject(), s.rval());
        return true;
    }
    SE_REPORT_ERROR("wrong number of arguments: %d, was expecting %d", (int)argc, 1);
    return false;
}
SE_BIND_FUNC(js_effekseer_ModelEx_getFaces)

static bool js_effekseer_ModelEx_getFrameCount(se::State& s) // NOLINT(readability-identifier-naming)
{
    auto* cobj = SE_THIS_OBJECT<cce::ModelEx>(s);
    // SE_PRECONDITION2(cobj, false, "Invalid Native Object");
    if (nullptr == cobj) return true;
    const auto& args = s.args();
    size_t argc = args.size();
    CC_UNUSED bool ok = true;
    if (argc == 0) {
        int result = cobj->getFrameCount();
        ok &= nativevalue_to_se(result, s.rval(), nullptr /*ctx*/);
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        SE_HOLD_RETURN_VALUE(result, s.thisObject(), s.rval());
        return true;
    }
    SE_REPORT_ERROR("wrong number of arguments: %d, was expecting %d", (int)argc, 0);
    return false;
}
SE_BIND_FUNC(js_effekseer_ModelEx_getFrameCount)

static bool js_effekseer_ModelEx_getVertecies(se::State& s) // NOLINT(readability-identifier-naming)
{
    auto* cobj = SE_THIS_OBJECT<cce::ModelEx>(s);
    // SE_PRECONDITION2(cobj, false, "Invalid Native Object");
    if (nullptr == cobj) return true;
    const auto& args = s.args();
    size_t argc = args.size();
    CC_UNUSED bool ok = true;
    if (argc == 1) {
        HolderType<int, false> arg0 = {};
        ok &= sevalue_to_native(args[0], &arg0, s.thisObject());
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        std::vector<unsigned char> result = cobj->getVertecies(arg0.value());
        ok &= nativevalue_to_se(result, s.rval(), nullptr /*ctx*/);
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        SE_HOLD_RETURN_VALUE(result, s.thisObject(), s.rval());
        return true;
    }
    SE_REPORT_ERROR("wrong number of arguments: %d, was expecting %d", (int)argc, 1);
    return false;
}
SE_BIND_FUNC(js_effekseer_ModelEx_getVertecies)

SE_DECLARE_FINALIZE_FUNC(js_cce_ModelEx_finalize)

static bool js_effekseer_ModelEx_constructor(se::State& s) // NOLINT(readability-identifier-naming) constructor.c
{
    CC_UNUSED bool ok = true;
    const auto& args = s.args();
    void* arg0 = nullptr;
    int32_t arg1 = 0;
    ok &= sevalue_to_native(args[0], &arg0, s.thisObject());
    ok &= sevalue_to_native(args[1], &arg1, s.thisObject());
    SE_PRECONDITION2(ok, false, "Error processing arguments");
    auto *ptr = JSB_MAKE_PRIVATE_OBJECT(cce::ModelEx, arg0, arg1);
    s.thisObject()->setPrivateObject(ptr);
    return true;
}
SE_BIND_CTOR(js_effekseer_ModelEx_constructor, __jsb_cce_ModelEx_class, js_cce_ModelEx_finalize)

static bool js_cce_ModelEx_finalize(se::State& s) // NOLINT(readability-identifier-naming)
{
    return true;
}
SE_BIND_FINALIZE_FUNC(js_cce_ModelEx_finalize)

bool js_register_effekseer_ModelEx(se::Object* obj) // NOLINT(readability-identifier-naming)
{
    auto* cls = se::Class::create("ModelEx", obj, nullptr, _SE(js_effekseer_ModelEx_constructor));

#if CC_DEBUG
    cls->defineStaticProperty("isJSBClass", _SE(js_effekseer_getter_return_true), nullptr);
#endif
    cls->defineFunction("getFaces", _SE(js_effekseer_ModelEx_getFaces));
    cls->defineFunction("getFrameCount", _SE(js_effekseer_ModelEx_getFrameCount));
    cls->defineFunction("getVertecies", _SE(js_effekseer_ModelEx_getVertecies));
    cls->defineFinalizeFunction(_SE(js_cce_ModelEx_finalize));
    cls->install();
    JSBClassType::registerClass<cce::ModelEx>(cls);

    __jsb_cce_ModelEx_proto = cls->getProto();
    __jsb_cce_ModelEx_class = cls;


    se::ScriptEngine::getInstance()->clearException();
    return true;
}
se::Object* __jsb_cce_StrideBufferParameterEx_proto = nullptr; // NOLINT
se::Class* __jsb_cce_StrideBufferParameterEx_class = nullptr;  // NOLINT

static bool js_effekseer_StrideBufferParameterEx_get_Stride(se::State& s) // NOLINT(readability-identifier-naming)
{
    auto* cobj = SE_THIS_OBJECT<cce::StrideBufferParameterEx>(s);
    // SE_PRECONDITION2(cobj, false, "Invalid Native Object");
    if (nullptr == cobj) return true;

    CC_UNUSED bool ok = true;
    se::Value jsret;
    ok &= nativevalue_to_se(cobj->Stride, jsret, s.thisObject() /*ctx*/);
    s.rval() = jsret;
    SE_HOLD_RETURN_VALUE(cobj->Stride, s.thisObject(), s.rval());
    return true;
}
SE_BIND_PROP_GET(js_effekseer_StrideBufferParameterEx_get_Stride)

static bool js_effekseer_StrideBufferParameterEx_set_Stride(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    auto* cobj = SE_THIS_OBJECT<cce::StrideBufferParameterEx>(s);
    SE_PRECONDITION2(cobj, false, "Invalid Native Object");

    CC_UNUSED bool ok = true;
    ok &= sevalue_to_native(args[0], &cobj->Stride, s.thisObject());
    SE_PRECONDITION2(ok, false, "Error processing new value");
    return true;
}
SE_BIND_PROP_SET(js_effekseer_StrideBufferParameterEx_set_Stride)

static bool js_effekseer_StrideBufferParameterEx_get_Ptr(se::State& s) // NOLINT(readability-identifier-naming)
{
    auto* cobj = SE_THIS_OBJECT<cce::StrideBufferParameterEx>(s);
    // SE_PRECONDITION2(cobj, false, "Invalid Native Object");
    if (nullptr == cobj) return true;

    CC_UNUSED bool ok = true;
    se::Value jsret;
    ok &= nativevalue_to_se(cobj->Ptr, jsret, s.thisObject() /*ctx*/);
    s.rval() = jsret;
    SE_HOLD_RETURN_VALUE(cobj->Ptr, s.thisObject(), s.rval());
    return true;
}
SE_BIND_PROP_GET(js_effekseer_StrideBufferParameterEx_get_Ptr)

static bool js_effekseer_StrideBufferParameterEx_set_Ptr(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    auto* cobj = SE_THIS_OBJECT<cce::StrideBufferParameterEx>(s);
    SE_PRECONDITION2(cobj, false, "Invalid Native Object");

    CC_UNUSED bool ok = true;
    ok &= sevalue_to_native(args[0], &cobj->Ptr, s.thisObject());
    SE_PRECONDITION2(ok, false, "Error processing new value");
    return true;
}
SE_BIND_PROP_SET(js_effekseer_StrideBufferParameterEx_set_Ptr)


template<>
bool sevalue_to_native(const se::Value &from, cce::StrideBufferParameterEx * to, se::Object *ctx)
{
    assert(from.isObject());
    se::Object *json = from.toObject();
    auto* data = reinterpret_cast<cce::StrideBufferParameterEx*>(json->getPrivateData());
    if (data) {
        *to = *data;
        return true;
    }
    se::Value field;
    bool ok = true;
    json->getProperty("Stride", &field, true);
    if(!field.isNullOrUndefined()) {
        ok &= sevalue_to_native(field, &(to->Stride), ctx);
    }
    json->getProperty("Ptr", &field, true);
    if(!field.isNullOrUndefined()) {
        ok &= sevalue_to_native(field, &(to->Ptr), ctx);
    }
    return ok;
}

SE_DECLARE_FINALIZE_FUNC(js_cce_StrideBufferParameterEx_finalize)

static bool js_effekseer_StrideBufferParameterEx_constructor(se::State& s) // NOLINT(readability-identifier-naming)
{
    CC_UNUSED bool ok = true;
    const auto& args = s.args();
    size_t argc = args.size();

    if(argc == 0)
    {
        auto *ptr = JSB_MAKE_PRIVATE_OBJECT(cce::StrideBufferParameterEx);
        s.thisObject()->setPrivateObject(ptr);
        return true;
    }

    if(argc == 1 && args[0].isObject())
    {
        se::Object *json = args[0].toObject();
        se::Value field;
        auto *ptr = JSB_MAKE_PRIVATE_OBJECT(cce::StrideBufferParameterEx);
        auto cobj = ptr->get<cce::StrideBufferParameterEx>();
        ok &= sevalue_to_native(args[0], cobj, s.thisObject());
        if(!ok) {
            delete ptr;
            SE_REPORT_ERROR("argument convertion error");
            return false;
        }
        s.thisObject()->setPrivateObject(ptr);
        return true;
    }
    auto *ptr = JSB_MAKE_PRIVATE_OBJECT(cce::StrideBufferParameterEx);
    auto cobj = ptr->get<cce::StrideBufferParameterEx>();
    if (argc > 0 && !args[0].isUndefined()) {
        ok &= sevalue_to_native(args[0], &(cobj->Stride), nullptr);
    }
    if (argc > 1 && !args[1].isUndefined()) {
        ok &= sevalue_to_native(args[1], &(cobj->Ptr), nullptr);
    }

    if(!ok) {
        delete ptr;
        SE_REPORT_ERROR("Argument convertion error");
        return false;
    }
    s.thisObject()->setPrivateObject(ptr);
    return true;
}
SE_BIND_CTOR(js_effekseer_StrideBufferParameterEx_constructor, __jsb_cce_StrideBufferParameterEx_class, js_cce_StrideBufferParameterEx_finalize)

static bool js_cce_StrideBufferParameterEx_finalize(se::State& s) // NOLINT(readability-identifier-naming)
{
    return true;
}
SE_BIND_FINALIZE_FUNC(js_cce_StrideBufferParameterEx_finalize)

bool js_register_effekseer_StrideBufferParameterEx(se::Object* obj) // NOLINT(readability-identifier-naming)
{
    auto* cls = se::Class::create("StrideBufferParameterEx", obj, nullptr, _SE(js_effekseer_StrideBufferParameterEx_constructor));

#if CC_DEBUG
    cls->defineStaticProperty("isJSBClass", _SE(js_effekseer_getter_return_true), nullptr);
#endif
    cls->defineProperty("Stride", _SE(js_effekseer_StrideBufferParameterEx_get_Stride), _SE(js_effekseer_StrideBufferParameterEx_set_Stride));
    cls->defineProperty("Ptr", _SE(js_effekseer_StrideBufferParameterEx_get_Ptr), _SE(js_effekseer_StrideBufferParameterEx_set_Ptr));
    cls->defineFinalizeFunction(_SE(js_cce_StrideBufferParameterEx_finalize));
    cls->install();
    JSBClassType::registerClass<cce::StrideBufferParameterEx>(cls);

    __jsb_cce_StrideBufferParameterEx_proto = cls->getProto();
    __jsb_cce_StrideBufferParameterEx_class = cls;


    se::ScriptEngine::getInstance()->clearException();
    return true;
}
se::Object* __jsb_cce_FlipbookParametersEx_proto = nullptr; // NOLINT
se::Class* __jsb_cce_FlipbookParametersEx_class = nullptr;  // NOLINT

static bool js_effekseer_FlipbookParametersEx_get_Enable(se::State& s) // NOLINT(readability-identifier-naming)
{
    auto* cobj = SE_THIS_OBJECT<cce::FlipbookParametersEx>(s);
    // SE_PRECONDITION2(cobj, false, "Invalid Native Object");
    if (nullptr == cobj) return true;

    CC_UNUSED bool ok = true;
    se::Value jsret;
    ok &= nativevalue_to_se(cobj->Enable, jsret, s.thisObject() /*ctx*/);
    s.rval() = jsret;
    SE_HOLD_RETURN_VALUE(cobj->Enable, s.thisObject(), s.rval());
    return true;
}
SE_BIND_PROP_GET(js_effekseer_FlipbookParametersEx_get_Enable)

static bool js_effekseer_FlipbookParametersEx_set_Enable(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    auto* cobj = SE_THIS_OBJECT<cce::FlipbookParametersEx>(s);
    SE_PRECONDITION2(cobj, false, "Invalid Native Object");

    CC_UNUSED bool ok = true;
    ok &= sevalue_to_native(args[0], &cobj->Enable, s.thisObject());
    SE_PRECONDITION2(ok, false, "Error processing new value");
    return true;
}
SE_BIND_PROP_SET(js_effekseer_FlipbookParametersEx_set_Enable)

static bool js_effekseer_FlipbookParametersEx_get_LoopType(se::State& s) // NOLINT(readability-identifier-naming)
{
    auto* cobj = SE_THIS_OBJECT<cce::FlipbookParametersEx>(s);
    // SE_PRECONDITION2(cobj, false, "Invalid Native Object");
    if (nullptr == cobj) return true;

    CC_UNUSED bool ok = true;
    se::Value jsret;
    ok &= nativevalue_to_se(cobj->LoopType, jsret, s.thisObject() /*ctx*/);
    s.rval() = jsret;
    SE_HOLD_RETURN_VALUE(cobj->LoopType, s.thisObject(), s.rval());
    return true;
}
SE_BIND_PROP_GET(js_effekseer_FlipbookParametersEx_get_LoopType)

static bool js_effekseer_FlipbookParametersEx_set_LoopType(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    auto* cobj = SE_THIS_OBJECT<cce::FlipbookParametersEx>(s);
    SE_PRECONDITION2(cobj, false, "Invalid Native Object");

    CC_UNUSED bool ok = true;
    ok &= sevalue_to_native(args[0], &cobj->LoopType, s.thisObject());
    SE_PRECONDITION2(ok, false, "Error processing new value");
    return true;
}
SE_BIND_PROP_SET(js_effekseer_FlipbookParametersEx_set_LoopType)

static bool js_effekseer_FlipbookParametersEx_get_DivideX(se::State& s) // NOLINT(readability-identifier-naming)
{
    auto* cobj = SE_THIS_OBJECT<cce::FlipbookParametersEx>(s);
    // SE_PRECONDITION2(cobj, false, "Invalid Native Object");
    if (nullptr == cobj) return true;

    CC_UNUSED bool ok = true;
    se::Value jsret;
    ok &= nativevalue_to_se(cobj->DivideX, jsret, s.thisObject() /*ctx*/);
    s.rval() = jsret;
    SE_HOLD_RETURN_VALUE(cobj->DivideX, s.thisObject(), s.rval());
    return true;
}
SE_BIND_PROP_GET(js_effekseer_FlipbookParametersEx_get_DivideX)

static bool js_effekseer_FlipbookParametersEx_set_DivideX(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    auto* cobj = SE_THIS_OBJECT<cce::FlipbookParametersEx>(s);
    SE_PRECONDITION2(cobj, false, "Invalid Native Object");

    CC_UNUSED bool ok = true;
    ok &= sevalue_to_native(args[0], &cobj->DivideX, s.thisObject());
    SE_PRECONDITION2(ok, false, "Error processing new value");
    return true;
}
SE_BIND_PROP_SET(js_effekseer_FlipbookParametersEx_set_DivideX)

static bool js_effekseer_FlipbookParametersEx_get_DivideY(se::State& s) // NOLINT(readability-identifier-naming)
{
    auto* cobj = SE_THIS_OBJECT<cce::FlipbookParametersEx>(s);
    // SE_PRECONDITION2(cobj, false, "Invalid Native Object");
    if (nullptr == cobj) return true;

    CC_UNUSED bool ok = true;
    se::Value jsret;
    ok &= nativevalue_to_se(cobj->DivideY, jsret, s.thisObject() /*ctx*/);
    s.rval() = jsret;
    SE_HOLD_RETURN_VALUE(cobj->DivideY, s.thisObject(), s.rval());
    return true;
}
SE_BIND_PROP_GET(js_effekseer_FlipbookParametersEx_get_DivideY)

static bool js_effekseer_FlipbookParametersEx_set_DivideY(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    auto* cobj = SE_THIS_OBJECT<cce::FlipbookParametersEx>(s);
    SE_PRECONDITION2(cobj, false, "Invalid Native Object");

    CC_UNUSED bool ok = true;
    ok &= sevalue_to_native(args[0], &cobj->DivideY, s.thisObject());
    SE_PRECONDITION2(ok, false, "Error processing new value");
    return true;
}
SE_BIND_PROP_SET(js_effekseer_FlipbookParametersEx_set_DivideY)

static bool js_effekseer_FlipbookParametersEx_get_OneSizeX(se::State& s) // NOLINT(readability-identifier-naming)
{
    auto* cobj = SE_THIS_OBJECT<cce::FlipbookParametersEx>(s);
    // SE_PRECONDITION2(cobj, false, "Invalid Native Object");
    if (nullptr == cobj) return true;

    CC_UNUSED bool ok = true;
    se::Value jsret;
    ok &= nativevalue_to_se(cobj->OneSizeX, jsret, s.thisObject() /*ctx*/);
    s.rval() = jsret;
    SE_HOLD_RETURN_VALUE(cobj->OneSizeX, s.thisObject(), s.rval());
    return true;
}
SE_BIND_PROP_GET(js_effekseer_FlipbookParametersEx_get_OneSizeX)

static bool js_effekseer_FlipbookParametersEx_set_OneSizeX(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    auto* cobj = SE_THIS_OBJECT<cce::FlipbookParametersEx>(s);
    SE_PRECONDITION2(cobj, false, "Invalid Native Object");

    CC_UNUSED bool ok = true;
    ok &= sevalue_to_native(args[0], &cobj->OneSizeX, s.thisObject());
    SE_PRECONDITION2(ok, false, "Error processing new value");
    return true;
}
SE_BIND_PROP_SET(js_effekseer_FlipbookParametersEx_set_OneSizeX)

static bool js_effekseer_FlipbookParametersEx_get_OneSizeY(se::State& s) // NOLINT(readability-identifier-naming)
{
    auto* cobj = SE_THIS_OBJECT<cce::FlipbookParametersEx>(s);
    // SE_PRECONDITION2(cobj, false, "Invalid Native Object");
    if (nullptr == cobj) return true;

    CC_UNUSED bool ok = true;
    se::Value jsret;
    ok &= nativevalue_to_se(cobj->OneSizeY, jsret, s.thisObject() /*ctx*/);
    s.rval() = jsret;
    SE_HOLD_RETURN_VALUE(cobj->OneSizeY, s.thisObject(), s.rval());
    return true;
}
SE_BIND_PROP_GET(js_effekseer_FlipbookParametersEx_get_OneSizeY)

static bool js_effekseer_FlipbookParametersEx_set_OneSizeY(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    auto* cobj = SE_THIS_OBJECT<cce::FlipbookParametersEx>(s);
    SE_PRECONDITION2(cobj, false, "Invalid Native Object");

    CC_UNUSED bool ok = true;
    ok &= sevalue_to_native(args[0], &cobj->OneSizeY, s.thisObject());
    SE_PRECONDITION2(ok, false, "Error processing new value");
    return true;
}
SE_BIND_PROP_SET(js_effekseer_FlipbookParametersEx_set_OneSizeY)

static bool js_effekseer_FlipbookParametersEx_get_OffsetX(se::State& s) // NOLINT(readability-identifier-naming)
{
    auto* cobj = SE_THIS_OBJECT<cce::FlipbookParametersEx>(s);
    // SE_PRECONDITION2(cobj, false, "Invalid Native Object");
    if (nullptr == cobj) return true;

    CC_UNUSED bool ok = true;
    se::Value jsret;
    ok &= nativevalue_to_se(cobj->OffsetX, jsret, s.thisObject() /*ctx*/);
    s.rval() = jsret;
    SE_HOLD_RETURN_VALUE(cobj->OffsetX, s.thisObject(), s.rval());
    return true;
}
SE_BIND_PROP_GET(js_effekseer_FlipbookParametersEx_get_OffsetX)

static bool js_effekseer_FlipbookParametersEx_set_OffsetX(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    auto* cobj = SE_THIS_OBJECT<cce::FlipbookParametersEx>(s);
    SE_PRECONDITION2(cobj, false, "Invalid Native Object");

    CC_UNUSED bool ok = true;
    ok &= sevalue_to_native(args[0], &cobj->OffsetX, s.thisObject());
    SE_PRECONDITION2(ok, false, "Error processing new value");
    return true;
}
SE_BIND_PROP_SET(js_effekseer_FlipbookParametersEx_set_OffsetX)

static bool js_effekseer_FlipbookParametersEx_get_OffsetY(se::State& s) // NOLINT(readability-identifier-naming)
{
    auto* cobj = SE_THIS_OBJECT<cce::FlipbookParametersEx>(s);
    // SE_PRECONDITION2(cobj, false, "Invalid Native Object");
    if (nullptr == cobj) return true;

    CC_UNUSED bool ok = true;
    se::Value jsret;
    ok &= nativevalue_to_se(cobj->OffsetY, jsret, s.thisObject() /*ctx*/);
    s.rval() = jsret;
    SE_HOLD_RETURN_VALUE(cobj->OffsetY, s.thisObject(), s.rval());
    return true;
}
SE_BIND_PROP_GET(js_effekseer_FlipbookParametersEx_get_OffsetY)

static bool js_effekseer_FlipbookParametersEx_set_OffsetY(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    auto* cobj = SE_THIS_OBJECT<cce::FlipbookParametersEx>(s);
    SE_PRECONDITION2(cobj, false, "Invalid Native Object");

    CC_UNUSED bool ok = true;
    ok &= sevalue_to_native(args[0], &cobj->OffsetY, s.thisObject());
    SE_PRECONDITION2(ok, false, "Error processing new value");
    return true;
}
SE_BIND_PROP_SET(js_effekseer_FlipbookParametersEx_set_OffsetY)


template<>
bool sevalue_to_native(const se::Value &from, cce::FlipbookParametersEx * to, se::Object *ctx)
{
    assert(from.isObject());
    se::Object *json = from.toObject();
    auto* data = reinterpret_cast<cce::FlipbookParametersEx*>(json->getPrivateData());
    if (data) {
        *to = *data;
        return true;
    }
    se::Value field;
    bool ok = true;
    json->getProperty("Enable", &field, true);
    if(!field.isNullOrUndefined()) {
        ok &= sevalue_to_native(field, &(to->Enable), ctx);
    }
    json->getProperty("LoopType", &field, true);
    if(!field.isNullOrUndefined()) {
        ok &= sevalue_to_native(field, &(to->LoopType), ctx);
    }
    json->getProperty("DivideX", &field, true);
    if(!field.isNullOrUndefined()) {
        ok &= sevalue_to_native(field, &(to->DivideX), ctx);
    }
    json->getProperty("DivideY", &field, true);
    if(!field.isNullOrUndefined()) {
        ok &= sevalue_to_native(field, &(to->DivideY), ctx);
    }
    json->getProperty("OneSizeX", &field, true);
    if(!field.isNullOrUndefined()) {
        ok &= sevalue_to_native(field, &(to->OneSizeX), ctx);
    }
    json->getProperty("OneSizeY", &field, true);
    if(!field.isNullOrUndefined()) {
        ok &= sevalue_to_native(field, &(to->OneSizeY), ctx);
    }
    json->getProperty("OffsetX", &field, true);
    if(!field.isNullOrUndefined()) {
        ok &= sevalue_to_native(field, &(to->OffsetX), ctx);
    }
    json->getProperty("OffsetY", &field, true);
    if(!field.isNullOrUndefined()) {
        ok &= sevalue_to_native(field, &(to->OffsetY), ctx);
    }
    return ok;
}

SE_DECLARE_FINALIZE_FUNC(js_cce_FlipbookParametersEx_finalize)

static bool js_effekseer_FlipbookParametersEx_constructor(se::State& s) // NOLINT(readability-identifier-naming)
{
    CC_UNUSED bool ok = true;
    const auto& args = s.args();
    size_t argc = args.size();

    if(argc == 0)
    {
        auto *ptr = JSB_MAKE_PRIVATE_OBJECT(cce::FlipbookParametersEx);
        s.thisObject()->setPrivateObject(ptr);
        return true;
    }

    if(argc == 1 && args[0].isObject())
    {
        se::Object *json = args[0].toObject();
        se::Value field;
        auto *ptr = JSB_MAKE_PRIVATE_OBJECT(cce::FlipbookParametersEx);
        auto cobj = ptr->get<cce::FlipbookParametersEx>();
        ok &= sevalue_to_native(args[0], cobj, s.thisObject());
        if(!ok) {
            delete ptr;
            SE_REPORT_ERROR("argument convertion error");
            return false;
        }
        s.thisObject()->setPrivateObject(ptr);
        return true;
    }
    auto *ptr = JSB_MAKE_PRIVATE_OBJECT(cce::FlipbookParametersEx);
    auto cobj = ptr->get<cce::FlipbookParametersEx>();
    if (argc > 0 && !args[0].isUndefined()) {
        ok &= sevalue_to_native(args[0], &(cobj->Enable), nullptr);
    }
    if (argc > 1 && !args[1].isUndefined()) {
        ok &= sevalue_to_native(args[1], &(cobj->LoopType), nullptr);
    }
    if (argc > 2 && !args[2].isUndefined()) {
        ok &= sevalue_to_native(args[2], &(cobj->DivideX), nullptr);
    }
    if (argc > 3 && !args[3].isUndefined()) {
        ok &= sevalue_to_native(args[3], &(cobj->DivideY), nullptr);
    }
    if (argc > 4 && !args[4].isUndefined()) {
        ok &= sevalue_to_native(args[4], &(cobj->OneSizeX), nullptr);
    }
    if (argc > 5 && !args[5].isUndefined()) {
        ok &= sevalue_to_native(args[5], &(cobj->OneSizeY), nullptr);
    }
    if (argc > 6 && !args[6].isUndefined()) {
        ok &= sevalue_to_native(args[6], &(cobj->OffsetX), nullptr);
    }
    if (argc > 7 && !args[7].isUndefined()) {
        ok &= sevalue_to_native(args[7], &(cobj->OffsetY), nullptr);
    }

    if(!ok) {
        delete ptr;
        SE_REPORT_ERROR("Argument convertion error");
        return false;
    }
    s.thisObject()->setPrivateObject(ptr);
    return true;
}
SE_BIND_CTOR(js_effekseer_FlipbookParametersEx_constructor, __jsb_cce_FlipbookParametersEx_class, js_cce_FlipbookParametersEx_finalize)

static bool js_cce_FlipbookParametersEx_finalize(se::State& s) // NOLINT(readability-identifier-naming)
{
    return true;
}
SE_BIND_FINALIZE_FUNC(js_cce_FlipbookParametersEx_finalize)

bool js_register_effekseer_FlipbookParametersEx(se::Object* obj) // NOLINT(readability-identifier-naming)
{
    auto* cls = se::Class::create("FlipbookParametersEx", obj, nullptr, _SE(js_effekseer_FlipbookParametersEx_constructor));

#if CC_DEBUG
    cls->defineStaticProperty("isJSBClass", _SE(js_effekseer_getter_return_true), nullptr);
#endif
    cls->defineProperty("Enable", _SE(js_effekseer_FlipbookParametersEx_get_Enable), _SE(js_effekseer_FlipbookParametersEx_set_Enable));
    cls->defineProperty("LoopType", _SE(js_effekseer_FlipbookParametersEx_get_LoopType), _SE(js_effekseer_FlipbookParametersEx_set_LoopType));
    cls->defineProperty("DivideX", _SE(js_effekseer_FlipbookParametersEx_get_DivideX), _SE(js_effekseer_FlipbookParametersEx_set_DivideX));
    cls->defineProperty("DivideY", _SE(js_effekseer_FlipbookParametersEx_get_DivideY), _SE(js_effekseer_FlipbookParametersEx_set_DivideY));
    cls->defineProperty("OneSizeX", _SE(js_effekseer_FlipbookParametersEx_get_OneSizeX), _SE(js_effekseer_FlipbookParametersEx_set_OneSizeX));
    cls->defineProperty("OneSizeY", _SE(js_effekseer_FlipbookParametersEx_get_OneSizeY), _SE(js_effekseer_FlipbookParametersEx_set_OneSizeY));
    cls->defineProperty("OffsetX", _SE(js_effekseer_FlipbookParametersEx_get_OffsetX), _SE(js_effekseer_FlipbookParametersEx_set_OffsetX));
    cls->defineProperty("OffsetY", _SE(js_effekseer_FlipbookParametersEx_get_OffsetY), _SE(js_effekseer_FlipbookParametersEx_set_OffsetY));
    cls->defineFinalizeFunction(_SE(js_cce_FlipbookParametersEx_finalize));
    cls->install();
    JSBClassType::registerClass<cce::FlipbookParametersEx>(cls);

    __jsb_cce_FlipbookParametersEx_proto = cls->getProto();
    __jsb_cce_FlipbookParametersEx_class = cls;


    se::ScriptEngine::getInstance()->clearException();
    return true;
}
se::Object* __jsb_cce_EdgeParametersEx_proto = nullptr; // NOLINT
se::Class* __jsb_cce_EdgeParametersEx_class = nullptr;  // NOLINT

static bool js_effekseer_EdgeParametersEx_get_Color(se::State& s) // NOLINT(readability-identifier-naming)
{
    auto* cobj = SE_THIS_OBJECT<cce::EdgeParametersEx>(s);
    // SE_PRECONDITION2(cobj, false, "Invalid Native Object");
    if (nullptr == cobj) return true;

    CC_UNUSED bool ok = true;
    se::Value jsret;
    ok &= nativevalue_to_se(cobj->Color, jsret, s.thisObject() /*ctx*/);
    s.rval() = jsret;
    SE_HOLD_RETURN_VALUE(cobj->Color, s.thisObject(), s.rval());
    return true;
}
SE_BIND_PROP_GET(js_effekseer_EdgeParametersEx_get_Color)

static bool js_effekseer_EdgeParametersEx_set_Color(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    auto* cobj = SE_THIS_OBJECT<cce::EdgeParametersEx>(s);
    SE_PRECONDITION2(cobj, false, "Invalid Native Object");

    CC_UNUSED bool ok = true;
    ok &= sevalue_to_native(args[0], &cobj->Color, s.thisObject());
    SE_PRECONDITION2(ok, false, "Error processing new value");
    return true;
}
SE_BIND_PROP_SET(js_effekseer_EdgeParametersEx_set_Color)

static bool js_effekseer_EdgeParametersEx_get_Threshold(se::State& s) // NOLINT(readability-identifier-naming)
{
    auto* cobj = SE_THIS_OBJECT<cce::EdgeParametersEx>(s);
    // SE_PRECONDITION2(cobj, false, "Invalid Native Object");
    if (nullptr == cobj) return true;

    CC_UNUSED bool ok = true;
    se::Value jsret;
    ok &= nativevalue_to_se(cobj->Threshold, jsret, s.thisObject() /*ctx*/);
    s.rval() = jsret;
    SE_HOLD_RETURN_VALUE(cobj->Threshold, s.thisObject(), s.rval());
    return true;
}
SE_BIND_PROP_GET(js_effekseer_EdgeParametersEx_get_Threshold)

static bool js_effekseer_EdgeParametersEx_set_Threshold(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    auto* cobj = SE_THIS_OBJECT<cce::EdgeParametersEx>(s);
    SE_PRECONDITION2(cobj, false, "Invalid Native Object");

    CC_UNUSED bool ok = true;
    ok &= sevalue_to_native(args[0], &cobj->Threshold, s.thisObject());
    SE_PRECONDITION2(ok, false, "Error processing new value");
    return true;
}
SE_BIND_PROP_SET(js_effekseer_EdgeParametersEx_set_Threshold)

static bool js_effekseer_EdgeParametersEx_get_ColorScaling(se::State& s) // NOLINT(readability-identifier-naming)
{
    auto* cobj = SE_THIS_OBJECT<cce::EdgeParametersEx>(s);
    // SE_PRECONDITION2(cobj, false, "Invalid Native Object");
    if (nullptr == cobj) return true;

    CC_UNUSED bool ok = true;
    se::Value jsret;
    ok &= nativevalue_to_se(cobj->ColorScaling, jsret, s.thisObject() /*ctx*/);
    s.rval() = jsret;
    SE_HOLD_RETURN_VALUE(cobj->ColorScaling, s.thisObject(), s.rval());
    return true;
}
SE_BIND_PROP_GET(js_effekseer_EdgeParametersEx_get_ColorScaling)

static bool js_effekseer_EdgeParametersEx_set_ColorScaling(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    auto* cobj = SE_THIS_OBJECT<cce::EdgeParametersEx>(s);
    SE_PRECONDITION2(cobj, false, "Invalid Native Object");

    CC_UNUSED bool ok = true;
    ok &= sevalue_to_native(args[0], &cobj->ColorScaling, s.thisObject());
    SE_PRECONDITION2(ok, false, "Error processing new value");
    return true;
}
SE_BIND_PROP_SET(js_effekseer_EdgeParametersEx_set_ColorScaling)


template<>
bool sevalue_to_native(const se::Value &from, cce::EdgeParametersEx * to, se::Object *ctx)
{
    assert(from.isObject());
    se::Object *json = from.toObject();
    auto* data = reinterpret_cast<cce::EdgeParametersEx*>(json->getPrivateData());
    if (data) {
        *to = *data;
        return true;
    }
    se::Value field;
    bool ok = true;
    json->getProperty("Color", &field, true);
    if(!field.isNullOrUndefined()) {
        ok &= sevalue_to_native(field, &(to->Color), ctx);
    }
    json->getProperty("Threshold", &field, true);
    if(!field.isNullOrUndefined()) {
        ok &= sevalue_to_native(field, &(to->Threshold), ctx);
    }
    json->getProperty("ColorScaling", &field, true);
    if(!field.isNullOrUndefined()) {
        ok &= sevalue_to_native(field, &(to->ColorScaling), ctx);
    }
    return ok;
}

SE_DECLARE_FINALIZE_FUNC(js_cce_EdgeParametersEx_finalize)

static bool js_effekseer_EdgeParametersEx_constructor(se::State& s) // NOLINT(readability-identifier-naming)
{
    CC_UNUSED bool ok = true;
    const auto& args = s.args();
    size_t argc = args.size();

    if(argc == 0)
    {
        auto *ptr = JSB_MAKE_PRIVATE_OBJECT(cce::EdgeParametersEx);
        s.thisObject()->setPrivateObject(ptr);
        return true;
    }

    if(argc == 1 && args[0].isObject())
    {
        se::Object *json = args[0].toObject();
        se::Value field;
        auto *ptr = JSB_MAKE_PRIVATE_OBJECT(cce::EdgeParametersEx);
        auto cobj = ptr->get<cce::EdgeParametersEx>();
        ok &= sevalue_to_native(args[0], cobj, s.thisObject());
        if(!ok) {
            delete ptr;
            SE_REPORT_ERROR("argument convertion error");
            return false;
        }
        s.thisObject()->setPrivateObject(ptr);
        return true;
    }
    auto *ptr = JSB_MAKE_PRIVATE_OBJECT(cce::EdgeParametersEx);
    auto cobj = ptr->get<cce::EdgeParametersEx>();
    if (argc > 0 && !args[0].isUndefined()) {
        ok &= sevalue_to_native(args[0], &(cobj->Color), nullptr);
    }
    if (argc > 1 && !args[1].isUndefined()) {
        ok &= sevalue_to_native(args[1], &(cobj->Threshold), nullptr);
    }
    if (argc > 2 && !args[2].isUndefined()) {
        ok &= sevalue_to_native(args[2], &(cobj->ColorScaling), nullptr);
    }

    if(!ok) {
        delete ptr;
        SE_REPORT_ERROR("Argument convertion error");
        return false;
    }
    s.thisObject()->setPrivateObject(ptr);
    return true;
}
SE_BIND_CTOR(js_effekseer_EdgeParametersEx_constructor, __jsb_cce_EdgeParametersEx_class, js_cce_EdgeParametersEx_finalize)

static bool js_cce_EdgeParametersEx_finalize(se::State& s) // NOLINT(readability-identifier-naming)
{
    return true;
}
SE_BIND_FINALIZE_FUNC(js_cce_EdgeParametersEx_finalize)

bool js_register_effekseer_EdgeParametersEx(se::Object* obj) // NOLINT(readability-identifier-naming)
{
    auto* cls = se::Class::create("EdgeParametersEx", obj, nullptr, _SE(js_effekseer_EdgeParametersEx_constructor));

#if CC_DEBUG
    cls->defineStaticProperty("isJSBClass", _SE(js_effekseer_getter_return_true), nullptr);
#endif
    cls->defineProperty("Color", _SE(js_effekseer_EdgeParametersEx_get_Color), _SE(js_effekseer_EdgeParametersEx_set_Color));
    cls->defineProperty("Threshold", _SE(js_effekseer_EdgeParametersEx_get_Threshold), _SE(js_effekseer_EdgeParametersEx_set_Threshold));
    cls->defineProperty("ColorScaling", _SE(js_effekseer_EdgeParametersEx_get_ColorScaling), _SE(js_effekseer_EdgeParametersEx_set_ColorScaling));
    cls->defineFinalizeFunction(_SE(js_cce_EdgeParametersEx_finalize));
    cls->install();
    JSBClassType::registerClass<cce::EdgeParametersEx>(cls);

    __jsb_cce_EdgeParametersEx_proto = cls->getProto();
    __jsb_cce_EdgeParametersEx_class = cls;


    se::ScriptEngine::getInstance()->clearException();
    return true;
}
se::Object* __jsb_cce_FalloffParameterEx_proto = nullptr; // NOLINT
se::Class* __jsb_cce_FalloffParameterEx_class = nullptr;  // NOLINT

static bool js_effekseer_FalloffParameterEx_get_ColorBlendType(se::State& s) // NOLINT(readability-identifier-naming)
{
    auto* cobj = SE_THIS_OBJECT<cce::FalloffParameterEx>(s);
    // SE_PRECONDITION2(cobj, false, "Invalid Native Object");
    if (nullptr == cobj) return true;

    CC_UNUSED bool ok = true;
    se::Value jsret;
    ok &= nativevalue_to_se(cobj->ColorBlendType, jsret, s.thisObject() /*ctx*/);
    s.rval() = jsret;
    SE_HOLD_RETURN_VALUE(cobj->ColorBlendType, s.thisObject(), s.rval());
    return true;
}
SE_BIND_PROP_GET(js_effekseer_FalloffParameterEx_get_ColorBlendType)

static bool js_effekseer_FalloffParameterEx_set_ColorBlendType(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    auto* cobj = SE_THIS_OBJECT<cce::FalloffParameterEx>(s);
    SE_PRECONDITION2(cobj, false, "Invalid Native Object");

    CC_UNUSED bool ok = true;
    ok &= sevalue_to_native(args[0], &cobj->ColorBlendType, s.thisObject());
    SE_PRECONDITION2(ok, false, "Error processing new value");
    return true;
}
SE_BIND_PROP_SET(js_effekseer_FalloffParameterEx_set_ColorBlendType)

static bool js_effekseer_FalloffParameterEx_get_BeginColor(se::State& s) // NOLINT(readability-identifier-naming)
{
    auto* cobj = SE_THIS_OBJECT<cce::FalloffParameterEx>(s);
    // SE_PRECONDITION2(cobj, false, "Invalid Native Object");
    if (nullptr == cobj) return true;

    CC_UNUSED bool ok = true;
    se::Value jsret;
    ok &= nativevalue_to_se(cobj->BeginColor, jsret, s.thisObject() /*ctx*/);
    s.rval() = jsret;
    SE_HOLD_RETURN_VALUE(cobj->BeginColor, s.thisObject(), s.rval());
    return true;
}
SE_BIND_PROP_GET(js_effekseer_FalloffParameterEx_get_BeginColor)

static bool js_effekseer_FalloffParameterEx_set_BeginColor(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    auto* cobj = SE_THIS_OBJECT<cce::FalloffParameterEx>(s);
    SE_PRECONDITION2(cobj, false, "Invalid Native Object");

    CC_UNUSED bool ok = true;
    ok &= sevalue_to_native(args[0], &cobj->BeginColor, s.thisObject());
    SE_PRECONDITION2(ok, false, "Error processing new value");
    return true;
}
SE_BIND_PROP_SET(js_effekseer_FalloffParameterEx_set_BeginColor)

static bool js_effekseer_FalloffParameterEx_get_EndColor(se::State& s) // NOLINT(readability-identifier-naming)
{
    auto* cobj = SE_THIS_OBJECT<cce::FalloffParameterEx>(s);
    // SE_PRECONDITION2(cobj, false, "Invalid Native Object");
    if (nullptr == cobj) return true;

    CC_UNUSED bool ok = true;
    se::Value jsret;
    ok &= nativevalue_to_se(cobj->EndColor, jsret, s.thisObject() /*ctx*/);
    s.rval() = jsret;
    SE_HOLD_RETURN_VALUE(cobj->EndColor, s.thisObject(), s.rval());
    return true;
}
SE_BIND_PROP_GET(js_effekseer_FalloffParameterEx_get_EndColor)

static bool js_effekseer_FalloffParameterEx_set_EndColor(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    auto* cobj = SE_THIS_OBJECT<cce::FalloffParameterEx>(s);
    SE_PRECONDITION2(cobj, false, "Invalid Native Object");

    CC_UNUSED bool ok = true;
    ok &= sevalue_to_native(args[0], &cobj->EndColor, s.thisObject());
    SE_PRECONDITION2(ok, false, "Error processing new value");
    return true;
}
SE_BIND_PROP_SET(js_effekseer_FalloffParameterEx_set_EndColor)

static bool js_effekseer_FalloffParameterEx_get_Pow(se::State& s) // NOLINT(readability-identifier-naming)
{
    auto* cobj = SE_THIS_OBJECT<cce::FalloffParameterEx>(s);
    // SE_PRECONDITION2(cobj, false, "Invalid Native Object");
    if (nullptr == cobj) return true;

    CC_UNUSED bool ok = true;
    se::Value jsret;
    ok &= nativevalue_to_se(cobj->Pow, jsret, s.thisObject() /*ctx*/);
    s.rval() = jsret;
    SE_HOLD_RETURN_VALUE(cobj->Pow, s.thisObject(), s.rval());
    return true;
}
SE_BIND_PROP_GET(js_effekseer_FalloffParameterEx_get_Pow)

static bool js_effekseer_FalloffParameterEx_set_Pow(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    auto* cobj = SE_THIS_OBJECT<cce::FalloffParameterEx>(s);
    SE_PRECONDITION2(cobj, false, "Invalid Native Object");

    CC_UNUSED bool ok = true;
    ok &= sevalue_to_native(args[0], &cobj->Pow, s.thisObject());
    SE_PRECONDITION2(ok, false, "Error processing new value");
    return true;
}
SE_BIND_PROP_SET(js_effekseer_FalloffParameterEx_set_Pow)


template<>
bool sevalue_to_native(const se::Value &from, cce::FalloffParameterEx * to, se::Object *ctx)
{
    assert(from.isObject());
    se::Object *json = from.toObject();
    auto* data = reinterpret_cast<cce::FalloffParameterEx*>(json->getPrivateData());
    if (data) {
        *to = *data;
        return true;
    }
    se::Value field;
    bool ok = true;
    json->getProperty("ColorBlendType", &field, true);
    if(!field.isNullOrUndefined()) {
        ok &= sevalue_to_native(field, &(to->ColorBlendType), ctx);
    }
    json->getProperty("BeginColor", &field, true);
    if(!field.isNullOrUndefined()) {
        ok &= sevalue_to_native(field, &(to->BeginColor), ctx);
    }
    json->getProperty("EndColor", &field, true);
    if(!field.isNullOrUndefined()) {
        ok &= sevalue_to_native(field, &(to->EndColor), ctx);
    }
    json->getProperty("Pow", &field, true);
    if(!field.isNullOrUndefined()) {
        ok &= sevalue_to_native(field, &(to->Pow), ctx);
    }
    return ok;
}

SE_DECLARE_FINALIZE_FUNC(js_cce_FalloffParameterEx_finalize)

static bool js_effekseer_FalloffParameterEx_constructor(se::State& s) // NOLINT(readability-identifier-naming)
{
    CC_UNUSED bool ok = true;
    const auto& args = s.args();
    size_t argc = args.size();

    if(argc == 0)
    {
        auto *ptr = JSB_MAKE_PRIVATE_OBJECT(cce::FalloffParameterEx);
        s.thisObject()->setPrivateObject(ptr);
        return true;
    }

    if(argc == 1 && args[0].isObject())
    {
        se::Object *json = args[0].toObject();
        se::Value field;
        auto *ptr = JSB_MAKE_PRIVATE_OBJECT(cce::FalloffParameterEx);
        auto cobj = ptr->get<cce::FalloffParameterEx>();
        ok &= sevalue_to_native(args[0], cobj, s.thisObject());
        if(!ok) {
            delete ptr;
            SE_REPORT_ERROR("argument convertion error");
            return false;
        }
        s.thisObject()->setPrivateObject(ptr);
        return true;
    }
    auto *ptr = JSB_MAKE_PRIVATE_OBJECT(cce::FalloffParameterEx);
    auto cobj = ptr->get<cce::FalloffParameterEx>();
    if (argc > 0 && !args[0].isUndefined()) {
        ok &= sevalue_to_native(args[0], &(cobj->ColorBlendType), nullptr);
    }
    if (argc > 1 && !args[1].isUndefined()) {
        ok &= sevalue_to_native(args[1], &(cobj->BeginColor), nullptr);
    }
    if (argc > 2 && !args[2].isUndefined()) {
        ok &= sevalue_to_native(args[2], &(cobj->EndColor), nullptr);
    }
    if (argc > 3 && !args[3].isUndefined()) {
        ok &= sevalue_to_native(args[3], &(cobj->Pow), nullptr);
    }

    if(!ok) {
        delete ptr;
        SE_REPORT_ERROR("Argument convertion error");
        return false;
    }
    s.thisObject()->setPrivateObject(ptr);
    return true;
}
SE_BIND_CTOR(js_effekseer_FalloffParameterEx_constructor, __jsb_cce_FalloffParameterEx_class, js_cce_FalloffParameterEx_finalize)

static bool js_cce_FalloffParameterEx_finalize(se::State& s) // NOLINT(readability-identifier-naming)
{
    return true;
}
SE_BIND_FINALIZE_FUNC(js_cce_FalloffParameterEx_finalize)

bool js_register_effekseer_FalloffParameterEx(se::Object* obj) // NOLINT(readability-identifier-naming)
{
    auto* cls = se::Class::create("FalloffParameterEx", obj, nullptr, _SE(js_effekseer_FalloffParameterEx_constructor));

#if CC_DEBUG
    cls->defineStaticProperty("isJSBClass", _SE(js_effekseer_getter_return_true), nullptr);
#endif
    cls->defineProperty("ColorBlendType", _SE(js_effekseer_FalloffParameterEx_get_ColorBlendType), _SE(js_effekseer_FalloffParameterEx_set_ColorBlendType));
    cls->defineProperty("BeginColor", _SE(js_effekseer_FalloffParameterEx_get_BeginColor), _SE(js_effekseer_FalloffParameterEx_set_BeginColor));
    cls->defineProperty("EndColor", _SE(js_effekseer_FalloffParameterEx_get_EndColor), _SE(js_effekseer_FalloffParameterEx_set_EndColor));
    cls->defineProperty("Pow", _SE(js_effekseer_FalloffParameterEx_get_Pow), _SE(js_effekseer_FalloffParameterEx_set_Pow));
    cls->defineFinalizeFunction(_SE(js_cce_FalloffParameterEx_finalize));
    cls->install();
    JSBClassType::registerClass<cce::FalloffParameterEx>(cls);

    __jsb_cce_FalloffParameterEx_proto = cls->getProto();
    __jsb_cce_FalloffParameterEx_class = cls;


    se::ScriptEngine::getInstance()->clearException();
    return true;
}
se::Object* __jsb_cce_RenderParameter_proto = nullptr; // NOLINT
se::Class* __jsb_cce_RenderParameter_class = nullptr;  // NOLINT

static bool js_effekseer_RenderParameter_getEdgeParams(se::State& s) // NOLINT(readability-identifier-naming)
{
    auto* cobj = SE_THIS_OBJECT<cce::RenderParameter>(s);
    // SE_PRECONDITION2(cobj, false, "Invalid Native Object");
    if (nullptr == cobj) return true;
    const auto& args = s.args();
    size_t argc = args.size();
    CC_UNUSED bool ok = true;
    if (argc == 0) {
        cce::EdgeParametersEx* result = cobj->getEdgeParams();
        ok &= nativevalue_to_se(result, s.rval(), nullptr /*ctx*/);
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        SE_HOLD_RETURN_VALUE(result, s.thisObject(), s.rval());
        return true;
    }
    SE_REPORT_ERROR("wrong number of arguments: %d, was expecting %d", (int)argc, 0);
    return false;
}
SE_BIND_FUNC(js_effekseer_RenderParameter_getEdgeParams)

static bool js_effekseer_RenderParameter_getFalloffParam(se::State& s) // NOLINT(readability-identifier-naming)
{
    auto* cobj = SE_THIS_OBJECT<cce::RenderParameter>(s);
    // SE_PRECONDITION2(cobj, false, "Invalid Native Object");
    if (nullptr == cobj) return true;
    const auto& args = s.args();
    size_t argc = args.size();
    CC_UNUSED bool ok = true;
    if (argc == 0) {
        cce::FalloffParameterEx* result = cobj->getFalloffParam();
        ok &= nativevalue_to_se(result, s.rval(), nullptr /*ctx*/);
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        SE_HOLD_RETURN_VALUE(result, s.thisObject(), s.rval());
        return true;
    }
    SE_REPORT_ERROR("wrong number of arguments: %d, was expecting %d", (int)argc, 0);
    return false;
}
SE_BIND_FUNC(js_effekseer_RenderParameter_getFalloffParam)

static bool js_effekseer_RenderParameter_getFlipbookParams(se::State& s) // NOLINT(readability-identifier-naming)
{
    auto* cobj = SE_THIS_OBJECT<cce::RenderParameter>(s);
    // SE_PRECONDITION2(cobj, false, "Invalid Native Object");
    if (nullptr == cobj) return true;
    const auto& args = s.args();
    size_t argc = args.size();
    CC_UNUSED bool ok = true;
    if (argc == 0) {
        cce::FlipbookParametersEx* result = cobj->getFlipbookParams();
        ok &= nativevalue_to_se(result, s.rval(), nullptr /*ctx*/);
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        SE_HOLD_RETURN_VALUE(result, s.thisObject(), s.rval());
        return true;
    }
    SE_REPORT_ERROR("wrong number of arguments: %d, was expecting %d", (int)argc, 0);
    return false;
}
SE_BIND_FUNC(js_effekseer_RenderParameter_getFlipbookParams)

static bool js_effekseer_RenderParameter_get_RenderMode(se::State& s) // NOLINT(readability-identifier-naming)
{
    auto* cobj = SE_THIS_OBJECT<cce::RenderParameter>(s);
    // SE_PRECONDITION2(cobj, false, "Invalid Native Object");
    if (nullptr == cobj) return true;

    CC_UNUSED bool ok = true;
    se::Value jsret;
    ok &= nativevalue_to_se(cobj->RenderMode, jsret, s.thisObject() /*ctx*/);
    s.rval() = jsret;
    SE_HOLD_RETURN_VALUE(cobj->RenderMode, s.thisObject(), s.rval());
    return true;
}
SE_BIND_PROP_GET(js_effekseer_RenderParameter_get_RenderMode)

static bool js_effekseer_RenderParameter_set_RenderMode(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    auto* cobj = SE_THIS_OBJECT<cce::RenderParameter>(s);
    SE_PRECONDITION2(cobj, false, "Invalid Native Object");

    CC_UNUSED bool ok = true;
    ok &= sevalue_to_native(args[0], &cobj->RenderMode, s.thisObject());
    SE_PRECONDITION2(ok, false, "Error processing new value");
    return true;
}
SE_BIND_PROP_SET(js_effekseer_RenderParameter_set_RenderMode)

static bool js_effekseer_RenderParameter_get_MaterialType(se::State& s) // NOLINT(readability-identifier-naming)
{
    auto* cobj = SE_THIS_OBJECT<cce::RenderParameter>(s);
    // SE_PRECONDITION2(cobj, false, "Invalid Native Object");
    if (nullptr == cobj) return true;

    CC_UNUSED bool ok = true;
    se::Value jsret;
    ok &= nativevalue_to_se(cobj->MaterialType, jsret, s.thisObject() /*ctx*/);
    s.rval() = jsret;
    SE_HOLD_RETURN_VALUE(cobj->MaterialType, s.thisObject(), s.rval());
    return true;
}
SE_BIND_PROP_GET(js_effekseer_RenderParameter_get_MaterialType)

static bool js_effekseer_RenderParameter_set_MaterialType(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    auto* cobj = SE_THIS_OBJECT<cce::RenderParameter>(s);
    SE_PRECONDITION2(cobj, false, "Invalid Native Object");

    CC_UNUSED bool ok = true;
    ok &= sevalue_to_native(args[0], &cobj->MaterialType, s.thisObject());
    SE_PRECONDITION2(ok, false, "Error processing new value");
    return true;
}
SE_BIND_PROP_SET(js_effekseer_RenderParameter_set_MaterialType)

static bool js_effekseer_RenderParameter_get_VertexBufferOffset(se::State& s) // NOLINT(readability-identifier-naming)
{
    auto* cobj = SE_THIS_OBJECT<cce::RenderParameter>(s);
    // SE_PRECONDITION2(cobj, false, "Invalid Native Object");
    if (nullptr == cobj) return true;

    CC_UNUSED bool ok = true;
    se::Value jsret;
    ok &= nativevalue_to_se(cobj->VertexBufferOffset, jsret, s.thisObject() /*ctx*/);
    s.rval() = jsret;
    SE_HOLD_RETURN_VALUE(cobj->VertexBufferOffset, s.thisObject(), s.rval());
    return true;
}
SE_BIND_PROP_GET(js_effekseer_RenderParameter_get_VertexBufferOffset)

static bool js_effekseer_RenderParameter_set_VertexBufferOffset(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    auto* cobj = SE_THIS_OBJECT<cce::RenderParameter>(s);
    SE_PRECONDITION2(cobj, false, "Invalid Native Object");

    CC_UNUSED bool ok = true;
    ok &= sevalue_to_native(args[0], &cobj->VertexBufferOffset, s.thisObject());
    SE_PRECONDITION2(ok, false, "Error processing new value");
    return true;
}
SE_BIND_PROP_SET(js_effekseer_RenderParameter_set_VertexBufferOffset)

static bool js_effekseer_RenderParameter_get_AdvancedBufferOffset(se::State& s) // NOLINT(readability-identifier-naming)
{
    auto* cobj = SE_THIS_OBJECT<cce::RenderParameter>(s);
    // SE_PRECONDITION2(cobj, false, "Invalid Native Object");
    if (nullptr == cobj) return true;

    CC_UNUSED bool ok = true;
    se::Value jsret;
    ok &= nativevalue_to_se(cobj->AdvancedBufferOffset, jsret, s.thisObject() /*ctx*/);
    s.rval() = jsret;
    SE_HOLD_RETURN_VALUE(cobj->AdvancedBufferOffset, s.thisObject(), s.rval());
    return true;
}
SE_BIND_PROP_GET(js_effekseer_RenderParameter_get_AdvancedBufferOffset)

static bool js_effekseer_RenderParameter_set_AdvancedBufferOffset(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    auto* cobj = SE_THIS_OBJECT<cce::RenderParameter>(s);
    SE_PRECONDITION2(cobj, false, "Invalid Native Object");

    CC_UNUSED bool ok = true;
    ok &= sevalue_to_native(args[0], &cobj->AdvancedBufferOffset, s.thisObject());
    SE_PRECONDITION2(ok, false, "Error processing new value");
    return true;
}
SE_BIND_PROP_SET(js_effekseer_RenderParameter_set_AdvancedBufferOffset)

static bool js_effekseer_RenderParameter_get_VertexBufferStride(se::State& s) // NOLINT(readability-identifier-naming)
{
    auto* cobj = SE_THIS_OBJECT<cce::RenderParameter>(s);
    // SE_PRECONDITION2(cobj, false, "Invalid Native Object");
    if (nullptr == cobj) return true;

    CC_UNUSED bool ok = true;
    se::Value jsret;
    ok &= nativevalue_to_se(cobj->VertexBufferStride, jsret, s.thisObject() /*ctx*/);
    s.rval() = jsret;
    SE_HOLD_RETURN_VALUE(cobj->VertexBufferStride, s.thisObject(), s.rval());
    return true;
}
SE_BIND_PROP_GET(js_effekseer_RenderParameter_get_VertexBufferStride)

static bool js_effekseer_RenderParameter_set_VertexBufferStride(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    auto* cobj = SE_THIS_OBJECT<cce::RenderParameter>(s);
    SE_PRECONDITION2(cobj, false, "Invalid Native Object");

    CC_UNUSED bool ok = true;
    ok &= sevalue_to_native(args[0], &cobj->VertexBufferStride, s.thisObject());
    SE_PRECONDITION2(ok, false, "Error processing new value");
    return true;
}
SE_BIND_PROP_SET(js_effekseer_RenderParameter_set_VertexBufferStride)

static bool js_effekseer_RenderParameter_get_CustomData1BufferOffset(se::State& s) // NOLINT(readability-identifier-naming)
{
    auto* cobj = SE_THIS_OBJECT<cce::RenderParameter>(s);
    // SE_PRECONDITION2(cobj, false, "Invalid Native Object");
    if (nullptr == cobj) return true;

    CC_UNUSED bool ok = true;
    se::Value jsret;
    ok &= nativevalue_to_se(cobj->CustomData1BufferOffset, jsret, s.thisObject() /*ctx*/);
    s.rval() = jsret;
    SE_HOLD_RETURN_VALUE(cobj->CustomData1BufferOffset, s.thisObject(), s.rval());
    return true;
}
SE_BIND_PROP_GET(js_effekseer_RenderParameter_get_CustomData1BufferOffset)

static bool js_effekseer_RenderParameter_set_CustomData1BufferOffset(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    auto* cobj = SE_THIS_OBJECT<cce::RenderParameter>(s);
    SE_PRECONDITION2(cobj, false, "Invalid Native Object");

    CC_UNUSED bool ok = true;
    ok &= sevalue_to_native(args[0], &cobj->CustomData1BufferOffset, s.thisObject());
    SE_PRECONDITION2(ok, false, "Error processing new value");
    return true;
}
SE_BIND_PROP_SET(js_effekseer_RenderParameter_set_CustomData1BufferOffset)

static bool js_effekseer_RenderParameter_get_CustomData2BufferOffset(se::State& s) // NOLINT(readability-identifier-naming)
{
    auto* cobj = SE_THIS_OBJECT<cce::RenderParameter>(s);
    // SE_PRECONDITION2(cobj, false, "Invalid Native Object");
    if (nullptr == cobj) return true;

    CC_UNUSED bool ok = true;
    se::Value jsret;
    ok &= nativevalue_to_se(cobj->CustomData2BufferOffset, jsret, s.thisObject() /*ctx*/);
    s.rval() = jsret;
    SE_HOLD_RETURN_VALUE(cobj->CustomData2BufferOffset, s.thisObject(), s.rval());
    return true;
}
SE_BIND_PROP_GET(js_effekseer_RenderParameter_get_CustomData2BufferOffset)

static bool js_effekseer_RenderParameter_set_CustomData2BufferOffset(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    auto* cobj = SE_THIS_OBJECT<cce::RenderParameter>(s);
    SE_PRECONDITION2(cobj, false, "Invalid Native Object");

    CC_UNUSED bool ok = true;
    ok &= sevalue_to_native(args[0], &cobj->CustomData2BufferOffset, s.thisObject());
    SE_PRECONDITION2(ok, false, "Error processing new value");
    return true;
}
SE_BIND_PROP_SET(js_effekseer_RenderParameter_set_CustomData2BufferOffset)

static bool js_effekseer_RenderParameter_get_UniformBufferOffset(se::State& s) // NOLINT(readability-identifier-naming)
{
    auto* cobj = SE_THIS_OBJECT<cce::RenderParameter>(s);
    // SE_PRECONDITION2(cobj, false, "Invalid Native Object");
    if (nullptr == cobj) return true;

    CC_UNUSED bool ok = true;
    se::Value jsret;
    ok &= nativevalue_to_se(cobj->UniformBufferOffset, jsret, s.thisObject() /*ctx*/);
    s.rval() = jsret;
    SE_HOLD_RETURN_VALUE(cobj->UniformBufferOffset, s.thisObject(), s.rval());
    return true;
}
SE_BIND_PROP_GET(js_effekseer_RenderParameter_get_UniformBufferOffset)

static bool js_effekseer_RenderParameter_set_UniformBufferOffset(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    auto* cobj = SE_THIS_OBJECT<cce::RenderParameter>(s);
    SE_PRECONDITION2(cobj, false, "Invalid Native Object");

    CC_UNUSED bool ok = true;
    ok &= sevalue_to_native(args[0], &cobj->UniformBufferOffset, s.thisObject());
    SE_PRECONDITION2(ok, false, "Error processing new value");
    return true;
}
SE_BIND_PROP_SET(js_effekseer_RenderParameter_set_UniformBufferOffset)

static bool js_effekseer_RenderParameter_get_ElementCount(se::State& s) // NOLINT(readability-identifier-naming)
{
    auto* cobj = SE_THIS_OBJECT<cce::RenderParameter>(s);
    // SE_PRECONDITION2(cobj, false, "Invalid Native Object");
    if (nullptr == cobj) return true;

    CC_UNUSED bool ok = true;
    se::Value jsret;
    ok &= nativevalue_to_se(cobj->ElementCount, jsret, s.thisObject() /*ctx*/);
    s.rval() = jsret;
    SE_HOLD_RETURN_VALUE(cobj->ElementCount, s.thisObject(), s.rval());
    return true;
}
SE_BIND_PROP_GET(js_effekseer_RenderParameter_get_ElementCount)

static bool js_effekseer_RenderParameter_set_ElementCount(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    auto* cobj = SE_THIS_OBJECT<cce::RenderParameter>(s);
    SE_PRECONDITION2(cobj, false, "Invalid Native Object");

    CC_UNUSED bool ok = true;
    ok &= sevalue_to_native(args[0], &cobj->ElementCount, s.thisObject());
    SE_PRECONDITION2(ok, false, "Error processing new value");
    return true;
}
SE_BIND_PROP_SET(js_effekseer_RenderParameter_set_ElementCount)

static bool js_effekseer_RenderParameter_get_UVDistortionIntensity(se::State& s) // NOLINT(readability-identifier-naming)
{
    auto* cobj = SE_THIS_OBJECT<cce::RenderParameter>(s);
    // SE_PRECONDITION2(cobj, false, "Invalid Native Object");
    if (nullptr == cobj) return true;

    CC_UNUSED bool ok = true;
    se::Value jsret;
    ok &= nativevalue_to_se(cobj->UVDistortionIntensity, jsret, s.thisObject() /*ctx*/);
    s.rval() = jsret;
    SE_HOLD_RETURN_VALUE(cobj->UVDistortionIntensity, s.thisObject(), s.rval());
    return true;
}
SE_BIND_PROP_GET(js_effekseer_RenderParameter_get_UVDistortionIntensity)

static bool js_effekseer_RenderParameter_set_UVDistortionIntensity(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    auto* cobj = SE_THIS_OBJECT<cce::RenderParameter>(s);
    SE_PRECONDITION2(cobj, false, "Invalid Native Object");

    CC_UNUSED bool ok = true;
    ok &= sevalue_to_native(args[0], &cobj->UVDistortionIntensity, s.thisObject());
    SE_PRECONDITION2(ok, false, "Error processing new value");
    return true;
}
SE_BIND_PROP_SET(js_effekseer_RenderParameter_set_UVDistortionIntensity)

static bool js_effekseer_RenderParameter_get_TextureBlendType(se::State& s) // NOLINT(readability-identifier-naming)
{
    auto* cobj = SE_THIS_OBJECT<cce::RenderParameter>(s);
    // SE_PRECONDITION2(cobj, false, "Invalid Native Object");
    if (nullptr == cobj) return true;

    CC_UNUSED bool ok = true;
    se::Value jsret;
    ok &= nativevalue_to_se(cobj->TextureBlendType, jsret, s.thisObject() /*ctx*/);
    s.rval() = jsret;
    SE_HOLD_RETURN_VALUE(cobj->TextureBlendType, s.thisObject(), s.rval());
    return true;
}
SE_BIND_PROP_GET(js_effekseer_RenderParameter_get_TextureBlendType)

static bool js_effekseer_RenderParameter_set_TextureBlendType(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    auto* cobj = SE_THIS_OBJECT<cce::RenderParameter>(s);
    SE_PRECONDITION2(cobj, false, "Invalid Native Object");

    CC_UNUSED bool ok = true;
    ok &= sevalue_to_native(args[0], &cobj->TextureBlendType, s.thisObject());
    SE_PRECONDITION2(ok, false, "Error processing new value");
    return true;
}
SE_BIND_PROP_SET(js_effekseer_RenderParameter_set_TextureBlendType)

static bool js_effekseer_RenderParameter_get_BlendUVDistortionIntensity(se::State& s) // NOLINT(readability-identifier-naming)
{
    auto* cobj = SE_THIS_OBJECT<cce::RenderParameter>(s);
    // SE_PRECONDITION2(cobj, false, "Invalid Native Object");
    if (nullptr == cobj) return true;

    CC_UNUSED bool ok = true;
    se::Value jsret;
    ok &= nativevalue_to_se(cobj->BlendUVDistortionIntensity, jsret, s.thisObject() /*ctx*/);
    s.rval() = jsret;
    SE_HOLD_RETURN_VALUE(cobj->BlendUVDistortionIntensity, s.thisObject(), s.rval());
    return true;
}
SE_BIND_PROP_GET(js_effekseer_RenderParameter_get_BlendUVDistortionIntensity)

static bool js_effekseer_RenderParameter_set_BlendUVDistortionIntensity(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    auto* cobj = SE_THIS_OBJECT<cce::RenderParameter>(s);
    SE_PRECONDITION2(cobj, false, "Invalid Native Object");

    CC_UNUSED bool ok = true;
    ok &= sevalue_to_native(args[0], &cobj->BlendUVDistortionIntensity, s.thisObject());
    SE_PRECONDITION2(ok, false, "Error processing new value");
    return true;
}
SE_BIND_PROP_SET(js_effekseer_RenderParameter_set_BlendUVDistortionIntensity)

static bool js_effekseer_RenderParameter_get_EnableFalloff(se::State& s) // NOLINT(readability-identifier-naming)
{
    auto* cobj = SE_THIS_OBJECT<cce::RenderParameter>(s);
    // SE_PRECONDITION2(cobj, false, "Invalid Native Object");
    if (nullptr == cobj) return true;

    CC_UNUSED bool ok = true;
    se::Value jsret;
    ok &= nativevalue_to_se(cobj->EnableFalloff, jsret, s.thisObject() /*ctx*/);
    s.rval() = jsret;
    SE_HOLD_RETURN_VALUE(cobj->EnableFalloff, s.thisObject(), s.rval());
    return true;
}
SE_BIND_PROP_GET(js_effekseer_RenderParameter_get_EnableFalloff)

static bool js_effekseer_RenderParameter_set_EnableFalloff(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    auto* cobj = SE_THIS_OBJECT<cce::RenderParameter>(s);
    SE_PRECONDITION2(cobj, false, "Invalid Native Object");

    CC_UNUSED bool ok = true;
    ok &= sevalue_to_native(args[0], &cobj->EnableFalloff, s.thisObject());
    SE_PRECONDITION2(ok, false, "Error processing new value");
    return true;
}
SE_BIND_PROP_SET(js_effekseer_RenderParameter_set_EnableFalloff)

static bool js_effekseer_RenderParameter_get_EmissiveScaling(se::State& s) // NOLINT(readability-identifier-naming)
{
    auto* cobj = SE_THIS_OBJECT<cce::RenderParameter>(s);
    // SE_PRECONDITION2(cobj, false, "Invalid Native Object");
    if (nullptr == cobj) return true;

    CC_UNUSED bool ok = true;
    se::Value jsret;
    ok &= nativevalue_to_se(cobj->EmissiveScaling, jsret, s.thisObject() /*ctx*/);
    s.rval() = jsret;
    SE_HOLD_RETURN_VALUE(cobj->EmissiveScaling, s.thisObject(), s.rval());
    return true;
}
SE_BIND_PROP_GET(js_effekseer_RenderParameter_get_EmissiveScaling)

static bool js_effekseer_RenderParameter_set_EmissiveScaling(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    auto* cobj = SE_THIS_OBJECT<cce::RenderParameter>(s);
    SE_PRECONDITION2(cobj, false, "Invalid Native Object");

    CC_UNUSED bool ok = true;
    ok &= sevalue_to_native(args[0], &cobj->EmissiveScaling, s.thisObject());
    SE_PRECONDITION2(ok, false, "Error processing new value");
    return true;
}
SE_BIND_PROP_SET(js_effekseer_RenderParameter_set_EmissiveScaling)

static bool js_effekseer_RenderParameter_get_SoftParticleParam(se::State& s) // NOLINT(readability-identifier-naming)
{
    auto* cobj = SE_THIS_OBJECT<cce::RenderParameter>(s);
    // SE_PRECONDITION2(cobj, false, "Invalid Native Object");
    if (nullptr == cobj) return true;

    CC_UNUSED bool ok = true;
    se::Value jsret;
    ok &= nativevalue_to_se(cobj->SoftParticleParam, jsret, s.thisObject() /*ctx*/);
    s.rval() = jsret;
    SE_HOLD_RETURN_VALUE(cobj->SoftParticleParam, s.thisObject(), s.rval());
    return true;
}
SE_BIND_PROP_GET(js_effekseer_RenderParameter_get_SoftParticleParam)

static bool js_effekseer_RenderParameter_set_SoftParticleParam(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    auto* cobj = SE_THIS_OBJECT<cce::RenderParameter>(s);
    SE_PRECONDITION2(cobj, false, "Invalid Native Object");

    CC_UNUSED bool ok = true;
    ok &= sevalue_to_native(args[0], &cobj->SoftParticleParam, s.thisObject());
    SE_PRECONDITION2(ok, false, "Error processing new value");
    return true;
}
SE_BIND_PROP_SET(js_effekseer_RenderParameter_set_SoftParticleParam)

static bool js_effekseer_RenderParameter_get_ReconstrcutionParam1(se::State& s) // NOLINT(readability-identifier-naming)
{
    auto* cobj = SE_THIS_OBJECT<cce::RenderParameter>(s);
    // SE_PRECONDITION2(cobj, false, "Invalid Native Object");
    if (nullptr == cobj) return true;

    CC_UNUSED bool ok = true;
    se::Value jsret;
    ok &= nativevalue_to_se(cobj->ReconstrcutionParam1, jsret, s.thisObject() /*ctx*/);
    s.rval() = jsret;
    SE_HOLD_RETURN_VALUE(cobj->ReconstrcutionParam1, s.thisObject(), s.rval());
    return true;
}
SE_BIND_PROP_GET(js_effekseer_RenderParameter_get_ReconstrcutionParam1)

static bool js_effekseer_RenderParameter_set_ReconstrcutionParam1(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    auto* cobj = SE_THIS_OBJECT<cce::RenderParameter>(s);
    SE_PRECONDITION2(cobj, false, "Invalid Native Object");

    CC_UNUSED bool ok = true;
    ok &= sevalue_to_native(args[0], &cobj->ReconstrcutionParam1, s.thisObject());
    SE_PRECONDITION2(ok, false, "Error processing new value");
    return true;
}
SE_BIND_PROP_SET(js_effekseer_RenderParameter_set_ReconstrcutionParam1)

static bool js_effekseer_RenderParameter_get_ReconstrcutionParam2(se::State& s) // NOLINT(readability-identifier-naming)
{
    auto* cobj = SE_THIS_OBJECT<cce::RenderParameter>(s);
    // SE_PRECONDITION2(cobj, false, "Invalid Native Object");
    if (nullptr == cobj) return true;

    CC_UNUSED bool ok = true;
    se::Value jsret;
    ok &= nativevalue_to_se(cobj->ReconstrcutionParam2, jsret, s.thisObject() /*ctx*/);
    s.rval() = jsret;
    SE_HOLD_RETURN_VALUE(cobj->ReconstrcutionParam2, s.thisObject(), s.rval());
    return true;
}
SE_BIND_PROP_GET(js_effekseer_RenderParameter_get_ReconstrcutionParam2)

static bool js_effekseer_RenderParameter_set_ReconstrcutionParam2(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    auto* cobj = SE_THIS_OBJECT<cce::RenderParameter>(s);
    SE_PRECONDITION2(cobj, false, "Invalid Native Object");

    CC_UNUSED bool ok = true;
    ok &= sevalue_to_native(args[0], &cobj->ReconstrcutionParam2, s.thisObject());
    SE_PRECONDITION2(ok, false, "Error processing new value");
    return true;
}
SE_BIND_PROP_SET(js_effekseer_RenderParameter_set_ReconstrcutionParam2)

static bool js_effekseer_RenderParameter_get_PredefinedUniform(se::State& s) // NOLINT(readability-identifier-naming)
{
    auto* cobj = SE_THIS_OBJECT<cce::RenderParameter>(s);
    // SE_PRECONDITION2(cobj, false, "Invalid Native Object");
    if (nullptr == cobj) return true;

    CC_UNUSED bool ok = true;
    se::Value jsret;
    ok &= nativevalue_to_se(cobj->PredefinedUniform, jsret, s.thisObject() /*ctx*/);
    s.rval() = jsret;
    SE_HOLD_RETURN_VALUE(cobj->PredefinedUniform, s.thisObject(), s.rval());
    return true;
}
SE_BIND_PROP_GET(js_effekseer_RenderParameter_get_PredefinedUniform)

static bool js_effekseer_RenderParameter_set_PredefinedUniform(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    auto* cobj = SE_THIS_OBJECT<cce::RenderParameter>(s);
    SE_PRECONDITION2(cobj, false, "Invalid Native Object");

    CC_UNUSED bool ok = true;
    ok &= sevalue_to_native(args[0], &cobj->PredefinedUniform, s.thisObject());
    SE_PRECONDITION2(ok, false, "Error processing new value");
    return true;
}
SE_BIND_PROP_SET(js_effekseer_RenderParameter_set_PredefinedUniform)

static bool js_effekseer_RenderParameter_get_ZTest(se::State& s) // NOLINT(readability-identifier-naming)
{
    auto* cobj = SE_THIS_OBJECT<cce::RenderParameter>(s);
    // SE_PRECONDITION2(cobj, false, "Invalid Native Object");
    if (nullptr == cobj) return true;

    CC_UNUSED bool ok = true;
    se::Value jsret;
    ok &= nativevalue_to_se(cobj->ZTest, jsret, s.thisObject() /*ctx*/);
    s.rval() = jsret;
    SE_HOLD_RETURN_VALUE(cobj->ZTest, s.thisObject(), s.rval());
    return true;
}
SE_BIND_PROP_GET(js_effekseer_RenderParameter_get_ZTest)

static bool js_effekseer_RenderParameter_set_ZTest(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    auto* cobj = SE_THIS_OBJECT<cce::RenderParameter>(s);
    SE_PRECONDITION2(cobj, false, "Invalid Native Object");

    CC_UNUSED bool ok = true;
    ok &= sevalue_to_native(args[0], &cobj->ZTest, s.thisObject());
    SE_PRECONDITION2(ok, false, "Error processing new value");
    return true;
}
SE_BIND_PROP_SET(js_effekseer_RenderParameter_set_ZTest)

static bool js_effekseer_RenderParameter_get_ZWrite(se::State& s) // NOLINT(readability-identifier-naming)
{
    auto* cobj = SE_THIS_OBJECT<cce::RenderParameter>(s);
    // SE_PRECONDITION2(cobj, false, "Invalid Native Object");
    if (nullptr == cobj) return true;

    CC_UNUSED bool ok = true;
    se::Value jsret;
    ok &= nativevalue_to_se(cobj->ZWrite, jsret, s.thisObject() /*ctx*/);
    s.rval() = jsret;
    SE_HOLD_RETURN_VALUE(cobj->ZWrite, s.thisObject(), s.rval());
    return true;
}
SE_BIND_PROP_GET(js_effekseer_RenderParameter_get_ZWrite)

static bool js_effekseer_RenderParameter_set_ZWrite(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    auto* cobj = SE_THIS_OBJECT<cce::RenderParameter>(s);
    SE_PRECONDITION2(cobj, false, "Invalid Native Object");

    CC_UNUSED bool ok = true;
    ok &= sevalue_to_native(args[0], &cobj->ZWrite, s.thisObject());
    SE_PRECONDITION2(ok, false, "Error processing new value");
    return true;
}
SE_BIND_PROP_SET(js_effekseer_RenderParameter_set_ZWrite)

static bool js_effekseer_RenderParameter_get_Blend(se::State& s) // NOLINT(readability-identifier-naming)
{
    auto* cobj = SE_THIS_OBJECT<cce::RenderParameter>(s);
    // SE_PRECONDITION2(cobj, false, "Invalid Native Object");
    if (nullptr == cobj) return true;

    CC_UNUSED bool ok = true;
    se::Value jsret;
    ok &= nativevalue_to_se(cobj->Blend, jsret, s.thisObject() /*ctx*/);
    s.rval() = jsret;
    SE_HOLD_RETURN_VALUE(cobj->Blend, s.thisObject(), s.rval());
    return true;
}
SE_BIND_PROP_GET(js_effekseer_RenderParameter_get_Blend)

static bool js_effekseer_RenderParameter_set_Blend(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    auto* cobj = SE_THIS_OBJECT<cce::RenderParameter>(s);
    SE_PRECONDITION2(cobj, false, "Invalid Native Object");

    CC_UNUSED bool ok = true;
    ok &= sevalue_to_native(args[0], &cobj->Blend, s.thisObject());
    SE_PRECONDITION2(ok, false, "Error processing new value");
    return true;
}
SE_BIND_PROP_SET(js_effekseer_RenderParameter_set_Blend)

static bool js_effekseer_RenderParameter_get_Culling(se::State& s) // NOLINT(readability-identifier-naming)
{
    auto* cobj = SE_THIS_OBJECT<cce::RenderParameter>(s);
    // SE_PRECONDITION2(cobj, false, "Invalid Native Object");
    if (nullptr == cobj) return true;

    CC_UNUSED bool ok = true;
    se::Value jsret;
    ok &= nativevalue_to_se(cobj->Culling, jsret, s.thisObject() /*ctx*/);
    s.rval() = jsret;
    SE_HOLD_RETURN_VALUE(cobj->Culling, s.thisObject(), s.rval());
    return true;
}
SE_BIND_PROP_GET(js_effekseer_RenderParameter_get_Culling)

static bool js_effekseer_RenderParameter_set_Culling(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    auto* cobj = SE_THIS_OBJECT<cce::RenderParameter>(s);
    SE_PRECONDITION2(cobj, false, "Invalid Native Object");

    CC_UNUSED bool ok = true;
    ok &= sevalue_to_native(args[0], &cobj->Culling, s.thisObject());
    SE_PRECONDITION2(ok, false, "Error processing new value");
    return true;
}
SE_BIND_PROP_SET(js_effekseer_RenderParameter_set_Culling)

static bool js_effekseer_RenderParameter_get_DistortionIntensity(se::State& s) // NOLINT(readability-identifier-naming)
{
    auto* cobj = SE_THIS_OBJECT<cce::RenderParameter>(s);
    // SE_PRECONDITION2(cobj, false, "Invalid Native Object");
    if (nullptr == cobj) return true;

    CC_UNUSED bool ok = true;
    se::Value jsret;
    ok &= nativevalue_to_se(cobj->DistortionIntensity, jsret, s.thisObject() /*ctx*/);
    s.rval() = jsret;
    SE_HOLD_RETURN_VALUE(cobj->DistortionIntensity, s.thisObject(), s.rval());
    return true;
}
SE_BIND_PROP_GET(js_effekseer_RenderParameter_get_DistortionIntensity)

static bool js_effekseer_RenderParameter_set_DistortionIntensity(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    auto* cobj = SE_THIS_OBJECT<cce::RenderParameter>(s);
    SE_PRECONDITION2(cobj, false, "Invalid Native Object");

    CC_UNUSED bool ok = true;
    ok &= sevalue_to_native(args[0], &cobj->DistortionIntensity, s.thisObject());
    SE_PRECONDITION2(ok, false, "Error processing new value");
    return true;
}
SE_BIND_PROP_SET(js_effekseer_RenderParameter_set_DistortionIntensity)

static bool js_effekseer_RenderParameter_get_IsRefraction(se::State& s) // NOLINT(readability-identifier-naming)
{
    auto* cobj = SE_THIS_OBJECT<cce::RenderParameter>(s);
    // SE_PRECONDITION2(cobj, false, "Invalid Native Object");
    if (nullptr == cobj) return true;

    CC_UNUSED bool ok = true;
    se::Value jsret;
    ok &= nativevalue_to_se(cobj->IsRefraction, jsret, s.thisObject() /*ctx*/);
    s.rval() = jsret;
    SE_HOLD_RETURN_VALUE(cobj->IsRefraction, s.thisObject(), s.rval());
    return true;
}
SE_BIND_PROP_GET(js_effekseer_RenderParameter_get_IsRefraction)

static bool js_effekseer_RenderParameter_set_IsRefraction(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    auto* cobj = SE_THIS_OBJECT<cce::RenderParameter>(s);
    SE_PRECONDITION2(cobj, false, "Invalid Native Object");

    CC_UNUSED bool ok = true;
    ok &= sevalue_to_native(args[0], &cobj->IsRefraction, s.thisObject());
    SE_PRECONDITION2(ok, false, "Error processing new value");
    return true;
}
SE_BIND_PROP_SET(js_effekseer_RenderParameter_set_IsRefraction)

static bool js_effekseer_RenderParameter_get_TexturePtrs(se::State& s) // NOLINT(readability-identifier-naming)
{
    auto* cobj = SE_THIS_OBJECT<cce::RenderParameter>(s);
    // SE_PRECONDITION2(cobj, false, "Invalid Native Object");
    if (nullptr == cobj) return true;

    CC_UNUSED bool ok = true;
    se::Value jsret;
    ok &= nativevalue_to_se(cobj->TexturePtrs, jsret, s.thisObject() /*ctx*/);
    s.rval() = jsret;
    SE_HOLD_RETURN_VALUE(cobj->TexturePtrs, s.thisObject(), s.rval());
    return true;
}
SE_BIND_PROP_GET(js_effekseer_RenderParameter_get_TexturePtrs)

static bool js_effekseer_RenderParameter_set_TexturePtrs(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    auto* cobj = SE_THIS_OBJECT<cce::RenderParameter>(s);
    SE_PRECONDITION2(cobj, false, "Invalid Native Object");

    CC_UNUSED bool ok = true;
    ok &= sevalue_to_native(args[0], &cobj->TexturePtrs, s.thisObject());
    SE_PRECONDITION2(ok, false, "Error processing new value");
    return true;
}
SE_BIND_PROP_SET(js_effekseer_RenderParameter_set_TexturePtrs)

static bool js_effekseer_RenderParameter_get_TextureFilterTypes(se::State& s) // NOLINT(readability-identifier-naming)
{
    auto* cobj = SE_THIS_OBJECT<cce::RenderParameter>(s);
    // SE_PRECONDITION2(cobj, false, "Invalid Native Object");
    if (nullptr == cobj) return true;

    CC_UNUSED bool ok = true;
    se::Value jsret;
    ok &= nativevalue_to_se(cobj->TextureFilterTypes, jsret, s.thisObject() /*ctx*/);
    s.rval() = jsret;
    SE_HOLD_RETURN_VALUE(cobj->TextureFilterTypes, s.thisObject(), s.rval());
    return true;
}
SE_BIND_PROP_GET(js_effekseer_RenderParameter_get_TextureFilterTypes)

static bool js_effekseer_RenderParameter_set_TextureFilterTypes(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    auto* cobj = SE_THIS_OBJECT<cce::RenderParameter>(s);
    SE_PRECONDITION2(cobj, false, "Invalid Native Object");

    CC_UNUSED bool ok = true;
    ok &= sevalue_to_native(args[0], &cobj->TextureFilterTypes, s.thisObject());
    SE_PRECONDITION2(ok, false, "Error processing new value");
    return true;
}
SE_BIND_PROP_SET(js_effekseer_RenderParameter_set_TextureFilterTypes)

static bool js_effekseer_RenderParameter_get_TextureWrapTypes(se::State& s) // NOLINT(readability-identifier-naming)
{
    auto* cobj = SE_THIS_OBJECT<cce::RenderParameter>(s);
    // SE_PRECONDITION2(cobj, false, "Invalid Native Object");
    if (nullptr == cobj) return true;

    CC_UNUSED bool ok = true;
    se::Value jsret;
    ok &= nativevalue_to_se(cobj->TextureWrapTypes, jsret, s.thisObject() /*ctx*/);
    s.rval() = jsret;
    SE_HOLD_RETURN_VALUE(cobj->TextureWrapTypes, s.thisObject(), s.rval());
    return true;
}
SE_BIND_PROP_GET(js_effekseer_RenderParameter_get_TextureWrapTypes)

static bool js_effekseer_RenderParameter_set_TextureWrapTypes(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    auto* cobj = SE_THIS_OBJECT<cce::RenderParameter>(s);
    SE_PRECONDITION2(cobj, false, "Invalid Native Object");

    CC_UNUSED bool ok = true;
    ok &= sevalue_to_native(args[0], &cobj->TextureWrapTypes, s.thisObject());
    SE_PRECONDITION2(ok, false, "Error processing new value");
    return true;
}
SE_BIND_PROP_SET(js_effekseer_RenderParameter_set_TextureWrapTypes)

static bool js_effekseer_RenderParameter_get_TextureCount(se::State& s) // NOLINT(readability-identifier-naming)
{
    auto* cobj = SE_THIS_OBJECT<cce::RenderParameter>(s);
    // SE_PRECONDITION2(cobj, false, "Invalid Native Object");
    if (nullptr == cobj) return true;

    CC_UNUSED bool ok = true;
    se::Value jsret;
    ok &= nativevalue_to_se(cobj->TextureCount, jsret, s.thisObject() /*ctx*/);
    s.rval() = jsret;
    SE_HOLD_RETURN_VALUE(cobj->TextureCount, s.thisObject(), s.rval());
    return true;
}
SE_BIND_PROP_GET(js_effekseer_RenderParameter_get_TextureCount)

static bool js_effekseer_RenderParameter_set_TextureCount(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    auto* cobj = SE_THIS_OBJECT<cce::RenderParameter>(s);
    SE_PRECONDITION2(cobj, false, "Invalid Native Object");

    CC_UNUSED bool ok = true;
    ok &= sevalue_to_native(args[0], &cobj->TextureCount, s.thisObject());
    SE_PRECONDITION2(ok, false, "Error processing new value");
    return true;
}
SE_BIND_PROP_SET(js_effekseer_RenderParameter_set_TextureCount)

static bool js_effekseer_RenderParameter_get_MaterialPtr(se::State& s) // NOLINT(readability-identifier-naming)
{
    auto* cobj = SE_THIS_OBJECT<cce::RenderParameter>(s);
    // SE_PRECONDITION2(cobj, false, "Invalid Native Object");
    if (nullptr == cobj) return true;

    CC_UNUSED bool ok = true;
    se::Value jsret;
    ok &= nativevalue_to_se(cobj->MaterialPtr, jsret, s.thisObject() /*ctx*/);
    s.rval() = jsret;
    SE_HOLD_RETURN_VALUE(cobj->MaterialPtr, s.thisObject(), s.rval());
    return true;
}
SE_BIND_PROP_GET(js_effekseer_RenderParameter_get_MaterialPtr)

static bool js_effekseer_RenderParameter_set_MaterialPtr(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    auto* cobj = SE_THIS_OBJECT<cce::RenderParameter>(s);
    SE_PRECONDITION2(cobj, false, "Invalid Native Object");

    CC_UNUSED bool ok = true;
    ok &= sevalue_to_native(args[0], &cobj->MaterialPtr, s.thisObject());
    SE_PRECONDITION2(ok, false, "Error processing new value");
    return true;
}
SE_BIND_PROP_SET(js_effekseer_RenderParameter_set_MaterialPtr)

static bool js_effekseer_RenderParameter_get_ModelPtr(se::State& s) // NOLINT(readability-identifier-naming)
{
    auto* cobj = SE_THIS_OBJECT<cce::RenderParameter>(s);
    // SE_PRECONDITION2(cobj, false, "Invalid Native Object");
    if (nullptr == cobj) return true;

    CC_UNUSED bool ok = true;
    se::Value jsret;
    ok &= nativevalue_to_se(cobj->ModelPtr, jsret, s.thisObject() /*ctx*/);
    s.rval() = jsret;
    SE_HOLD_RETURN_VALUE(cobj->ModelPtr, s.thisObject(), s.rval());
    return true;
}
SE_BIND_PROP_GET(js_effekseer_RenderParameter_get_ModelPtr)

static bool js_effekseer_RenderParameter_set_ModelPtr(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    auto* cobj = SE_THIS_OBJECT<cce::RenderParameter>(s);
    SE_PRECONDITION2(cobj, false, "Invalid Native Object");

    CC_UNUSED bool ok = true;
    ok &= sevalue_to_native(args[0], &cobj->ModelPtr, s.thisObject());
    SE_PRECONDITION2(ok, false, "Error processing new value");
    return true;
}
SE_BIND_PROP_SET(js_effekseer_RenderParameter_set_ModelPtr)

static bool js_effekseer_RenderParameter_get_ComPtr(se::State& s) // NOLINT(readability-identifier-naming)
{
    auto* cobj = SE_THIS_OBJECT<cce::RenderParameter>(s);
    // SE_PRECONDITION2(cobj, false, "Invalid Native Object");
    if (nullptr == cobj) return true;

    CC_UNUSED bool ok = true;
    se::Value jsret;
    ok &= nativevalue_to_se(cobj->ComPtr, jsret, s.thisObject() /*ctx*/);
    s.rval() = jsret;
    SE_HOLD_RETURN_VALUE(cobj->ComPtr, s.thisObject(), s.rval());
    return true;
}
SE_BIND_PROP_GET(js_effekseer_RenderParameter_get_ComPtr)

static bool js_effekseer_RenderParameter_set_ComPtr(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    auto* cobj = SE_THIS_OBJECT<cce::RenderParameter>(s);
    SE_PRECONDITION2(cobj, false, "Invalid Native Object");

    CC_UNUSED bool ok = true;
    ok &= sevalue_to_native(args[0], &cobj->ComPtr, s.thisObject());
    SE_PRECONDITION2(ok, false, "Error processing new value");
    return true;
}
SE_BIND_PROP_SET(js_effekseer_RenderParameter_set_ComPtr)


template<>
bool sevalue_to_native(const se::Value &from, cce::RenderParameter * to, se::Object *ctx)
{
    assert(from.isObject());
    se::Object *json = from.toObject();
    auto* data = reinterpret_cast<cce::RenderParameter*>(json->getPrivateData());
    if (data) {
        *to = *data;
        return true;
    }
    se::Value field;
    bool ok = true;
    json->getProperty("RenderMode", &field, true);
    if(!field.isNullOrUndefined()) {
        ok &= sevalue_to_native(field, &(to->RenderMode), ctx);
    }
    json->getProperty("MaterialType", &field, true);
    if(!field.isNullOrUndefined()) {
        ok &= sevalue_to_native(field, &(to->MaterialType), ctx);
    }
    json->getProperty("VertexBufferOffset", &field, true);
    if(!field.isNullOrUndefined()) {
        ok &= sevalue_to_native(field, &(to->VertexBufferOffset), ctx);
    }
    json->getProperty("AdvancedBufferOffset", &field, true);
    if(!field.isNullOrUndefined()) {
        ok &= sevalue_to_native(field, &(to->AdvancedBufferOffset), ctx);
    }
    json->getProperty("VertexBufferStride", &field, true);
    if(!field.isNullOrUndefined()) {
        ok &= sevalue_to_native(field, &(to->VertexBufferStride), ctx);
    }
    json->getProperty("CustomData1BufferOffset", &field, true);
    if(!field.isNullOrUndefined()) {
        ok &= sevalue_to_native(field, &(to->CustomData1BufferOffset), ctx);
    }
    json->getProperty("CustomData2BufferOffset", &field, true);
    if(!field.isNullOrUndefined()) {
        ok &= sevalue_to_native(field, &(to->CustomData2BufferOffset), ctx);
    }
    json->getProperty("UniformBufferOffset", &field, true);
    if(!field.isNullOrUndefined()) {
        ok &= sevalue_to_native(field, &(to->UniformBufferOffset), ctx);
    }
    json->getProperty("ElementCount", &field, true);
    if(!field.isNullOrUndefined()) {
        ok &= sevalue_to_native(field, &(to->ElementCount), ctx);
    }
    json->getProperty("UVDistortionIntensity", &field, true);
    if(!field.isNullOrUndefined()) {
        ok &= sevalue_to_native(field, &(to->UVDistortionIntensity), ctx);
    }
    json->getProperty("TextureBlendType", &field, true);
    if(!field.isNullOrUndefined()) {
        ok &= sevalue_to_native(field, &(to->TextureBlendType), ctx);
    }
    json->getProperty("BlendUVDistortionIntensity", &field, true);
    if(!field.isNullOrUndefined()) {
        ok &= sevalue_to_native(field, &(to->BlendUVDistortionIntensity), ctx);
    }
    json->getProperty("EnableFalloff", &field, true);
    if(!field.isNullOrUndefined()) {
        ok &= sevalue_to_native(field, &(to->EnableFalloff), ctx);
    }
    json->getProperty("EmissiveScaling", &field, true);
    if(!field.isNullOrUndefined()) {
        ok &= sevalue_to_native(field, &(to->EmissiveScaling), ctx);
    }
    json->getProperty("SoftParticleParam", &field, true);
    if(!field.isNullOrUndefined()) {
        ok &= sevalue_to_native(field, &(to->SoftParticleParam), ctx);
    }
    json->getProperty("ReconstrcutionParam1", &field, true);
    if(!field.isNullOrUndefined()) {
        ok &= sevalue_to_native(field, &(to->ReconstrcutionParam1), ctx);
    }
    json->getProperty("ReconstrcutionParam2", &field, true);
    if(!field.isNullOrUndefined()) {
        ok &= sevalue_to_native(field, &(to->ReconstrcutionParam2), ctx);
    }
    json->getProperty("PredefinedUniform", &field, true);
    if(!field.isNullOrUndefined()) {
        ok &= sevalue_to_native(field, &(to->PredefinedUniform), ctx);
    }
    json->getProperty("ZTest", &field, true);
    if(!field.isNullOrUndefined()) {
        ok &= sevalue_to_native(field, &(to->ZTest), ctx);
    }
    json->getProperty("ZWrite", &field, true);
    if(!field.isNullOrUndefined()) {
        ok &= sevalue_to_native(field, &(to->ZWrite), ctx);
    }
    json->getProperty("Blend", &field, true);
    if(!field.isNullOrUndefined()) {
        ok &= sevalue_to_native(field, &(to->Blend), ctx);
    }
    json->getProperty("Culling", &field, true);
    if(!field.isNullOrUndefined()) {
        ok &= sevalue_to_native(field, &(to->Culling), ctx);
    }
    json->getProperty("DistortionIntensity", &field, true);
    if(!field.isNullOrUndefined()) {
        ok &= sevalue_to_native(field, &(to->DistortionIntensity), ctx);
    }
    json->getProperty("IsRefraction", &field, true);
    if(!field.isNullOrUndefined()) {
        ok &= sevalue_to_native(field, &(to->IsRefraction), ctx);
    }
    json->getProperty("TexturePtrs", &field, true);
    if(!field.isNullOrUndefined()) {
        ok &= sevalue_to_native(field, &(to->TexturePtrs), ctx);
    }
    json->getProperty("TextureFilterTypes", &field, true);
    if(!field.isNullOrUndefined()) {
        ok &= sevalue_to_native(field, &(to->TextureFilterTypes), ctx);
    }
    json->getProperty("TextureWrapTypes", &field, true);
    if(!field.isNullOrUndefined()) {
        ok &= sevalue_to_native(field, &(to->TextureWrapTypes), ctx);
    }
    json->getProperty("TextureCount", &field, true);
    if(!field.isNullOrUndefined()) {
        ok &= sevalue_to_native(field, &(to->TextureCount), ctx);
    }
    json->getProperty("MaterialPtr", &field, true);
    if(!field.isNullOrUndefined()) {
        ok &= sevalue_to_native(field, &(to->MaterialPtr), ctx);
    }
    json->getProperty("ModelPtr", &field, true);
    if(!field.isNullOrUndefined()) {
        ok &= sevalue_to_native(field, &(to->ModelPtr), ctx);
    }
    json->getProperty("ComPtr", &field, true);
    if(!field.isNullOrUndefined()) {
        ok &= sevalue_to_native(field, &(to->ComPtr), ctx);
    }
    return ok;
}

SE_DECLARE_FINALIZE_FUNC(js_cce_RenderParameter_finalize)

static bool js_effekseer_RenderParameter_constructor(se::State& s) // NOLINT(readability-identifier-naming)
{
    CC_UNUSED bool ok = true;
    const auto& args = s.args();
    size_t argc = args.size();

    if(argc == 0)
    {
        auto *ptr = JSB_MAKE_PRIVATE_OBJECT(cce::RenderParameter);
        s.thisObject()->setPrivateObject(ptr);
        return true;
    }

    if(argc == 1 && args[0].isObject())
    {
        se::Object *json = args[0].toObject();
        se::Value field;
        auto *ptr = JSB_MAKE_PRIVATE_OBJECT(cce::RenderParameter);
        auto cobj = ptr->get<cce::RenderParameter>();
        ok &= sevalue_to_native(args[0], cobj, s.thisObject());
        if(!ok) {
            delete ptr;
            SE_REPORT_ERROR("argument convertion error");
            return false;
        }
        s.thisObject()->setPrivateObject(ptr);
        return true;
    }
    auto *ptr = JSB_MAKE_PRIVATE_OBJECT(cce::RenderParameter);
    auto cobj = ptr->get<cce::RenderParameter>();
    if (argc > 0 && !args[0].isUndefined()) {
        ok &= sevalue_to_native(args[0], &(cobj->RenderMode), nullptr);
    }
    if (argc > 1 && !args[1].isUndefined()) {
        ok &= sevalue_to_native(args[1], &(cobj->MaterialType), nullptr);
    }
    if (argc > 2 && !args[2].isUndefined()) {
        ok &= sevalue_to_native(args[2], &(cobj->VertexBufferOffset), nullptr);
    }
    if (argc > 3 && !args[3].isUndefined()) {
        ok &= sevalue_to_native(args[3], &(cobj->AdvancedBufferOffset), nullptr);
    }
    if (argc > 4 && !args[4].isUndefined()) {
        ok &= sevalue_to_native(args[4], &(cobj->VertexBufferStride), nullptr);
    }
    if (argc > 5 && !args[5].isUndefined()) {
        ok &= sevalue_to_native(args[5], &(cobj->CustomData1BufferOffset), nullptr);
    }
    if (argc > 6 && !args[6].isUndefined()) {
        ok &= sevalue_to_native(args[6], &(cobj->CustomData2BufferOffset), nullptr);
    }
    if (argc > 7 && !args[7].isUndefined()) {
        ok &= sevalue_to_native(args[7], &(cobj->UniformBufferOffset), nullptr);
    }
    if (argc > 8 && !args[8].isUndefined()) {
        ok &= sevalue_to_native(args[8], &(cobj->ElementCount), nullptr);
    }
    if (argc > 9 && !args[9].isUndefined()) {
        ok &= sevalue_to_native(args[9], &(cobj->UVDistortionIntensity), nullptr);
    }
    if (argc > 10 && !args[10].isUndefined()) {
        ok &= sevalue_to_native(args[10], &(cobj->TextureBlendType), nullptr);
    }
    if (argc > 11 && !args[11].isUndefined()) {
        ok &= sevalue_to_native(args[11], &(cobj->BlendUVDistortionIntensity), nullptr);
    }
    if (argc > 12 && !args[12].isUndefined()) {
        ok &= sevalue_to_native(args[12], &(cobj->EnableFalloff), nullptr);
    }
    if (argc > 13 && !args[13].isUndefined()) {
        ok &= sevalue_to_native(args[13], &(cobj->EmissiveScaling), nullptr);
    }
    if (argc > 14 && !args[14].isUndefined()) {
        ok &= sevalue_to_native(args[14], &(cobj->SoftParticleParam), nullptr);
    }
    if (argc > 15 && !args[15].isUndefined()) {
        ok &= sevalue_to_native(args[15], &(cobj->ReconstrcutionParam1), nullptr);
    }
    if (argc > 16 && !args[16].isUndefined()) {
        ok &= sevalue_to_native(args[16], &(cobj->ReconstrcutionParam2), nullptr);
    }
    if (argc > 17 && !args[17].isUndefined()) {
        ok &= sevalue_to_native(args[17], &(cobj->PredefinedUniform), nullptr);
    }
    if (argc > 18 && !args[18].isUndefined()) {
        ok &= sevalue_to_native(args[18], &(cobj->ZTest), nullptr);
    }
    if (argc > 19 && !args[19].isUndefined()) {
        ok &= sevalue_to_native(args[19], &(cobj->ZWrite), nullptr);
    }
    if (argc > 20 && !args[20].isUndefined()) {
        ok &= sevalue_to_native(args[20], &(cobj->Blend), nullptr);
    }
    if (argc > 21 && !args[21].isUndefined()) {
        ok &= sevalue_to_native(args[21], &(cobj->Culling), nullptr);
    }
    if (argc > 22 && !args[22].isUndefined()) {
        ok &= sevalue_to_native(args[22], &(cobj->DistortionIntensity), nullptr);
    }
    if (argc > 23 && !args[23].isUndefined()) {
        ok &= sevalue_to_native(args[23], &(cobj->IsRefraction), nullptr);
    }
    if (argc > 24 && !args[24].isUndefined()) {
        ok &= sevalue_to_native(args[24], &(cobj->TexturePtrs), nullptr);
    }
    if (argc > 25 && !args[25].isUndefined()) {
        ok &= sevalue_to_native(args[25], &(cobj->TextureFilterTypes), nullptr);
    }
    if (argc > 26 && !args[26].isUndefined()) {
        ok &= sevalue_to_native(args[26], &(cobj->TextureWrapTypes), nullptr);
    }
    if (argc > 27 && !args[27].isUndefined()) {
        ok &= sevalue_to_native(args[27], &(cobj->TextureCount), nullptr);
    }
    if (argc > 28 && !args[28].isUndefined()) {
        ok &= sevalue_to_native(args[28], &(cobj->MaterialPtr), nullptr);
    }
    if (argc > 29 && !args[29].isUndefined()) {
        ok &= sevalue_to_native(args[29], &(cobj->ModelPtr), nullptr);
    }
    if (argc > 30 && !args[30].isUndefined()) {
        ok &= sevalue_to_native(args[30], &(cobj->ComPtr), nullptr);
    }

    if(!ok) {
        delete ptr;
        SE_REPORT_ERROR("Argument convertion error");
        return false;
    }
    s.thisObject()->setPrivateObject(ptr);
    return true;
}
SE_BIND_CTOR(js_effekseer_RenderParameter_constructor, __jsb_cce_RenderParameter_class, js_cce_RenderParameter_finalize)

static bool js_cce_RenderParameter_finalize(se::State& s) // NOLINT(readability-identifier-naming)
{
    return true;
}
SE_BIND_FINALIZE_FUNC(js_cce_RenderParameter_finalize)

bool js_register_effekseer_RenderParameter(se::Object* obj) // NOLINT(readability-identifier-naming)
{
    auto* cls = se::Class::create("RenderParameter", obj, nullptr, _SE(js_effekseer_RenderParameter_constructor));

#if CC_DEBUG
    cls->defineStaticProperty("isJSBClass", _SE(js_effekseer_getter_return_true), nullptr);
#endif
    cls->defineProperty("RenderMode", _SE(js_effekseer_RenderParameter_get_RenderMode), _SE(js_effekseer_RenderParameter_set_RenderMode));
    cls->defineProperty("MaterialType", _SE(js_effekseer_RenderParameter_get_MaterialType), _SE(js_effekseer_RenderParameter_set_MaterialType));
    cls->defineProperty("VertexBufferOffset", _SE(js_effekseer_RenderParameter_get_VertexBufferOffset), _SE(js_effekseer_RenderParameter_set_VertexBufferOffset));
    cls->defineProperty("AdvancedBufferOffset", _SE(js_effekseer_RenderParameter_get_AdvancedBufferOffset), _SE(js_effekseer_RenderParameter_set_AdvancedBufferOffset));
    cls->defineProperty("VertexBufferStride", _SE(js_effekseer_RenderParameter_get_VertexBufferStride), _SE(js_effekseer_RenderParameter_set_VertexBufferStride));
    cls->defineProperty("CustomData1BufferOffset", _SE(js_effekseer_RenderParameter_get_CustomData1BufferOffset), _SE(js_effekseer_RenderParameter_set_CustomData1BufferOffset));
    cls->defineProperty("CustomData2BufferOffset", _SE(js_effekseer_RenderParameter_get_CustomData2BufferOffset), _SE(js_effekseer_RenderParameter_set_CustomData2BufferOffset));
    cls->defineProperty("UniformBufferOffset", _SE(js_effekseer_RenderParameter_get_UniformBufferOffset), _SE(js_effekseer_RenderParameter_set_UniformBufferOffset));
    cls->defineProperty("ElementCount", _SE(js_effekseer_RenderParameter_get_ElementCount), _SE(js_effekseer_RenderParameter_set_ElementCount));
    cls->defineProperty("UVDistortionIntensity", _SE(js_effekseer_RenderParameter_get_UVDistortionIntensity), _SE(js_effekseer_RenderParameter_set_UVDistortionIntensity));
    cls->defineProperty("TextureBlendType", _SE(js_effekseer_RenderParameter_get_TextureBlendType), _SE(js_effekseer_RenderParameter_set_TextureBlendType));
    cls->defineProperty("BlendUVDistortionIntensity", _SE(js_effekseer_RenderParameter_get_BlendUVDistortionIntensity), _SE(js_effekseer_RenderParameter_set_BlendUVDistortionIntensity));
    cls->defineProperty("EnableFalloff", _SE(js_effekseer_RenderParameter_get_EnableFalloff), _SE(js_effekseer_RenderParameter_set_EnableFalloff));
    cls->defineProperty("EmissiveScaling", _SE(js_effekseer_RenderParameter_get_EmissiveScaling), _SE(js_effekseer_RenderParameter_set_EmissiveScaling));
    cls->defineProperty("SoftParticleParam", _SE(js_effekseer_RenderParameter_get_SoftParticleParam), _SE(js_effekseer_RenderParameter_set_SoftParticleParam));
    cls->defineProperty("ReconstrcutionParam1", _SE(js_effekseer_RenderParameter_get_ReconstrcutionParam1), _SE(js_effekseer_RenderParameter_set_ReconstrcutionParam1));
    cls->defineProperty("ReconstrcutionParam2", _SE(js_effekseer_RenderParameter_get_ReconstrcutionParam2), _SE(js_effekseer_RenderParameter_set_ReconstrcutionParam2));
    cls->defineProperty("PredefinedUniform", _SE(js_effekseer_RenderParameter_get_PredefinedUniform), _SE(js_effekseer_RenderParameter_set_PredefinedUniform));
    cls->defineProperty("ZTest", _SE(js_effekseer_RenderParameter_get_ZTest), _SE(js_effekseer_RenderParameter_set_ZTest));
    cls->defineProperty("ZWrite", _SE(js_effekseer_RenderParameter_get_ZWrite), _SE(js_effekseer_RenderParameter_set_ZWrite));
    cls->defineProperty("Blend", _SE(js_effekseer_RenderParameter_get_Blend), _SE(js_effekseer_RenderParameter_set_Blend));
    cls->defineProperty("Culling", _SE(js_effekseer_RenderParameter_get_Culling), _SE(js_effekseer_RenderParameter_set_Culling));
    cls->defineProperty("DistortionIntensity", _SE(js_effekseer_RenderParameter_get_DistortionIntensity), _SE(js_effekseer_RenderParameter_set_DistortionIntensity));
    cls->defineProperty("IsRefraction", _SE(js_effekseer_RenderParameter_get_IsRefraction), _SE(js_effekseer_RenderParameter_set_IsRefraction));
    cls->defineProperty("TexturePtrs", _SE(js_effekseer_RenderParameter_get_TexturePtrs), _SE(js_effekseer_RenderParameter_set_TexturePtrs));
    cls->defineProperty("TextureFilterTypes", _SE(js_effekseer_RenderParameter_get_TextureFilterTypes), _SE(js_effekseer_RenderParameter_set_TextureFilterTypes));
    cls->defineProperty("TextureWrapTypes", _SE(js_effekseer_RenderParameter_get_TextureWrapTypes), _SE(js_effekseer_RenderParameter_set_TextureWrapTypes));
    cls->defineProperty("TextureCount", _SE(js_effekseer_RenderParameter_get_TextureCount), _SE(js_effekseer_RenderParameter_set_TextureCount));
    cls->defineProperty("MaterialPtr", _SE(js_effekseer_RenderParameter_get_MaterialPtr), _SE(js_effekseer_RenderParameter_set_MaterialPtr));
    cls->defineProperty("ModelPtr", _SE(js_effekseer_RenderParameter_get_ModelPtr), _SE(js_effekseer_RenderParameter_set_ModelPtr));
    cls->defineProperty("ComPtr", _SE(js_effekseer_RenderParameter_get_ComPtr), _SE(js_effekseer_RenderParameter_set_ComPtr));
    cls->defineFunction("getEdgeParams", _SE(js_effekseer_RenderParameter_getEdgeParams));
    cls->defineFunction("getFalloffParam", _SE(js_effekseer_RenderParameter_getFalloffParam));
    cls->defineFunction("getFlipbookParams", _SE(js_effekseer_RenderParameter_getFlipbookParams));
    cls->defineFinalizeFunction(_SE(js_cce_RenderParameter_finalize));
    cls->install();
    JSBClassType::registerClass<cce::RenderParameter>(cls);

    __jsb_cce_RenderParameter_proto = cls->getProto();
    __jsb_cce_RenderParameter_class = cls;


    se::ScriptEngine::getInstance()->clearException();
    return true;
}
se::Object* __jsb_cce_effekseer_proto = nullptr; // NOLINT
se::Class* __jsb_cce_effekseer_class = nullptr;  // NOLINT

static bool js_effekseer_effekseer_enableBackGroundTexture_static(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    size_t argc = args.size();
    CC_UNUSED bool ok = true;
    if (argc == 1) {
        HolderType<int, false> arg0 = {};
        ok &= sevalue_to_native(args[0], &arg0, nullptr);
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        int32_t result = cce::effekseer::enableBackGroundTexture(arg0.value());
        ok &= nativevalue_to_se(result, s.rval(), nullptr /*ctx*/);
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        SE_HOLD_RETURN_VALUE(result, s.thisObject(), s.rval());
        return true;
    }
    SE_REPORT_ERROR("wrong number of arguments: %d, was expecting %d", (int)argc, 1);
    return false;
}
SE_BIND_FUNC(js_effekseer_effekseer_enableBackGroundTexture_static)

static bool js_effekseer_effekseer_enableDepthTexture_static(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    size_t argc = args.size();
    CC_UNUSED bool ok = true;
    if (argc == 1) {
        HolderType<int, false> arg0 = {};
        ok &= sevalue_to_native(args[0], &arg0, nullptr);
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        int32_t result = cce::effekseer::enableDepthTexture(arg0.value());
        ok &= nativevalue_to_se(result, s.rval(), nullptr /*ctx*/);
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        SE_HOLD_RETURN_VALUE(result, s.thisObject(), s.rval());
        return true;
    }
    SE_REPORT_ERROR("wrong number of arguments: %d, was expecting %d", (int)argc, 1);
    return false;
}
SE_BIND_FUNC(js_effekseer_effekseer_enableDepthTexture_static)

static bool js_effekseer_effekseer_exists_static(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    size_t argc = args.size();
    CC_UNUSED bool ok = true;
    if (argc == 1) {
        HolderType<int32_t, false> arg0 = {};
        ok &= sevalue_to_native(args[0], &arg0, nullptr);
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        int32_t result = cce::effekseer::exists(arg0.value());
        ok &= nativevalue_to_se(result, s.rval(), nullptr /*ctx*/);
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        SE_HOLD_RETURN_VALUE(result, s.thisObject(), s.rval());
        return true;
    }
    SE_REPORT_ERROR("wrong number of arguments: %d, was expecting %d", (int)argc, 1);
    return false;
}
SE_BIND_FUNC(js_effekseer_effekseer_exists_static)

static bool js_effekseer_effekseer_getCameraCullingMaskToShowAllEffects_static(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    size_t argc = args.size();
    CC_UNUSED bool ok = true;
    if (argc == 0) {
        int32_t result = cce::effekseer::getCameraCullingMaskToShowAllEffects();
        ok &= nativevalue_to_se(result, s.rval(), nullptr /*ctx*/);
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        SE_HOLD_RETURN_VALUE(result, s.thisObject(), s.rval());
        return true;
    }
    SE_REPORT_ERROR("wrong number of arguments: %d, was expecting %d", (int)argc, 0);
    return false;
}
SE_BIND_FUNC(js_effekseer_effekseer_getCameraCullingMaskToShowAllEffects_static)

static bool js_effekseer_effekseer_getDynamicInput_static(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    size_t argc = args.size();
    CC_UNUSED bool ok = true;
    if (argc == 2) {
        HolderType<int32_t, false> arg0 = {};
        HolderType<int, false> arg1 = {};
        ok &= sevalue_to_native(args[0], &arg0, nullptr);
        ok &= sevalue_to_native(args[1], &arg1, nullptr);
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        float result = cce::effekseer::getDynamicInput(arg0.value(), arg1.value());
        ok &= nativevalue_to_se(result, s.rval(), nullptr /*ctx*/);
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        SE_HOLD_RETURN_VALUE(result, s.thisObject(), s.rval());
        return true;
    }
    SE_REPORT_ERROR("wrong number of arguments: %d, was expecting %d", (int)argc, 2);
    return false;
}
SE_BIND_FUNC(js_effekseer_effekseer_getDynamicInput_static)

static bool js_effekseer_effekseer_getEffectMagnification_static(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    size_t argc = args.size();
    CC_UNUSED bool ok = true;
    if (argc == 1) {
        HolderType<int32_t, false> arg0 = {};
        ok &= sevalue_to_native(args[0], &arg0, nullptr);
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        float result = cce::effekseer::getEffectMagnification(arg0.value());
        ok &= nativevalue_to_se(result, s.rval(), nullptr /*ctx*/);
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        SE_HOLD_RETURN_VALUE(result, s.thisObject(), s.rval());
        return true;
    }
    SE_REPORT_ERROR("wrong number of arguments: %d, was expecting %d", (int)argc, 1);
    return false;
}
SE_BIND_FUNC(js_effekseer_effekseer_getEffectMagnification_static)

static bool js_effekseer_effekseer_getFrameCount_static(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    size_t argc = args.size();
    CC_UNUSED bool ok = true;
    if (argc == 1) {
        HolderType<int32_t, false> arg0 = {};
        ok &= sevalue_to_native(args[0], &arg0, nullptr);
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        int32_t result = cce::effekseer::getFrameCount(arg0.value());
        ok &= nativevalue_to_se(result, s.rval(), nullptr /*ctx*/);
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        SE_HOLD_RETURN_VALUE(result, s.thisObject(), s.rval());
        return true;
    }
    SE_REPORT_ERROR("wrong number of arguments: %d, was expecting %d", (int)argc, 1);
    return false;
}
SE_BIND_FUNC(js_effekseer_effekseer_getFrameCount_static)

static bool js_effekseer_effekseer_getInstanceCount_static(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    size_t argc = args.size();
    CC_UNUSED bool ok = true;
    if (argc == 1) {
        HolderType<int32_t, false> arg0 = {};
        ok &= sevalue_to_native(args[0], &arg0, nullptr);
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        int32_t result = cce::effekseer::getInstanceCount(arg0.value());
        ok &= nativevalue_to_se(result, s.rval(), nullptr /*ctx*/);
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        SE_HOLD_RETURN_VALUE(result, s.thisObject(), s.rval());
        return true;
    }
    SE_REPORT_ERROR("wrong number of arguments: %d, was expecting %d", (int)argc, 1);
    return false;
}
SE_BIND_FUNC(js_effekseer_effekseer_getInstanceCount_static)

static bool js_effekseer_effekseer_getPaused_static(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    size_t argc = args.size();
    CC_UNUSED bool ok = true;
    if (argc == 1) {
        HolderType<int32_t, false> arg0 = {};
        ok &= sevalue_to_native(args[0], &arg0, nullptr);
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        int32_t result = cce::effekseer::getPaused(arg0.value());
        ok &= nativevalue_to_se(result, s.rval(), nullptr /*ctx*/);
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        SE_HOLD_RETURN_VALUE(result, s.thisObject(), s.rval());
        return true;
    }
    SE_REPORT_ERROR("wrong number of arguments: %d, was expecting %d", (int)argc, 1);
    return false;
}
SE_BIND_FUNC(js_effekseer_effekseer_getPaused_static)

static bool js_effekseer_effekseer_getRestInstancesCount_static(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    size_t argc = args.size();
    CC_UNUSED bool ok = true;
    if (argc == 0) {
        int32_t result = cce::effekseer::getRestInstancesCount();
        ok &= nativevalue_to_se(result, s.rval(), nullptr /*ctx*/);
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        SE_HOLD_RETURN_VALUE(result, s.thisObject(), s.rval());
        return true;
    }
    SE_REPORT_ERROR("wrong number of arguments: %d, was expecting %d", (int)argc, 0);
    return false;
}
SE_BIND_FUNC(js_effekseer_effekseer_getRestInstancesCount_static)

static bool js_effekseer_effekseer_getShown_static(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    size_t argc = args.size();
    CC_UNUSED bool ok = true;
    if (argc == 1) {
        HolderType<int32_t, false> arg0 = {};
        ok &= sevalue_to_native(args[0], &arg0, nullptr);
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        int32_t result = cce::effekseer::getShown(arg0.value());
        ok &= nativevalue_to_se(result, s.rval(), nullptr /*ctx*/);
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        SE_HOLD_RETURN_VALUE(result, s.thisObject(), s.rval());
        return true;
    }
    SE_REPORT_ERROR("wrong number of arguments: %d, was expecting %d", (int)argc, 1);
    return false;
}
SE_BIND_FUNC(js_effekseer_effekseer_getShown_static)

static bool js_effekseer_effekseer_getSpeed_static(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    size_t argc = args.size();
    CC_UNUSED bool ok = true;
    if (argc == 1) {
        HolderType<int32_t, false> arg0 = {};
        ok &= sevalue_to_native(args[0], &arg0, nullptr);
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        float result = cce::effekseer::getSpeed(arg0.value());
        ok &= nativevalue_to_se(result, s.rval(), nullptr /*ctx*/);
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        SE_HOLD_RETURN_VALUE(result, s.thisObject(), s.rval());
        return true;
    }
    SE_REPORT_ERROR("wrong number of arguments: %d, was expecting %d", (int)argc, 1);
    return false;
}
SE_BIND_FUNC(js_effekseer_effekseer_getSpeed_static)

static bool js_effekseer_effekseer_init_static(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    size_t argc = args.size();
    CC_UNUSED bool ok = true;
    if (argc == 6) {
        HolderType<int, false> arg0 = {};
        HolderType<int, false> arg1 = {};
        HolderType<int, false> arg2 = {};
        HolderType<int, false> arg3 = {};
        HolderType<int, false> arg4 = {};
        HolderType<int, false> arg5 = {};
        ok &= sevalue_to_native(args[0], &arg0, nullptr);
        ok &= sevalue_to_native(args[1], &arg1, nullptr);
        ok &= sevalue_to_native(args[2], &arg2, nullptr);
        ok &= sevalue_to_native(args[3], &arg3, nullptr);
        ok &= sevalue_to_native(args[4], &arg4, nullptr);
        ok &= sevalue_to_native(args[5], &arg5, nullptr);
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        cce::effekseer::init(arg0.value(), arg1.value(), arg2.value(), arg3.value(), arg4.value(), arg5.value());
        return true;
    }
    SE_REPORT_ERROR("wrong number of arguments: %d, was expecting %d", (int)argc, 6);
    return false;
}
SE_BIND_FUNC(js_effekseer_effekseer_init_static)

static bool js_effekseer_effekseer_initRenderer_static(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    size_t argc = args.size();
    if (argc == 0) {
        cce::effekseer::initRenderer();
        return true;
    }
    SE_REPORT_ERROR("wrong number of arguments: %d, was expecting %d", (int)argc, 0);
    return false;
}
SE_BIND_FUNC(js_effekseer_effekseer_initRenderer_static)

static bool js_effekseer_effekseer_loadEffect_static(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    size_t argc = args.size();
    CC_UNUSED bool ok = true;
    if (argc == 2) {
        HolderType<std::string, false> arg0 = {};
        HolderType<float, false> arg1 = {};
        ok &= sevalue_to_native(args[0], &arg0, nullptr);
        ok &= sevalue_to_native(args[1], &arg1, nullptr);
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        int32_t result = cce::effekseer::loadEffect(arg0.value(), arg1.value());
        ok &= nativevalue_to_se(result, s.rval(), nullptr /*ctx*/);
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        SE_HOLD_RETURN_VALUE(result, s.thisObject(), s.rval());
        return true;
    }
    SE_REPORT_ERROR("wrong number of arguments: %d, was expecting %d", (int)argc, 2);
    return false;
}
SE_BIND_FUNC(js_effekseer_effekseer_loadEffect_static)

static bool js_effekseer_effekseer_loadEffectOnMemory_static(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    size_t argc = args.size();
    CC_UNUSED bool ok = true;
    if (argc == 2) {
        HolderType<std::vector<unsigned char>, false> arg0 = {};
        HolderType<std::string, false> arg1 = {};
        ok &= sevalue_to_native(args[0], &arg0, nullptr);
        ok &= sevalue_to_native(args[1], &arg1, nullptr);
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        int32_t result = cce::effekseer::loadEffectOnMemory(arg0.value(), arg1.value());
        ok &= nativevalue_to_se(result, s.rval(), nullptr /*ctx*/);
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        SE_HOLD_RETURN_VALUE(result, s.thisObject(), s.rval());
        return true;
    }
    if (argc == 3) {
        HolderType<std::vector<unsigned char>, false> arg0 = {};
        HolderType<std::string, false> arg1 = {};
        HolderType<float, false> arg2 = {};
        ok &= sevalue_to_native(args[0], &arg0, nullptr);
        ok &= sevalue_to_native(args[1], &arg1, nullptr);
        ok &= sevalue_to_native(args[2], &arg2, nullptr);
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        int32_t result = cce::effekseer::loadEffectOnMemory(arg0.value(), arg1.value(), arg2.value());
        ok &= nativevalue_to_se(result, s.rval(), nullptr /*ctx*/);
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        SE_HOLD_RETURN_VALUE(result, s.thisObject(), s.rval());
        return true;
    }
    SE_REPORT_ERROR("wrong number of arguments: %d, was expecting %d", (int)argc, 3);
    return false;
}
SE_BIND_FUNC(js_effekseer_effekseer_loadEffectOnMemory_static)

static bool js_effekseer_effekseer_playEffect_static(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    size_t argc = args.size();
    CC_UNUSED bool ok = true;
    if (argc == 4) {
        HolderType<int32_t, false> arg0 = {};
        HolderType<float, false> arg1 = {};
        HolderType<float, false> arg2 = {};
        HolderType<float, false> arg3 = {};
        ok &= sevalue_to_native(args[0], &arg0, nullptr);
        ok &= sevalue_to_native(args[1], &arg1, nullptr);
        ok &= sevalue_to_native(args[2], &arg2, nullptr);
        ok &= sevalue_to_native(args[3], &arg3, nullptr);
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        int result = cce::effekseer::playEffect(arg0.value(), arg1.value(), arg2.value(), arg3.value());
        ok &= nativevalue_to_se(result, s.rval(), nullptr /*ctx*/);
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        SE_HOLD_RETURN_VALUE(result, s.thisObject(), s.rval());
        return true;
    }
    SE_REPORT_ERROR("wrong number of arguments: %d, was expecting %d", (int)argc, 4);
    return false;
}
SE_BIND_FUNC(js_effekseer_effekseer_playEffect_static)

static bool js_effekseer_effekseer_releaseEffect_static(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    size_t argc = args.size();
    CC_UNUSED bool ok = true;
    if (argc == 1) {
        HolderType<int32_t, false> arg0 = {};
        ok &= sevalue_to_native(args[0], &arg0, nullptr);
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        cce::effekseer::releaseEffect(arg0.value());
        return true;
    }
    SE_REPORT_ERROR("wrong number of arguments: %d, was expecting %d", (int)argc, 1);
    return false;
}
SE_BIND_FUNC(js_effekseer_effekseer_releaseEffect_static)

static bool js_effekseer_effekseer_reloadResources_static(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    size_t argc = args.size();
    CC_UNUSED bool ok = true;
    if (argc == 1) {
        HolderType<int32_t, false> arg0 = {};
        ok &= sevalue_to_native(args[0], &arg0, nullptr);
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        cce::effekseer::reloadResources(arg0.value());
        return true;
    }
    SE_REPORT_ERROR("wrong number of arguments: %d, was expecting %d", (int)argc, 1);
    return false;
}
SE_BIND_FUNC(js_effekseer_effekseer_reloadResources_static)

static bool js_effekseer_effekseer_render_static(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    size_t argc = args.size();
    CC_UNUSED bool ok = true;
    if (argc == 1) {
        HolderType<int, false> arg0 = {};
        ok &= sevalue_to_native(args[0], &arg0, nullptr);
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        cce::effekseer::render(arg0.value());
        return true;
    }
    SE_REPORT_ERROR("wrong number of arguments: %d, was expecting %d", (int)argc, 1);
    return false;
}
SE_BIND_FUNC(js_effekseer_effekseer_render_static)

static bool js_effekseer_effekseer_renderBack_static(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    size_t argc = args.size();
    CC_UNUSED bool ok = true;
    if (argc == 1) {
        HolderType<int, false> arg0 = {};
        ok &= sevalue_to_native(args[0], &arg0, nullptr);
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        cce::effekseer::renderBack(arg0.value());
        return true;
    }
    SE_REPORT_ERROR("wrong number of arguments: %d, was expecting %d", (int)argc, 1);
    return false;
}
SE_BIND_FUNC(js_effekseer_effekseer_renderBack_static)

static bool js_effekseer_effekseer_renderFront_static(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    size_t argc = args.size();
    CC_UNUSED bool ok = true;
    if (argc == 1) {
        HolderType<int, false> arg0 = {};
        ok &= sevalue_to_native(args[0], &arg0, nullptr);
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        cce::effekseer::renderFront(arg0.value());
        return true;
    }
    SE_REPORT_ERROR("wrong number of arguments: %d, was expecting %d", (int)argc, 1);
    return false;
}
SE_BIND_FUNC(js_effekseer_effekseer_renderFront_static)

static bool js_effekseer_effekseer_renderInfoBuffer_static(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    size_t argc = args.size();
    CC_UNUSED bool ok = true;
    if (argc == 0) {
        std::vector<unsigned char>& result = cce::effekseer::renderInfoBuffer();
        ok &= nativevalue_to_se(result, s.rval(), nullptr /*ctx*/);
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        SE_HOLD_RETURN_VALUE(result, s.thisObject(), s.rval());
        return true;
    }
    SE_REPORT_ERROR("wrong number of arguments: %d, was expecting %d", (int)argc, 0);
    return false;
}
SE_BIND_FUNC(js_effekseer_effekseer_renderInfoBuffer_static)

static bool js_effekseer_effekseer_renderParameter_static(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    size_t argc = args.size();
    CC_UNUSED bool ok = true;
    if (argc == 1) {
        HolderType<int, false> arg0 = {};
        ok &= sevalue_to_native(args[0], &arg0, nullptr);
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        cce::RenderParameter* result = cce::effekseer::renderParameter(arg0.value());
        ok &= nativevalue_to_se(result, s.rval(), nullptr /*ctx*/);
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        SE_HOLD_RETURN_VALUE(result, s.thisObject(), s.rval());
        return true;
    }
    SE_REPORT_ERROR("wrong number of arguments: %d, was expecting %d", (int)argc, 1);
    return false;
}
SE_BIND_FUNC(js_effekseer_effekseer_renderParameter_static)

static bool js_effekseer_effekseer_renderParameterCount_static(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    size_t argc = args.size();
    CC_UNUSED bool ok = true;
    if (argc == 0) {
        int result = cce::effekseer::renderParameterCount();
        ok &= nativevalue_to_se(result, s.rval(), nullptr /*ctx*/);
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        SE_HOLD_RETURN_VALUE(result, s.thisObject(), s.rval());
        return true;
    }
    SE_REPORT_ERROR("wrong number of arguments: %d, was expecting %d", (int)argc, 0);
    return false;
}
SE_BIND_FUNC(js_effekseer_effekseer_renderParameterCount_static)

static bool js_effekseer_effekseer_renderStrideBufferCount_static(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    size_t argc = args.size();
    CC_UNUSED bool ok = true;
    if (argc == 0) {
        int32_t result = cce::effekseer::renderStrideBufferCount();
        ok &= nativevalue_to_se(result, s.rval(), nullptr /*ctx*/);
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        SE_HOLD_RETURN_VALUE(result, s.thisObject(), s.rval());
        return true;
    }
    SE_REPORT_ERROR("wrong number of arguments: %d, was expecting %d", (int)argc, 0);
    return false;
}
SE_BIND_FUNC(js_effekseer_effekseer_renderStrideBufferCount_static)

static bool js_effekseer_effekseer_renderStrideBufferParameter_static(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    size_t argc = args.size();
    CC_UNUSED bool ok = true;
    if (argc == 1) {
        HolderType<int, false> arg0 = {};
        ok &= sevalue_to_native(args[0], &arg0, nullptr);
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        cce::StrideBufferParameterEx* result = cce::effekseer::renderStrideBufferParameter(arg0.value());
        ok &= nativevalue_to_se(result, s.rval(), nullptr /*ctx*/);
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        SE_HOLD_RETURN_VALUE(result, s.thisObject(), s.rval());
        return true;
    }
    SE_REPORT_ERROR("wrong number of arguments: %d, was expecting %d", (int)argc, 1);
    return false;
}
SE_BIND_FUNC(js_effekseer_effekseer_renderStrideBufferParameter_static)

static bool js_effekseer_effekseer_resetTime_static(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    size_t argc = args.size();
    if (argc == 0) {
        cce::effekseer::resetTime();
        return true;
    }
    SE_REPORT_ERROR("wrong number of arguments: %d, was expecting %d", (int)argc, 0);
    return false;
}
SE_BIND_FUNC(js_effekseer_effekseer_resetTime_static)

static bool js_effekseer_effekseer_sendTrigger_static(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    size_t argc = args.size();
    CC_UNUSED bool ok = true;
    if (argc == 2) {
        HolderType<int32_t, false> arg0 = {};
        HolderType<int32_t, false> arg1 = {};
        ok &= sevalue_to_native(args[0], &arg0, nullptr);
        ok &= sevalue_to_native(args[1], &arg1, nullptr);
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        cce::effekseer::sendTrigger(arg0.value(), arg1.value());
        return true;
    }
    SE_REPORT_ERROR("wrong number of arguments: %d, was expecting %d", (int)argc, 2);
    return false;
}
SE_BIND_FUNC(js_effekseer_effekseer_sendTrigger_static)

static bool js_effekseer_effekseer_setAllColor_static(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    size_t argc = args.size();
    CC_UNUSED bool ok = true;
    if (argc == 5) {
        HolderType<int32_t, false> arg0 = {};
        HolderType<int, false> arg1 = {};
        HolderType<int, false> arg2 = {};
        HolderType<int, false> arg3 = {};
        HolderType<int, false> arg4 = {};
        ok &= sevalue_to_native(args[0], &arg0, nullptr);
        ok &= sevalue_to_native(args[1], &arg1, nullptr);
        ok &= sevalue_to_native(args[2], &arg2, nullptr);
        ok &= sevalue_to_native(args[3], &arg3, nullptr);
        ok &= sevalue_to_native(args[4], &arg4, nullptr);
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        cce::effekseer::setAllColor(arg0.value(), arg1.value(), arg2.value(), arg3.value(), arg4.value());
        return true;
    }
    SE_REPORT_ERROR("wrong number of arguments: %d, was expecting %d", (int)argc, 5);
    return false;
}
SE_BIND_FUNC(js_effekseer_effekseer_setAllColor_static)

static bool js_effekseer_effekseer_setCameraMatrix_static(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    size_t argc = args.size();
    CC_UNUSED bool ok = true;
    if (argc == 2) {
        HolderType<int, false> arg0 = {};
        HolderType<std::vector<float>, false> arg1 = {};
        ok &= sevalue_to_native(args[0], &arg0, nullptr);
        ok &= sevalue_to_native(args[1], &arg1, nullptr);
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        cce::effekseer::setCameraMatrix(arg0.value(), arg1.value());
        return true;
    }
    SE_REPORT_ERROR("wrong number of arguments: %d, was expecting %d", (int)argc, 2);
    return false;
}
SE_BIND_FUNC(js_effekseer_effekseer_setCameraMatrix_static)

static bool js_effekseer_effekseer_setCurveLoaderEvent_static(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    size_t argc = args.size();
    CC_UNUSED bool ok = true;
    if (argc == 2) {
        HolderType<std::function<std::vector<unsigned char> (std::string)>, false> arg0 = {};
        HolderType<std::function<void (std::string, unsigned int)>, false> arg1 = {};
        do {
            if (args[0].isObject() && args[0].toObject()->isFunction())
            {
                se::Value jsThis(s.thisObject());
                se::Value jsFunc(args[0]);
                jsFunc.toObject()->root();
                auto * thisObj = s.thisObject();
                auto lambda = [=](std::string larg0) -> std::vector<unsigned char> {
                    se::ScriptEngine::getInstance()->clearException();
                    se::AutoHandleScope hs;
        
                    CC_UNUSED bool ok = true;
                    se::ValueArray args;
                    args.resize(1);
                    ok &= nativevalue_to_se(larg0, args[0], nullptr /*ctx*/);
                    se::Value rval;
                    se::Object* funcObj = jsFunc.toObject();
                    bool succeed = funcObj->call(args, thisObj, &rval);
                    if (!succeed) {
                        se::ScriptEngine::getInstance()->clearException();
                    }
                    std::vector<unsigned char> result;
                    ok &= sevalue_to_native(rval, &result, nullptr);
                    SE_PRECONDITION2(ok, result, "lambda function : Error processing return value with type vector<unsigned");
                    return result;
                };
                arg0.data = lambda;
            }
            else
            {
                arg0.data = nullptr;
            }
        } while(false)
        ;
        do {
            if (args[1].isObject() && args[1].toObject()->isFunction())
            {
                se::Value jsThis(s.thisObject());
                se::Value jsFunc(args[1]);
                jsFunc.toObject()->root();
                auto * thisObj = s.thisObject();
                auto lambda = [=](std::string larg0, unsigned int larg1) -> void {
                    se::ScriptEngine::getInstance()->clearException();
                    se::AutoHandleScope hs;
        
                    CC_UNUSED bool ok = true;
                    se::ValueArray args;
                    args.resize(2);
                    ok &= nativevalue_to_se(larg0, args[0], nullptr /*ctx*/);
                    ok &= nativevalue_to_se(larg1, args[1], nullptr /*ctx*/);
                    se::Value rval;
                    se::Object* funcObj = jsFunc.toObject();
                    bool succeed = funcObj->call(args, thisObj, &rval);
                    if (!succeed) {
                        se::ScriptEngine::getInstance()->clearException();
                    }
                };
                arg1.data = lambda;
            }
            else
            {
                arg1.data = nullptr;
            }
        } while(false)
        ;
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        cce::effekseer::setCurveLoaderEvent(arg0.value(), arg1.value());
        return true;
    }
    SE_REPORT_ERROR("wrong number of arguments: %d, was expecting %d", (int)argc, 2);
    return false;
}
SE_BIND_FUNC(js_effekseer_effekseer_setCurveLoaderEvent_static)

static bool js_effekseer_effekseer_setDynamicInput_static(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    size_t argc = args.size();
    CC_UNUSED bool ok = true;
    if (argc == 3) {
        HolderType<int32_t, false> arg0 = {};
        HolderType<int, false> arg1 = {};
        HolderType<float, false> arg2 = {};
        ok &= sevalue_to_native(args[0], &arg0, nullptr);
        ok &= sevalue_to_native(args[1], &arg1, nullptr);
        ok &= sevalue_to_native(args[2], &arg2, nullptr);
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        cce::effekseer::setDynamicInput(arg0.value(), arg1.value(), arg2.value());
        return true;
    }
    SE_REPORT_ERROR("wrong number of arguments: %d, was expecting %d", (int)argc, 3);
    return false;
}
SE_BIND_FUNC(js_effekseer_effekseer_setDynamicInput_static)

static bool js_effekseer_effekseer_setGroupMask_static(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    size_t argc = args.size();
    CC_UNUSED bool ok = true;
    if (argc == 2) {
        HolderType<int32_t, false> arg0 = {};
        HolderType<int64_t, false> arg1 = {};
        ok &= sevalue_to_native(args[0], &arg0, nullptr);
        ok &= sevalue_to_native(args[1], &arg1, nullptr);
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        cce::effekseer::setGroupMask(arg0.value(), arg1.value());
        return true;
    }
    SE_REPORT_ERROR("wrong number of arguments: %d, was expecting %d", (int)argc, 2);
    return false;
}
SE_BIND_FUNC(js_effekseer_effekseer_setGroupMask_static)

static bool js_effekseer_effekseer_setLayer_static(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    size_t argc = args.size();
    CC_UNUSED bool ok = true;
    if (argc == 2) {
        HolderType<int32_t, false> arg0 = {};
        HolderType<int, false> arg1 = {};
        ok &= sevalue_to_native(args[0], &arg0, nullptr);
        ok &= sevalue_to_native(args[1], &arg1, nullptr);
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        cce::effekseer::setLayer(arg0.value(), arg1.value());
        return true;
    }
    SE_REPORT_ERROR("wrong number of arguments: %d, was expecting %d", (int)argc, 2);
    return false;
}
SE_BIND_FUNC(js_effekseer_effekseer_setLayer_static)

static bool js_effekseer_effekseer_setLightAmbientColor_static(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    size_t argc = args.size();
    CC_UNUSED bool ok = true;
    if (argc == 3) {
        HolderType<int32_t, false> arg0 = {};
        HolderType<int32_t, false> arg1 = {};
        HolderType<int32_t, false> arg2 = {};
        ok &= sevalue_to_native(args[0], &arg0, nullptr);
        ok &= sevalue_to_native(args[1], &arg1, nullptr);
        ok &= sevalue_to_native(args[2], &arg2, nullptr);
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        cce::effekseer::setLightAmbientColor(arg0.value(), arg1.value(), arg2.value());
        return true;
    }
    SE_REPORT_ERROR("wrong number of arguments: %d, was expecting %d", (int)argc, 3);
    return false;
}
SE_BIND_FUNC(js_effekseer_effekseer_setLightAmbientColor_static)

static bool js_effekseer_effekseer_setLightColor_static(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    size_t argc = args.size();
    CC_UNUSED bool ok = true;
    if (argc == 3) {
        HolderType<int32_t, false> arg0 = {};
        HolderType<int32_t, false> arg1 = {};
        HolderType<int32_t, false> arg2 = {};
        ok &= sevalue_to_native(args[0], &arg0, nullptr);
        ok &= sevalue_to_native(args[1], &arg1, nullptr);
        ok &= sevalue_to_native(args[2], &arg2, nullptr);
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        cce::effekseer::setLightColor(arg0.value(), arg1.value(), arg2.value());
        return true;
    }
    SE_REPORT_ERROR("wrong number of arguments: %d, was expecting %d", (int)argc, 3);
    return false;
}
SE_BIND_FUNC(js_effekseer_effekseer_setLightColor_static)

static bool js_effekseer_effekseer_setLightDirection_static(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    size_t argc = args.size();
    CC_UNUSED bool ok = true;
    if (argc == 3) {
        HolderType<float, false> arg0 = {};
        HolderType<float, false> arg1 = {};
        HolderType<float, false> arg2 = {};
        ok &= sevalue_to_native(args[0], &arg0, nullptr);
        ok &= sevalue_to_native(args[1], &arg1, nullptr);
        ok &= sevalue_to_native(args[2], &arg2, nullptr);
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        cce::effekseer::setLightDirection(arg0.value(), arg1.value(), arg2.value());
        return true;
    }
    SE_REPORT_ERROR("wrong number of arguments: %d, was expecting %d", (int)argc, 3);
    return false;
}
SE_BIND_FUNC(js_effekseer_effekseer_setLightDirection_static)

static bool js_effekseer_effekseer_setLocation_static(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    size_t argc = args.size();
    CC_UNUSED bool ok = true;
    if (argc == 4) {
        HolderType<int32_t, false> arg0 = {};
        HolderType<float, false> arg1 = {};
        HolderType<float, false> arg2 = {};
        HolderType<float, false> arg3 = {};
        ok &= sevalue_to_native(args[0], &arg0, nullptr);
        ok &= sevalue_to_native(args[1], &arg1, nullptr);
        ok &= sevalue_to_native(args[2], &arg2, nullptr);
        ok &= sevalue_to_native(args[3], &arg3, nullptr);
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        cce::effekseer::setLocation(arg0.value(), arg1.value(), arg2.value(), arg3.value());
        return true;
    }
    SE_REPORT_ERROR("wrong number of arguments: %d, was expecting %d", (int)argc, 4);
    return false;
}
SE_BIND_FUNC(js_effekseer_effekseer_setLocation_static)

static bool js_effekseer_effekseer_setMaterialLoaderEvent_static(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    size_t argc = args.size();
    CC_UNUSED bool ok = true;
    if (argc == 3) {
        HolderType<std::function<std::vector<unsigned char> (int, std::string)>, false> arg0 = {};
        HolderType<std::function<void (std::string, int)>, false> arg1 = {};
        HolderType<std::function<void (int, cce::ShaderEx *, int)>, false> arg2 = {};
        do {
            if (args[0].isObject() && args[0].toObject()->isFunction())
            {
                se::Value jsThis(s.thisObject());
                se::Value jsFunc(args[0]);
                jsFunc.toObject()->root();
                auto * thisObj = s.thisObject();
                auto lambda = [=](int larg0, std::string larg1) -> std::vector<unsigned char> {
                    se::ScriptEngine::getInstance()->clearException();
                    se::AutoHandleScope hs;
        
                    CC_UNUSED bool ok = true;
                    se::ValueArray args;
                    args.resize(2);
                    ok &= nativevalue_to_se(larg0, args[0], nullptr /*ctx*/);
                    ok &= nativevalue_to_se(larg1, args[1], nullptr /*ctx*/);
                    se::Value rval;
                    se::Object* funcObj = jsFunc.toObject();
                    bool succeed = funcObj->call(args, thisObj, &rval);
                    if (!succeed) {
                        se::ScriptEngine::getInstance()->clearException();
                    }
                    std::vector<unsigned char> result;
                    ok &= sevalue_to_native(rval, &result, nullptr);
                    SE_PRECONDITION2(ok, result, "lambda function : Error processing return value with type vector<unsigned");
                    return result;
                };
                arg0.data = lambda;
            }
            else
            {
                arg0.data = nullptr;
            }
        } while(false)
        ;
        do {
            if (args[1].isObject() && args[1].toObject()->isFunction())
            {
                se::Value jsThis(s.thisObject());
                se::Value jsFunc(args[1]);
                jsFunc.toObject()->root();
                auto * thisObj = s.thisObject();
                auto lambda = [=](std::string larg0, int larg1) -> void {
                    se::ScriptEngine::getInstance()->clearException();
                    se::AutoHandleScope hs;
        
                    CC_UNUSED bool ok = true;
                    se::ValueArray args;
                    args.resize(2);
                    ok &= nativevalue_to_se(larg0, args[0], nullptr /*ctx*/);
                    ok &= nativevalue_to_se(larg1, args[1], nullptr /*ctx*/);
                    se::Value rval;
                    se::Object* funcObj = jsFunc.toObject();
                    bool succeed = funcObj->call(args, thisObj, &rval);
                    if (!succeed) {
                        se::ScriptEngine::getInstance()->clearException();
                    }
                };
                arg1.data = lambda;
            }
            else
            {
                arg1.data = nullptr;
            }
        } while(false)
        ;
        do {
            if (args[2].isObject() && args[2].toObject()->isFunction())
            {
                se::Value jsThis(s.thisObject());
                se::Value jsFunc(args[2]);
                jsFunc.toObject()->root();
                auto * thisObj = s.thisObject();
                auto lambda = [=](int larg0, cce::ShaderEx* larg1, int larg2) -> void {
                    se::ScriptEngine::getInstance()->clearException();
                    se::AutoHandleScope hs;
        
                    CC_UNUSED bool ok = true;
                    se::ValueArray args;
                    args.resize(3);
                    ok &= nativevalue_to_se(larg0, args[0], nullptr /*ctx*/);
                    ok &= nativevalue_to_se(larg1, args[1], nullptr /*ctx*/);
                    ok &= nativevalue_to_se(larg2, args[2], nullptr /*ctx*/);
                    se::Value rval;
                    se::Object* funcObj = jsFunc.toObject();
                    bool succeed = funcObj->call(args, thisObj, &rval);
                    if (!succeed) {
                        se::ScriptEngine::getInstance()->clearException();
                    }
                };
                arg2.data = lambda;
            }
            else
            {
                arg2.data = nullptr;
            }
        } while(false)
        ;
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        cce::effekseer::setMaterialLoaderEvent(arg0.value(), arg1.value(), arg2.value());
        return true;
    }
    SE_REPORT_ERROR("wrong number of arguments: %d, was expecting %d", (int)argc, 3);
    return false;
}
SE_BIND_FUNC(js_effekseer_effekseer_setMaterialLoaderEvent_static)

static bool js_effekseer_effekseer_setMatrix_static(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    size_t argc = args.size();
    CC_UNUSED bool ok = true;
    if (argc == 2) {
        HolderType<int32_t, false> arg0 = {};
        HolderType<std::vector<float>, false> arg1 = {};
        ok &= sevalue_to_native(args[0], &arg0, nullptr);
        ok &= sevalue_to_native(args[1], &arg1, nullptr);
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        cce::effekseer::setMatrix(arg0.value(), arg1.value());
        return true;
    }
    SE_REPORT_ERROR("wrong number of arguments: %d, was expecting %d", (int)argc, 2);
    return false;
}
SE_BIND_FUNC(js_effekseer_effekseer_setMatrix_static)

static bool js_effekseer_effekseer_setMeshLoaderEvent_static(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    size_t argc = args.size();
    CC_UNUSED bool ok = true;
    if (argc == 2) {
        HolderType<std::function<int (std::vector<float>, int, std::vector<int>, int)>, false> arg0 = {};
        HolderType<std::function<void (int, int)>, false> arg1 = {};
        do {
            if (args[0].isObject() && args[0].toObject()->isFunction())
            {
                se::Value jsThis(s.thisObject());
                se::Value jsFunc(args[0]);
                jsFunc.toObject()->root();
                auto * thisObj = s.thisObject();
                auto lambda = [=](std::vector<float> larg0, int larg1, std::vector<int> larg2, int larg3) -> int {
                    se::ScriptEngine::getInstance()->clearException();
                    se::AutoHandleScope hs;
        
                    CC_UNUSED bool ok = true;
                    se::ValueArray args;
                    args.resize(4);
                    ok &= nativevalue_to_se(larg0, args[0], nullptr /*ctx*/);
                    ok &= nativevalue_to_se(larg1, args[1], nullptr /*ctx*/);
                    ok &= nativevalue_to_se(larg2, args[2], nullptr /*ctx*/);
                    ok &= nativevalue_to_se(larg3, args[3], nullptr /*ctx*/);
                    se::Value rval;
                    se::Object* funcObj = jsFunc.toObject();
                    bool succeed = funcObj->call(args, thisObj, &rval);
                    if (!succeed) {
                        se::ScriptEngine::getInstance()->clearException();
                    }
                    int result;
                    ok &= sevalue_to_native(rval, &result, nullptr);
                    SE_PRECONDITION2(ok, result, "lambda function : Error processing return value with type int");
                    return result;
                };
                arg0.data = lambda;
            }
            else
            {
                arg0.data = nullptr;
            }
        } while(false)
        ;
        do {
            if (args[1].isObject() && args[1].toObject()->isFunction())
            {
                se::Value jsThis(s.thisObject());
                se::Value jsFunc(args[1]);
                jsFunc.toObject()->root();
                auto * thisObj = s.thisObject();
                auto lambda = [=](int larg0, int larg1) -> void {
                    se::ScriptEngine::getInstance()->clearException();
                    se::AutoHandleScope hs;
        
                    CC_UNUSED bool ok = true;
                    se::ValueArray args;
                    args.resize(2);
                    ok &= nativevalue_to_se(larg0, args[0], nullptr /*ctx*/);
                    ok &= nativevalue_to_se(larg1, args[1], nullptr /*ctx*/);
                    se::Value rval;
                    se::Object* funcObj = jsFunc.toObject();
                    bool succeed = funcObj->call(args, thisObj, &rval);
                    if (!succeed) {
                        se::ScriptEngine::getInstance()->clearException();
                    }
                };
                arg1.data = lambda;
            }
            else
            {
                arg1.data = nullptr;
            }
        } while(false)
        ;
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        cce::effekseer::setMeshLoaderEvent(arg0.value(), arg1.value());
        return true;
    }
    SE_REPORT_ERROR("wrong number of arguments: %d, was expecting %d", (int)argc, 2);
    return false;
}
SE_BIND_FUNC(js_effekseer_effekseer_setMeshLoaderEvent_static)

static bool js_effekseer_effekseer_setModelLoaderEvent_static(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    size_t argc = args.size();
    CC_UNUSED bool ok = true;
    if (argc == 3) {
        HolderType<std::function<std::vector<unsigned char> (int, std::string)>, false> arg0 = {};
        HolderType<std::function<void (int, cce::ModelEx *)>, false> arg1 = {};
        HolderType<std::function<void (int, std::string)>, false> arg2 = {};
        do {
            if (args[0].isObject() && args[0].toObject()->isFunction())
            {
                se::Value jsThis(s.thisObject());
                se::Value jsFunc(args[0]);
                jsFunc.toObject()->root();
                auto * thisObj = s.thisObject();
                auto lambda = [=](int larg0, std::string larg1) -> std::vector<unsigned char> {
                    se::ScriptEngine::getInstance()->clearException();
                    se::AutoHandleScope hs;
        
                    CC_UNUSED bool ok = true;
                    se::ValueArray args;
                    args.resize(2);
                    ok &= nativevalue_to_se(larg0, args[0], nullptr /*ctx*/);
                    ok &= nativevalue_to_se(larg1, args[1], nullptr /*ctx*/);
                    se::Value rval;
                    se::Object* funcObj = jsFunc.toObject();
                    bool succeed = funcObj->call(args, thisObj, &rval);
                    if (!succeed) {
                        se::ScriptEngine::getInstance()->clearException();
                    }
                    std::vector<unsigned char> result;
                    ok &= sevalue_to_native(rval, &result, nullptr);
                    SE_PRECONDITION2(ok, result, "lambda function : Error processing return value with type vector<unsigned");
                    return result;
                };
                arg0.data = lambda;
            }
            else
            {
                arg0.data = nullptr;
            }
        } while(false)
        ;
        do {
            if (args[1].isObject() && args[1].toObject()->isFunction())
            {
                se::Value jsThis(s.thisObject());
                se::Value jsFunc(args[1]);
                jsFunc.toObject()->root();
                auto * thisObj = s.thisObject();
                auto lambda = [=](int larg0, cce::ModelEx* larg1) -> void {
                    se::ScriptEngine::getInstance()->clearException();
                    se::AutoHandleScope hs;
        
                    CC_UNUSED bool ok = true;
                    se::ValueArray args;
                    args.resize(2);
                    ok &= nativevalue_to_se(larg0, args[0], nullptr /*ctx*/);
                    ok &= nativevalue_to_se(larg1, args[1], nullptr /*ctx*/);
                    se::Value rval;
                    se::Object* funcObj = jsFunc.toObject();
                    bool succeed = funcObj->call(args, thisObj, &rval);
                    if (!succeed) {
                        se::ScriptEngine::getInstance()->clearException();
                    }
                };
                arg1.data = lambda;
            }
            else
            {
                arg1.data = nullptr;
            }
        } while(false)
        ;
        do {
            if (args[2].isObject() && args[2].toObject()->isFunction())
            {
                se::Value jsThis(s.thisObject());
                se::Value jsFunc(args[2]);
                jsFunc.toObject()->root();
                auto * thisObj = s.thisObject();
                auto lambda = [=](int larg0, std::string larg1) -> void {
                    se::ScriptEngine::getInstance()->clearException();
                    se::AutoHandleScope hs;
        
                    CC_UNUSED bool ok = true;
                    se::ValueArray args;
                    args.resize(2);
                    ok &= nativevalue_to_se(larg0, args[0], nullptr /*ctx*/);
                    ok &= nativevalue_to_se(larg1, args[1], nullptr /*ctx*/);
                    se::Value rval;
                    se::Object* funcObj = jsFunc.toObject();
                    bool succeed = funcObj->call(args, thisObj, &rval);
                    if (!succeed) {
                        se::ScriptEngine::getInstance()->clearException();
                    }
                };
                arg2.data = lambda;
            }
            else
            {
                arg2.data = nullptr;
            }
        } while(false)
        ;
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        cce::effekseer::setModelLoaderEvent(arg0.value(), arg1.value(), arg2.value());
        return true;
    }
    SE_REPORT_ERROR("wrong number of arguments: %d, was expecting %d", (int)argc, 3);
    return false;
}
SE_BIND_FUNC(js_effekseer_effekseer_setModelLoaderEvent_static)

static bool js_effekseer_effekseer_setPaused_static(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    size_t argc = args.size();
    CC_UNUSED bool ok = true;
    if (argc == 2) {
        HolderType<int32_t, false> arg0 = {};
        HolderType<int, false> arg1 = {};
        ok &= sevalue_to_native(args[0], &arg0, nullptr);
        ok &= sevalue_to_native(args[1], &arg1, nullptr);
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        cce::effekseer::setPaused(arg0.value(), arg1.value());
        return true;
    }
    SE_REPORT_ERROR("wrong number of arguments: %d, was expecting %d", (int)argc, 2);
    return false;
}
SE_BIND_FUNC(js_effekseer_effekseer_setPaused_static)

static bool js_effekseer_effekseer_setPausedToAllEffects_static(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    size_t argc = args.size();
    CC_UNUSED bool ok = true;
    if (argc == 1) {
        HolderType<int, false> arg0 = {};
        ok &= sevalue_to_native(args[0], &arg0, nullptr);
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        cce::effekseer::setPausedToAllEffects(arg0.value());
        return true;
    }
    SE_REPORT_ERROR("wrong number of arguments: %d, was expecting %d", (int)argc, 1);
    return false;
}
SE_BIND_FUNC(js_effekseer_effekseer_setPausedToAllEffects_static)

static bool js_effekseer_effekseer_setProjectionMatrix_static(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    size_t argc = args.size();
    CC_UNUSED bool ok = true;
    if (argc == 2) {
        HolderType<int, false> arg0 = {};
        HolderType<std::vector<float>, false> arg1 = {};
        ok &= sevalue_to_native(args[0], &arg0, nullptr);
        ok &= sevalue_to_native(args[1], &arg1, nullptr);
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        cce::effekseer::setProjectionMatrix(arg0.value(), arg1.value());
        return true;
    }
    SE_REPORT_ERROR("wrong number of arguments: %d, was expecting %d", (int)argc, 2);
    return false;
}
SE_BIND_FUNC(js_effekseer_effekseer_setProjectionMatrix_static)

static bool js_effekseer_effekseer_setRemovingCallback_static(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    size_t argc = args.size();
    CC_UNUSED bool ok = true;
    if (argc == 2) {
        HolderType<int32_t, false> arg0 = {};
        HolderType<std::function<void (int)>, false> arg1 = {};
        ok &= sevalue_to_native(args[0], &arg0, nullptr);
        do {
            if (args[1].isObject() && args[1].toObject()->isFunction())
            {
                se::Value jsThis(s.thisObject());
                se::Value jsFunc(args[1]);
                jsFunc.toObject()->root();
                auto * thisObj = s.thisObject();
                auto lambda = [=](int larg0) -> void {
                    se::ScriptEngine::getInstance()->clearException();
                    se::AutoHandleScope hs;
        
                    CC_UNUSED bool ok = true;
                    se::ValueArray args;
                    args.resize(1);
                    ok &= nativevalue_to_se(larg0, args[0], nullptr /*ctx*/);
                    se::Value rval;
                    se::Object* funcObj = jsFunc.toObject();
                    bool succeed = funcObj->call(args, thisObj, &rval);
                    if (!succeed) {
                        se::ScriptEngine::getInstance()->clearException();
                    }
                };
                arg1.data = lambda;
            }
            else
            {
                arg1.data = nullptr;
            }
        } while(false)
        ;
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        cce::effekseer::setRemovingCallback(arg0.value(), arg1.value());
        return true;
    }
    SE_REPORT_ERROR("wrong number of arguments: %d, was expecting %d", (int)argc, 2);
    return false;
}
SE_BIND_FUNC(js_effekseer_effekseer_setRemovingCallback_static)

static bool js_effekseer_effekseer_setRenderSettings_static(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    size_t argc = args.size();
    CC_UNUSED bool ok = true;
    if (argc == 2) {
        HolderType<int, false> arg0 = {};
        HolderType<bool, false> arg1 = {};
        ok &= sevalue_to_native(args[0], &arg0, nullptr);
        ok &= sevalue_to_native(args[1], &arg1, nullptr);
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        cce::effekseer::setRenderSettings(arg0.value(), arg1.value());
        return true;
    }
    SE_REPORT_ERROR("wrong number of arguments: %d, was expecting %d", (int)argc, 2);
    return false;
}
SE_BIND_FUNC(js_effekseer_effekseer_setRenderSettings_static)

static bool js_effekseer_effekseer_setRenderTargetProperty_static(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    size_t argc = args.size();
    CC_UNUSED bool ok = true;
    if (argc == 5) {
        HolderType<int, false> arg0 = {};
        HolderType<Effekseer::Backend::TextureFormatType, false> arg1 = {};
        HolderType<Effekseer::Backend::TextureFormatType, false> arg2 = {};
        HolderType<int, false> arg3 = {};
        HolderType<int, false> arg4 = {};
        ok &= sevalue_to_native(args[0], &arg0, nullptr);
        ok &= sevalue_to_native(args[1], &arg1, nullptr);
        ok &= sevalue_to_native(args[2], &arg2, nullptr);
        ok &= sevalue_to_native(args[3], &arg3, nullptr);
        ok &= sevalue_to_native(args[4], &arg4, nullptr);
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        cce::effekseer::setRenderTargetProperty(arg0.value(), arg1.value(), arg2.value(), arg3.value(), arg4.value());
        return true;
    }
    SE_REPORT_ERROR("wrong number of arguments: %d, was expecting %d", (int)argc, 5);
    return false;
}
SE_BIND_FUNC(js_effekseer_effekseer_setRenderTargetProperty_static)

static bool js_effekseer_effekseer_setRenderingCameraCullingMask_static(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    size_t argc = args.size();
    CC_UNUSED bool ok = true;
    if (argc == 2) {
        HolderType<int, false> arg0 = {};
        HolderType<int32_t, false> arg1 = {};
        ok &= sevalue_to_native(args[0], &arg0, nullptr);
        ok &= sevalue_to_native(args[1], &arg1, nullptr);
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        cce::effekseer::setRenderingCameraCullingMask(arg0.value(), arg1.value());
        return true;
    }
    SE_REPORT_ERROR("wrong number of arguments: %d, was expecting %d", (int)argc, 2);
    return false;
}
SE_BIND_FUNC(js_effekseer_effekseer_setRenderingCameraCullingMask_static)

static bool js_effekseer_effekseer_setRotation_static(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    size_t argc = args.size();
    CC_UNUSED bool ok = true;
    if (argc == 5) {
        HolderType<int32_t, false> arg0 = {};
        HolderType<float, false> arg1 = {};
        HolderType<float, false> arg2 = {};
        HolderType<float, false> arg3 = {};
        HolderType<float, false> arg4 = {};
        ok &= sevalue_to_native(args[0], &arg0, nullptr);
        ok &= sevalue_to_native(args[1], &arg1, nullptr);
        ok &= sevalue_to_native(args[2], &arg2, nullptr);
        ok &= sevalue_to_native(args[3], &arg3, nullptr);
        ok &= sevalue_to_native(args[4], &arg4, nullptr);
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        cce::effekseer::setRotation(arg0.value(), arg1.value(), arg2.value(), arg3.value(), arg4.value());
        return true;
    }
    SE_REPORT_ERROR("wrong number of arguments: %d, was expecting %d", (int)argc, 5);
    return false;
}
SE_BIND_FUNC(js_effekseer_effekseer_setRotation_static)

static bool js_effekseer_effekseer_setScale_static(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    size_t argc = args.size();
    CC_UNUSED bool ok = true;
    if (argc == 4) {
        HolderType<int32_t, false> arg0 = {};
        HolderType<float, false> arg1 = {};
        HolderType<float, false> arg2 = {};
        HolderType<float, false> arg3 = {};
        ok &= sevalue_to_native(args[0], &arg0, nullptr);
        ok &= sevalue_to_native(args[1], &arg1, nullptr);
        ok &= sevalue_to_native(args[2], &arg2, nullptr);
        ok &= sevalue_to_native(args[3], &arg3, nullptr);
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        cce::effekseer::setScale(arg0.value(), arg1.value(), arg2.value(), arg3.value());
        return true;
    }
    SE_REPORT_ERROR("wrong number of arguments: %d, was expecting %d", (int)argc, 4);
    return false;
}
SE_BIND_FUNC(js_effekseer_effekseer_setScale_static)

static bool js_effekseer_effekseer_setShown_static(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    size_t argc = args.size();
    CC_UNUSED bool ok = true;
    if (argc == 2) {
        HolderType<int32_t, false> arg0 = {};
        HolderType<int, false> arg1 = {};
        ok &= sevalue_to_native(args[0], &arg0, nullptr);
        ok &= sevalue_to_native(args[1], &arg1, nullptr);
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        cce::effekseer::setShown(arg0.value(), arg1.value());
        return true;
    }
    SE_REPORT_ERROR("wrong number of arguments: %d, was expecting %d", (int)argc, 2);
    return false;
}
SE_BIND_FUNC(js_effekseer_effekseer_setShown_static)

static bool js_effekseer_effekseer_setSoundLoaderEvent_static(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    size_t argc = args.size();
    CC_UNUSED bool ok = true;
    if (argc == 2) {
        HolderType<std::function<unsigned int (std::string)>, false> arg0 = {};
        HolderType<std::function<void (std::string, int)>, false> arg1 = {};
        do {
            if (args[0].isObject() && args[0].toObject()->isFunction())
            {
                se::Value jsThis(s.thisObject());
                se::Value jsFunc(args[0]);
                jsFunc.toObject()->root();
                auto * thisObj = s.thisObject();
                auto lambda = [=](std::string larg0) -> unsigned {
                    se::ScriptEngine::getInstance()->clearException();
                    se::AutoHandleScope hs;
        
                    CC_UNUSED bool ok = true;
                    se::ValueArray args;
                    args.resize(1);
                    ok &= nativevalue_to_se(larg0, args[0], nullptr /*ctx*/);
                    se::Value rval;
                    se::Object* funcObj = jsFunc.toObject();
                    bool succeed = funcObj->call(args, thisObj, &rval);
                    if (!succeed) {
                        se::ScriptEngine::getInstance()->clearException();
                    }
                    unsigned result;
                    ok &= sevalue_to_native(rval, &result, nullptr);
                    SE_PRECONDITION2(ok, result, "lambda function : Error processing return value with type unsigned");
                    return result;
                };
                arg0.data = lambda;
            }
            else
            {
                arg0.data = nullptr;
            }
        } while(false)
        ;
        do {
            if (args[1].isObject() && args[1].toObject()->isFunction())
            {
                se::Value jsThis(s.thisObject());
                se::Value jsFunc(args[1]);
                jsFunc.toObject()->root();
                auto * thisObj = s.thisObject();
                auto lambda = [=](std::string larg0, int larg1) -> void {
                    se::ScriptEngine::getInstance()->clearException();
                    se::AutoHandleScope hs;
        
                    CC_UNUSED bool ok = true;
                    se::ValueArray args;
                    args.resize(2);
                    ok &= nativevalue_to_se(larg0, args[0], nullptr /*ctx*/);
                    ok &= nativevalue_to_se(larg1, args[1], nullptr /*ctx*/);
                    se::Value rval;
                    se::Object* funcObj = jsFunc.toObject();
                    bool succeed = funcObj->call(args, thisObj, &rval);
                    if (!succeed) {
                        se::ScriptEngine::getInstance()->clearException();
                    }
                };
                arg1.data = lambda;
            }
            else
            {
                arg1.data = nullptr;
            }
        } while(false)
        ;
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        cce::effekseer::setSoundLoaderEvent(arg0.value(), arg1.value());
        return true;
    }
    SE_REPORT_ERROR("wrong number of arguments: %d, was expecting %d", (int)argc, 2);
    return false;
}
SE_BIND_FUNC(js_effekseer_effekseer_setSoundLoaderEvent_static)

static bool js_effekseer_effekseer_setSoundPlayerEvent_static(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    size_t argc = args.size();
    CC_UNUSED bool ok = true;
    if (argc == 5) {
        HolderType<std::function<void (void *, unsigned int, float, float, float, bool, float, float, float, float)>, false> arg0 = {};
        HolderType<std::function<void (void *)>, false> arg1 = {};
        HolderType<std::function<void (void *, bool)>, false> arg2 = {};
        HolderType<std::function<bool (void *)>, false> arg3 = {};
        HolderType<std::function<void ()>, false> arg4 = {};
        do {
            if (args[0].isObject() && args[0].toObject()->isFunction())
            {
                se::Value jsThis(s.thisObject());
                se::Value jsFunc(args[0]);
                jsFunc.toObject()->root();
                auto * thisObj = s.thisObject();
                auto lambda = [=](void* larg0, unsigned int larg1, float larg2, float larg3, float larg4, bool larg5, float larg6, float larg7, float larg8, float larg9) -> void {
                    se::ScriptEngine::getInstance()->clearException();
                    se::AutoHandleScope hs;
        
                    CC_UNUSED bool ok = true;
                    se::ValueArray args;
                    args.resize(10);
                    ok &= nativevalue_to_se(larg0, args[0], nullptr /*ctx*/);
                    ok &= nativevalue_to_se(larg1, args[1], nullptr /*ctx*/);
                    ok &= nativevalue_to_se(larg2, args[2], nullptr /*ctx*/);
                    ok &= nativevalue_to_se(larg3, args[3], nullptr /*ctx*/);
                    ok &= nativevalue_to_se(larg4, args[4], nullptr /*ctx*/);
                    ok &= nativevalue_to_se(larg5, args[5], nullptr /*ctx*/);
                    ok &= nativevalue_to_se(larg6, args[6], nullptr /*ctx*/);
                    ok &= nativevalue_to_se(larg7, args[7], nullptr /*ctx*/);
                    ok &= nativevalue_to_se(larg8, args[8], nullptr /*ctx*/);
                    ok &= nativevalue_to_se(larg9, args[9], nullptr /*ctx*/);
                    se::Value rval;
                    se::Object* funcObj = jsFunc.toObject();
                    bool succeed = funcObj->call(args, thisObj, &rval);
                    if (!succeed) {
                        se::ScriptEngine::getInstance()->clearException();
                    }
                };
                arg0.data = lambda;
            }
            else
            {
                arg0.data = nullptr;
            }
        } while(false)
        ;
        do {
            if (args[1].isObject() && args[1].toObject()->isFunction())
            {
                se::Value jsThis(s.thisObject());
                se::Value jsFunc(args[1]);
                jsFunc.toObject()->root();
                auto * thisObj = s.thisObject();
                auto lambda = [=](void* larg0) -> void {
                    se::ScriptEngine::getInstance()->clearException();
                    se::AutoHandleScope hs;
        
                    CC_UNUSED bool ok = true;
                    se::ValueArray args;
                    args.resize(1);
                    ok &= nativevalue_to_se(larg0, args[0], nullptr /*ctx*/);
                    se::Value rval;
                    se::Object* funcObj = jsFunc.toObject();
                    bool succeed = funcObj->call(args, thisObj, &rval);
                    if (!succeed) {
                        se::ScriptEngine::getInstance()->clearException();
                    }
                };
                arg1.data = lambda;
            }
            else
            {
                arg1.data = nullptr;
            }
        } while(false)
        ;
        do {
            if (args[2].isObject() && args[2].toObject()->isFunction())
            {
                se::Value jsThis(s.thisObject());
                se::Value jsFunc(args[2]);
                jsFunc.toObject()->root();
                auto * thisObj = s.thisObject();
                auto lambda = [=](void* larg0, bool larg1) -> void {
                    se::ScriptEngine::getInstance()->clearException();
                    se::AutoHandleScope hs;
        
                    CC_UNUSED bool ok = true;
                    se::ValueArray args;
                    args.resize(2);
                    ok &= nativevalue_to_se(larg0, args[0], nullptr /*ctx*/);
                    ok &= nativevalue_to_se(larg1, args[1], nullptr /*ctx*/);
                    se::Value rval;
                    se::Object* funcObj = jsFunc.toObject();
                    bool succeed = funcObj->call(args, thisObj, &rval);
                    if (!succeed) {
                        se::ScriptEngine::getInstance()->clearException();
                    }
                };
                arg2.data = lambda;
            }
            else
            {
                arg2.data = nullptr;
            }
        } while(false)
        ;
        do {
            if (args[3].isObject() && args[3].toObject()->isFunction())
            {
                se::Value jsThis(s.thisObject());
                se::Value jsFunc(args[3]);
                jsFunc.toObject()->root();
                auto * thisObj = s.thisObject();
                auto lambda = [=](void* larg0) -> bool {
                    se::ScriptEngine::getInstance()->clearException();
                    se::AutoHandleScope hs;
        
                    CC_UNUSED bool ok = true;
                    se::ValueArray args;
                    args.resize(1);
                    ok &= nativevalue_to_se(larg0, args[0], nullptr /*ctx*/);
                    se::Value rval;
                    se::Object* funcObj = jsFunc.toObject();
                    bool succeed = funcObj->call(args, thisObj, &rval);
                    if (!succeed) {
                        se::ScriptEngine::getInstance()->clearException();
                    }
                    bool result;
                    ok &= sevalue_to_native(rval, &result, nullptr);
                    SE_PRECONDITION2(ok, result, "lambda function : Error processing return value with type bool");
                    return result;
                };
                arg3.data = lambda;
            }
            else
            {
                arg3.data = nullptr;
            }
        } while(false)
        ;
        do {
            if (args[4].isObject() && args[4].toObject()->isFunction())
            {
                se::Value jsThis(s.thisObject());
                se::Value jsFunc(args[4]);
                jsFunc.toObject()->root();
                auto * thisObj = s.thisObject();
                auto lambda = [=]() -> void {
                    se::ScriptEngine::getInstance()->clearException();
                    se::AutoHandleScope hs;
        
                    se::Value rval;
                    se::Object* funcObj = jsFunc.toObject();
                    bool succeed = funcObj->call(se::EmptyValueArray, thisObj, &rval);
                    if (!succeed) {
                        se::ScriptEngine::getInstance()->clearException();
                    }
                };
                arg4.data = lambda;
            }
            else
            {
                arg4.data = nullptr;
            }
        } while(false)
        ;
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        cce::effekseer::setSoundPlayerEvent(arg0.value(), arg1.value(), arg2.value(), arg3.value(), arg4.value());
        return true;
    }
    SE_REPORT_ERROR("wrong number of arguments: %d, was expecting %d", (int)argc, 5);
    return false;
}
SE_BIND_FUNC(js_effekseer_effekseer_setSoundPlayerEvent_static)

static bool js_effekseer_effekseer_setSpeed_static(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    size_t argc = args.size();
    CC_UNUSED bool ok = true;
    if (argc == 2) {
        HolderType<int32_t, false> arg0 = {};
        HolderType<float, false> arg1 = {};
        ok &= sevalue_to_native(args[0], &arg0, nullptr);
        ok &= sevalue_to_native(args[1], &arg1, nullptr);
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        cce::effekseer::setSpeed(arg0.value(), arg1.value());
        return true;
    }
    SE_REPORT_ERROR("wrong number of arguments: %d, was expecting %d", (int)argc, 2);
    return false;
}
SE_BIND_FUNC(js_effekseer_effekseer_setSpeed_static)

static bool js_effekseer_effekseer_setStereoRenderingMatrix_static(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    size_t argc = args.size();
    CC_UNUSED bool ok = true;
    if (argc == 7) {
        HolderType<int, false> arg0 = {};
        HolderType<int, false> arg1 = {};
        HolderType<std::vector<float>, false> arg2 = {};
        HolderType<std::vector<float>, false> arg3 = {};
        HolderType<std::vector<float>, false> arg4 = {};
        HolderType<std::vector<float>, false> arg5 = {};
        HolderType<std::vector<float>, false> arg6 = {};
        ok &= sevalue_to_native(args[0], &arg0, nullptr);
        ok &= sevalue_to_native(args[1], &arg1, nullptr);
        ok &= sevalue_to_native(args[2], &arg2, nullptr);
        ok &= sevalue_to_native(args[3], &arg3, nullptr);
        ok &= sevalue_to_native(args[4], &arg4, nullptr);
        ok &= sevalue_to_native(args[5], &arg5, nullptr);
        ok &= sevalue_to_native(args[6], &arg6, nullptr);
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        cce::effekseer::setStereoRenderingMatrix(arg0.value(), arg1.value(), arg2.value(), arg3.value(), arg4.value(), arg5.value(), arg6.value());
        return true;
    }
    SE_REPORT_ERROR("wrong number of arguments: %d, was expecting %d", (int)argc, 7);
    return false;
}
SE_BIND_FUNC(js_effekseer_effekseer_setStereoRenderingMatrix_static)

static bool js_effekseer_effekseer_setTargetLocation_static(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    size_t argc = args.size();
    CC_UNUSED bool ok = true;
    if (argc == 4) {
        HolderType<int32_t, false> arg0 = {};
        HolderType<float, false> arg1 = {};
        HolderType<float, false> arg2 = {};
        HolderType<float, false> arg3 = {};
        ok &= sevalue_to_native(args[0], &arg0, nullptr);
        ok &= sevalue_to_native(args[1], &arg1, nullptr);
        ok &= sevalue_to_native(args[2], &arg2, nullptr);
        ok &= sevalue_to_native(args[3], &arg3, nullptr);
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        cce::effekseer::setTargetLocation(arg0.value(), arg1.value(), arg2.value(), arg3.value());
        return true;
    }
    SE_REPORT_ERROR("wrong number of arguments: %d, was expecting %d", (int)argc, 4);
    return false;
}
SE_BIND_FUNC(js_effekseer_effekseer_setTargetLocation_static)

static bool js_effekseer_effekseer_setTextureLoaderEvent_static(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    size_t argc = args.size();
    CC_UNUSED bool ok = true;
    if (argc == 2) {
        HolderType<std::function<void (int, std::string)>, false> arg0 = {};
        HolderType<std::function<void (std::string, int)>, false> arg1 = {};
        do {
            if (args[0].isObject() && args[0].toObject()->isFunction())
            {
                se::Value jsThis(s.thisObject());
                se::Value jsFunc(args[0]);
                jsFunc.toObject()->root();
                auto * thisObj = s.thisObject();
                auto lambda = [=](int larg0, std::string larg1) -> void {
                    se::ScriptEngine::getInstance()->clearException();
                    se::AutoHandleScope hs;
        
                    CC_UNUSED bool ok = true;
                    se::ValueArray args;
                    args.resize(2);
                    ok &= nativevalue_to_se(larg0, args[0], nullptr /*ctx*/);
                    ok &= nativevalue_to_se(larg1, args[1], nullptr /*ctx*/);
                    se::Value rval;
                    se::Object* funcObj = jsFunc.toObject();
                    bool succeed = funcObj->call(args, thisObj, &rval);
                    if (!succeed) {
                        se::ScriptEngine::getInstance()->clearException();
                    }
                };
                arg0.data = lambda;
            }
            else
            {
                arg0.data = nullptr;
            }
        } while(false)
        ;
        do {
            if (args[1].isObject() && args[1].toObject()->isFunction())
            {
                se::Value jsThis(s.thisObject());
                se::Value jsFunc(args[1]);
                jsFunc.toObject()->root();
                auto * thisObj = s.thisObject();
                auto lambda = [=](std::string larg0, int larg1) -> void {
                    se::ScriptEngine::getInstance()->clearException();
                    se::AutoHandleScope hs;
        
                    CC_UNUSED bool ok = true;
                    se::ValueArray args;
                    args.resize(2);
                    ok &= nativevalue_to_se(larg0, args[0], nullptr /*ctx*/);
                    ok &= nativevalue_to_se(larg1, args[1], nullptr /*ctx*/);
                    se::Value rval;
                    se::Object* funcObj = jsFunc.toObject();
                    bool succeed = funcObj->call(args, thisObj, &rval);
                    if (!succeed) {
                        se::ScriptEngine::getInstance()->clearException();
                    }
                };
                arg1.data = lambda;
            }
            else
            {
                arg1.data = nullptr;
            }
        } while(false)
        ;
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        cce::effekseer::setTextureLoaderEvent(arg0.value(), arg1.value());
        return true;
    }
    SE_REPORT_ERROR("wrong number of arguments: %d, was expecting %d", (int)argc, 2);
    return false;
}
SE_BIND_FUNC(js_effekseer_effekseer_setTextureLoaderEvent_static)

static bool js_effekseer_effekseer_setTimeScaleByGroup_static(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    size_t argc = args.size();
    CC_UNUSED bool ok = true;
    if (argc == 2) {
        HolderType<int64_t, false> arg0 = {};
        HolderType<float, false> arg1 = {};
        ok &= sevalue_to_native(args[0], &arg0, nullptr);
        ok &= sevalue_to_native(args[1], &arg1, nullptr);
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        cce::effekseer::setTimeScaleByGroup(arg0.value(), arg1.value());
        return true;
    }
    SE_REPORT_ERROR("wrong number of arguments: %d, was expecting %d", (int)argc, 2);
    return false;
}
SE_BIND_FUNC(js_effekseer_effekseer_setTimeScaleByGroup_static)

static bool js_effekseer_effekseer_setUserData_static(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    size_t argc = args.size();
    CC_UNUSED bool ok = true;
    if (argc == 2) {
        HolderType<int32_t, false> arg0 = {};
        HolderType<int32_t, false> arg1 = {};
        ok &= sevalue_to_native(args[0], &arg0, nullptr);
        ok &= sevalue_to_native(args[1], &arg1, nullptr);
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        cce::effekseer::setUserData(arg0.value(), arg1.value());
        return true;
    }
    SE_REPORT_ERROR("wrong number of arguments: %d, was expecting %d", (int)argc, 2);
    return false;
}
SE_BIND_FUNC(js_effekseer_effekseer_setUserData_static)

static bool js_effekseer_effekseer_stopAllEffects_static(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    size_t argc = args.size();
    if (argc == 0) {
        cce::effekseer::stopAllEffects();
        return true;
    }
    SE_REPORT_ERROR("wrong number of arguments: %d, was expecting %d", (int)argc, 0);
    return false;
}
SE_BIND_FUNC(js_effekseer_effekseer_stopAllEffects_static)

static bool js_effekseer_effekseer_stopEffect_static(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    size_t argc = args.size();
    CC_UNUSED bool ok = true;
    if (argc == 1) {
        HolderType<int32_t, false> arg0 = {};
        ok &= sevalue_to_native(args[0], &arg0, nullptr);
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        cce::effekseer::stopEffect(arg0.value());
        return true;
    }
    SE_REPORT_ERROR("wrong number of arguments: %d, was expecting %d", (int)argc, 1);
    return false;
}
SE_BIND_FUNC(js_effekseer_effekseer_stopEffect_static)

static bool js_effekseer_effekseer_stopRoot_static(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    size_t argc = args.size();
    CC_UNUSED bool ok = true;
    if (argc == 1) {
        HolderType<int32_t, false> arg0 = {};
        ok &= sevalue_to_native(args[0], &arg0, nullptr);
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        cce::effekseer::stopRoot(arg0.value());
        return true;
    }
    SE_REPORT_ERROR("wrong number of arguments: %d, was expecting %d", (int)argc, 1);
    return false;
}
SE_BIND_FUNC(js_effekseer_effekseer_stopRoot_static)

static bool js_effekseer_effekseer_unloadResources_static(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    size_t argc = args.size();
    CC_UNUSED bool ok = true;
    if (argc == 1) {
        HolderType<int32_t, false> arg0 = {};
        ok &= sevalue_to_native(args[0], &arg0, nullptr);
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        cce::effekseer::unloadResources(arg0.value());
        return true;
    }
    SE_REPORT_ERROR("wrong number of arguments: %d, was expecting %d", (int)argc, 1);
    return false;
}
SE_BIND_FUNC(js_effekseer_effekseer_unloadResources_static)

static bool js_effekseer_effekseer_update_static(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    size_t argc = args.size();
    CC_UNUSED bool ok = true;
    if (argc == 1) {
        HolderType<float, false> arg0 = {};
        ok &= sevalue_to_native(args[0], &arg0, nullptr);
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        cce::effekseer::update(arg0.value());
        return true;
    }
    SE_REPORT_ERROR("wrong number of arguments: %d, was expecting %d", (int)argc, 1);
    return false;
}
SE_BIND_FUNC(js_effekseer_effekseer_update_static)

static bool js_effekseer_effekseer_updateHandle_static(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    size_t argc = args.size();
    CC_UNUSED bool ok = true;
    if (argc == 2) {
        HolderType<int32_t, false> arg0 = {};
        HolderType<float, false> arg1 = {};
        ok &= sevalue_to_native(args[0], &arg0, nullptr);
        ok &= sevalue_to_native(args[1], &arg1, nullptr);
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        cce::effekseer::updateHandle(arg0.value(), arg1.value());
        return true;
    }
    SE_REPORT_ERROR("wrong number of arguments: %d, was expecting %d", (int)argc, 2);
    return false;
}
SE_BIND_FUNC(js_effekseer_effekseer_updateHandle_static)

static bool js_effekseer_effekseer_updateHandleToMoveToFrame_static(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    size_t argc = args.size();
    CC_UNUSED bool ok = true;
    if (argc == 2) {
        HolderType<int32_t, false> arg0 = {};
        HolderType<float, false> arg1 = {};
        ok &= sevalue_to_native(args[0], &arg0, nullptr);
        ok &= sevalue_to_native(args[1], &arg1, nullptr);
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        cce::effekseer::updateHandleToMoveToFrame(arg0.value(), arg1.value());
        return true;
    }
    SE_REPORT_ERROR("wrong number of arguments: %d, was expecting %d", (int)argc, 2);
    return false;
}
SE_BIND_FUNC(js_effekseer_effekseer_updateHandleToMoveToFrame_static)

static bool js_effekseer_effekseer_updateTime_static(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    size_t argc = args.size();
    CC_UNUSED bool ok = true;
    if (argc == 1) {
        HolderType<float, false> arg0 = {};
        ok &= sevalue_to_native(args[0], &arg0, nullptr);
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        cce::effekseer::updateTime(arg0.value());
        return true;
    }
    SE_REPORT_ERROR("wrong number of arguments: %d, was expecting %d", (int)argc, 1);
    return false;
}
SE_BIND_FUNC(js_effekseer_effekseer_updateTime_static)

SE_DECLARE_FINALIZE_FUNC(js_cce_effekseer_finalize)

static bool js_effekseer_effekseer_constructor(se::State& s) // NOLINT(readability-identifier-naming) constructor.c
{
    auto *ptr = JSB_MAKE_PRIVATE_OBJECT(cce::effekseer);
    s.thisObject()->setPrivateObject(ptr);
    return true;
}
SE_BIND_CTOR(js_effekseer_effekseer_constructor, __jsb_cce_effekseer_class, js_cce_effekseer_finalize)

static bool js_cce_effekseer_finalize(se::State& s) // NOLINT(readability-identifier-naming)
{
    return true;
}
SE_BIND_FINALIZE_FUNC(js_cce_effekseer_finalize)

bool js_register_effekseer_effekseer(se::Object* obj) // NOLINT(readability-identifier-naming)
{
    auto* cls = se::Class::create("effekseer", obj, nullptr, _SE(js_effekseer_effekseer_constructor));

#if CC_DEBUG
    cls->defineStaticProperty("isJSBClass", _SE(js_effekseer_getter_return_true), nullptr);
#endif
    cls->defineStaticFunction("enableBackGroundTexture", _SE(js_effekseer_effekseer_enableBackGroundTexture_static));
    cls->defineStaticFunction("enableDepthTexture", _SE(js_effekseer_effekseer_enableDepthTexture_static));
    cls->defineStaticFunction("exists", _SE(js_effekseer_effekseer_exists_static));
    cls->defineStaticFunction("getCameraCullingMaskToShowAllEffects", _SE(js_effekseer_effekseer_getCameraCullingMaskToShowAllEffects_static));
    cls->defineStaticFunction("getDynamicInput", _SE(js_effekseer_effekseer_getDynamicInput_static));
    cls->defineStaticFunction("getEffectMagnification", _SE(js_effekseer_effekseer_getEffectMagnification_static));
    cls->defineStaticFunction("getFrameCount", _SE(js_effekseer_effekseer_getFrameCount_static));
    cls->defineStaticFunction("getInstanceCount", _SE(js_effekseer_effekseer_getInstanceCount_static));
    cls->defineStaticFunction("getPaused", _SE(js_effekseer_effekseer_getPaused_static));
    cls->defineStaticFunction("getRestInstancesCount", _SE(js_effekseer_effekseer_getRestInstancesCount_static));
    cls->defineStaticFunction("getShown", _SE(js_effekseer_effekseer_getShown_static));
    cls->defineStaticFunction("getSpeed", _SE(js_effekseer_effekseer_getSpeed_static));
    cls->defineStaticFunction("init", _SE(js_effekseer_effekseer_init_static));
    cls->defineStaticFunction("initRenderer", _SE(js_effekseer_effekseer_initRenderer_static));
    cls->defineStaticFunction("loadEffect", _SE(js_effekseer_effekseer_loadEffect_static));
    cls->defineStaticFunction("loadEffectOnMemory", _SE(js_effekseer_effekseer_loadEffectOnMemory_static));
    cls->defineStaticFunction("playEffect", _SE(js_effekseer_effekseer_playEffect_static));
    cls->defineStaticFunction("releaseEffect", _SE(js_effekseer_effekseer_releaseEffect_static));
    cls->defineStaticFunction("reloadResources", _SE(js_effekseer_effekseer_reloadResources_static));
    cls->defineStaticFunction("render", _SE(js_effekseer_effekseer_render_static));
    cls->defineStaticFunction("renderBack", _SE(js_effekseer_effekseer_renderBack_static));
    cls->defineStaticFunction("renderFront", _SE(js_effekseer_effekseer_renderFront_static));
    cls->defineStaticFunction("renderInfoBuffer", _SE(js_effekseer_effekseer_renderInfoBuffer_static));
    cls->defineStaticFunction("renderParameter", _SE(js_effekseer_effekseer_renderParameter_static));
    cls->defineStaticFunction("renderParameterCount", _SE(js_effekseer_effekseer_renderParameterCount_static));
    cls->defineStaticFunction("renderStrideBufferCount", _SE(js_effekseer_effekseer_renderStrideBufferCount_static));
    cls->defineStaticFunction("renderStrideBufferParameter", _SE(js_effekseer_effekseer_renderStrideBufferParameter_static));
    cls->defineStaticFunction("resetTime", _SE(js_effekseer_effekseer_resetTime_static));
    cls->defineStaticFunction("sendTrigger", _SE(js_effekseer_effekseer_sendTrigger_static));
    cls->defineStaticFunction("setAllColor", _SE(js_effekseer_effekseer_setAllColor_static));
    cls->defineStaticFunction("setCameraMatrix", _SE(js_effekseer_effekseer_setCameraMatrix_static));
    cls->defineStaticFunction("setCurveLoaderEvent", _SE(js_effekseer_effekseer_setCurveLoaderEvent_static));
    cls->defineStaticFunction("setDynamicInput", _SE(js_effekseer_effekseer_setDynamicInput_static));
    cls->defineStaticFunction("setGroupMask", _SE(js_effekseer_effekseer_setGroupMask_static));
    cls->defineStaticFunction("setLayer", _SE(js_effekseer_effekseer_setLayer_static));
    cls->defineStaticFunction("setLightAmbientColor", _SE(js_effekseer_effekseer_setLightAmbientColor_static));
    cls->defineStaticFunction("setLightColor", _SE(js_effekseer_effekseer_setLightColor_static));
    cls->defineStaticFunction("setLightDirection", _SE(js_effekseer_effekseer_setLightDirection_static));
    cls->defineStaticFunction("setLocation", _SE(js_effekseer_effekseer_setLocation_static));
    cls->defineStaticFunction("setMaterialLoaderEvent", _SE(js_effekseer_effekseer_setMaterialLoaderEvent_static));
    cls->defineStaticFunction("setMatrix", _SE(js_effekseer_effekseer_setMatrix_static));
    cls->defineStaticFunction("setMeshLoaderEvent", _SE(js_effekseer_effekseer_setMeshLoaderEvent_static));
    cls->defineStaticFunction("setModelLoaderEvent", _SE(js_effekseer_effekseer_setModelLoaderEvent_static));
    cls->defineStaticFunction("setPaused", _SE(js_effekseer_effekseer_setPaused_static));
    cls->defineStaticFunction("setPausedToAllEffects", _SE(js_effekseer_effekseer_setPausedToAllEffects_static));
    cls->defineStaticFunction("setProjectionMatrix", _SE(js_effekseer_effekseer_setProjectionMatrix_static));
    cls->defineStaticFunction("setRemovingCallback", _SE(js_effekseer_effekseer_setRemovingCallback_static));
    cls->defineStaticFunction("setRenderSettings", _SE(js_effekseer_effekseer_setRenderSettings_static));
    cls->defineStaticFunction("setRenderTargetProperty", _SE(js_effekseer_effekseer_setRenderTargetProperty_static));
    cls->defineStaticFunction("setRenderingCameraCullingMask", _SE(js_effekseer_effekseer_setRenderingCameraCullingMask_static));
    cls->defineStaticFunction("setRotation", _SE(js_effekseer_effekseer_setRotation_static));
    cls->defineStaticFunction("setScale", _SE(js_effekseer_effekseer_setScale_static));
    cls->defineStaticFunction("setShown", _SE(js_effekseer_effekseer_setShown_static));
    cls->defineStaticFunction("setSoundLoaderEvent", _SE(js_effekseer_effekseer_setSoundLoaderEvent_static));
    cls->defineStaticFunction("setSoundPlayerEvent", _SE(js_effekseer_effekseer_setSoundPlayerEvent_static));
    cls->defineStaticFunction("setSpeed", _SE(js_effekseer_effekseer_setSpeed_static));
    cls->defineStaticFunction("setStereoRenderingMatrix", _SE(js_effekseer_effekseer_setStereoRenderingMatrix_static));
    cls->defineStaticFunction("setTargetLocation", _SE(js_effekseer_effekseer_setTargetLocation_static));
    cls->defineStaticFunction("setTextureLoaderEvent", _SE(js_effekseer_effekseer_setTextureLoaderEvent_static));
    cls->defineStaticFunction("setTimeScaleByGroup", _SE(js_effekseer_effekseer_setTimeScaleByGroup_static));
    cls->defineStaticFunction("setUserData", _SE(js_effekseer_effekseer_setUserData_static));
    cls->defineStaticFunction("stopAllEffects", _SE(js_effekseer_effekseer_stopAllEffects_static));
    cls->defineStaticFunction("stopEffect", _SE(js_effekseer_effekseer_stopEffect_static));
    cls->defineStaticFunction("stopRoot", _SE(js_effekseer_effekseer_stopRoot_static));
    cls->defineStaticFunction("unloadResources", _SE(js_effekseer_effekseer_unloadResources_static));
    cls->defineStaticFunction("update", _SE(js_effekseer_effekseer_update_static));
    cls->defineStaticFunction("updateHandle", _SE(js_effekseer_effekseer_updateHandle_static));
    cls->defineStaticFunction("updateHandleToMoveToFrame", _SE(js_effekseer_effekseer_updateHandleToMoveToFrame_static));
    cls->defineStaticFunction("updateTime", _SE(js_effekseer_effekseer_updateTime_static));
    cls->defineFinalizeFunction(_SE(js_cce_effekseer_finalize));
    cls->install();
    JSBClassType::registerClass<cce::effekseer>(cls);

    __jsb_cce_effekseer_proto = cls->getProto();
    __jsb_cce_effekseer_class = cls;


    se::ScriptEngine::getInstance()->clearException();
    return true;
}
se::Object* __jsb_EFKMaterialN_proto = nullptr; // NOLINT
se::Class* __jsb_EFKMaterialN_class = nullptr;  // NOLINT

static bool js_effekseer_EFKMaterialN_check_static(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    size_t argc = args.size();
    CC_UNUSED bool ok = true;
    if (argc == 6) {
        HolderType<cce::RenderParameter*, false> arg0 = {};
        HolderType<float*, false> arg1 = {};
        HolderType<float*, false> arg2 = {};
        HolderType<cc::scene::Camera*, false> arg3 = {};
        HolderType<unsigned int, false> arg4 = {};
        HolderType<int32_t, false> arg5 = {};
        ok &= sevalue_to_native(args[0], &arg0, nullptr);
        ok &= sevalue_to_native(args[1], &arg1, nullptr);
        ok &= sevalue_to_native(args[2], &arg2, nullptr);
        ok &= sevalue_to_native(args[3], &arg3, nullptr);
        ok &= sevalue_to_native(args[4], &arg4, nullptr);
        ok &= sevalue_to_native(args[5], &arg5, nullptr);
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        cc::Material* result = EFKMaterialN::check(arg0.value(), arg1.value(), arg2.value(), arg3.value(), arg4.value(), arg5.value());
        ok &= nativevalue_to_se(result, s.rval(), nullptr /*ctx*/);
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        SE_HOLD_RETURN_VALUE(result, s.thisObject(), s.rval());
        return true;
    }
    SE_REPORT_ERROR("wrong number of arguments: %d, was expecting %d", (int)argc, 6);
    return false;
}
SE_BIND_FUNC(js_effekseer_EFKMaterialN_check_static)

static bool js_effekseer_EFKMaterialN_setCumstom_static(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    size_t argc = args.size();
    CC_UNUSED bool ok = true;
    if (argc == 3) {
        HolderType<unsigned int, false> arg0 = {};
        HolderType<std::vector<cc::Material *>, false> arg1 = {};
        HolderType<bool, false> arg2 = {};
        ok &= sevalue_to_native(args[0], &arg0, nullptr);
        ok &= sevalue_to_native(args[1], &arg1, nullptr);
        ok &= sevalue_to_native(args[2], &arg2, nullptr);
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        EFKMaterialN::setCumstom(arg0.value(), arg1.value(), arg2.value());
        return true;
    }
    SE_REPORT_ERROR("wrong number of arguments: %d, was expecting %d", (int)argc, 3);
    return false;
}
SE_BIND_FUNC(js_effekseer_EFKMaterialN_setCumstom_static)

static bool js_effekseer_EFKMaterialN_setInternals_static(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    size_t argc = args.size();
    CC_UNUSED bool ok = true;
    if (argc == 1) {
        HolderType<std::vector<cc::Material *>, false> arg0 = {};
        ok &= sevalue_to_native(args[0], &arg0, nullptr);
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        EFKMaterialN::setInternals(arg0.value());
        return true;
    }
    SE_REPORT_ERROR("wrong number of arguments: %d, was expecting %d", (int)argc, 1);
    return false;
}
SE_BIND_FUNC(js_effekseer_EFKMaterialN_setInternals_static)

static bool js_effekseer_EFKMaterialN_setTexture_static(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    size_t argc = args.size();
    CC_UNUSED bool ok = true;
    if (argc == 3) {
        HolderType<unsigned int, false> arg0 = {};
        HolderType<cc::Texture2D*, false> arg1 = {};
        HolderType<bool, false> arg2 = {};
        ok &= sevalue_to_native(args[0], &arg0, nullptr);
        ok &= sevalue_to_native(args[1], &arg1, nullptr);
        ok &= sevalue_to_native(args[2], &arg2, nullptr);
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        EFKMaterialN::setTexture(arg0.value(), arg1.value(), arg2.value());
        return true;
    }
    SE_REPORT_ERROR("wrong number of arguments: %d, was expecting %d", (int)argc, 3);
    return false;
}
SE_BIND_FUNC(js_effekseer_EFKMaterialN_setTexture_static)
static bool js_EFKMaterialN_finalize(se::State& s) // NOLINT(readability-identifier-naming)
{
    return true;
}
SE_BIND_FINALIZE_FUNC(js_EFKMaterialN_finalize)

bool js_register_effekseer_EFKMaterialN(se::Object* obj) // NOLINT(readability-identifier-naming)
{
    auto* cls = se::Class::create("EFKMaterialN", obj, nullptr, nullptr);

#if CC_DEBUG
    cls->defineStaticProperty("isJSBClass", _SE(js_effekseer_getter_return_true), nullptr);
#endif
    cls->defineStaticFunction("check", _SE(js_effekseer_EFKMaterialN_check_static));
    cls->defineStaticFunction("setCumstom", _SE(js_effekseer_EFKMaterialN_setCumstom_static));
    cls->defineStaticFunction("setInternals", _SE(js_effekseer_EFKMaterialN_setInternals_static));
    cls->defineStaticFunction("setTexture", _SE(js_effekseer_EFKMaterialN_setTexture_static));
    cls->defineFinalizeFunction(_SE(js_EFKMaterialN_finalize));
    cls->install();
    JSBClassType::registerClass<EFKMaterialN>(cls);

    __jsb_EFKMaterialN_proto = cls->getProto();
    __jsb_EFKMaterialN_class = cls;


    se::ScriptEngine::getInstance()->clearException();
    return true;
}
se::Object* __jsb_EFKModelN_proto = nullptr; // NOLINT
se::Class* __jsb_EFKModelN_class = nullptr;  // NOLINT

static bool js_effekseer_EFKModelN_addModel_static(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    size_t argc = args.size();
    CC_UNUSED bool ok = true;
    if (argc == 4) {
        HolderType<int32_t, false> arg0 = {};
        HolderType<std::vector<unsigned char>, false> arg1 = {};
        HolderType<std::vector<unsigned char>, false> arg2 = {};
        HolderType<unsigned int, false> arg3 = {};
        ok &= sevalue_to_native(args[0], &arg0, nullptr);
        ok &= sevalue_to_native(args[1], &arg1, nullptr);
        ok &= sevalue_to_native(args[2], &arg2, nullptr);
        ok &= sevalue_to_native(args[3], &arg3, nullptr);
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        EFKModelN::addModel(arg0.value(), arg1.value(), arg2.value(), arg3.value());
        return true;
    }
    SE_REPORT_ERROR("wrong number of arguments: %d, was expecting %d", (int)argc, 4);
    return false;
}
SE_BIND_FUNC(js_effekseer_EFKModelN_addModel_static)

static bool js_effekseer_EFKModelN_addSprite_static(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    size_t argc = args.size();
    CC_UNUSED bool ok = true;
    if (argc == 2) {
        HolderType<unsigned int, false> arg0 = {};
        HolderType<std::vector<unsigned char>, false> arg1 = {};
        ok &= sevalue_to_native(args[0], &arg0, nullptr);
        ok &= sevalue_to_native(args[1], &arg1, nullptr);
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        EFKModelN::addSprite(arg0.value(), arg1.value());
        return true;
    }
    SE_REPORT_ERROR("wrong number of arguments: %d, was expecting %d", (int)argc, 2);
    return false;
}
SE_BIND_FUNC(js_effekseer_EFKModelN_addSprite_static)

static bool js_effekseer_EFKModelN_drawModel_static(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    size_t argc = args.size();
    CC_UNUSED bool ok = true;
    if (argc == 4) {
        HolderType<int32_t, false> arg0 = {};
        HolderType<unsigned int, false> arg1 = {};
        HolderType<cc::Material*, false> arg2 = {};
        HolderType<unsigned int, false> arg3 = {};
        ok &= sevalue_to_native(args[0], &arg0, nullptr);
        ok &= sevalue_to_native(args[1], &arg1, nullptr);
        ok &= sevalue_to_native(args[2], &arg2, nullptr);
        ok &= sevalue_to_native(args[3], &arg3, nullptr);
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        cc::scene::Model* result = EFKModelN::drawModel(arg0.value(), arg1.value(), arg2.value(), arg3.value());
        ok &= nativevalue_to_se(result, s.rval(), nullptr /*ctx*/);
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        SE_HOLD_RETURN_VALUE(result, s.thisObject(), s.rval());
        return true;
    }
    SE_REPORT_ERROR("wrong number of arguments: %d, was expecting %d", (int)argc, 4);
    return false;
}
SE_BIND_FUNC(js_effekseer_EFKModelN_drawModel_static)

static bool js_effekseer_EFKModelN_drawSprite_static(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    size_t argc = args.size();
    CC_UNUSED bool ok = true;
    if (argc == 5) {
        HolderType<unsigned int, false> arg0 = {};
        HolderType<unsigned int, false> arg1 = {};
        HolderType<unsigned int, false> arg2 = {};
        HolderType<cc::Material*, false> arg3 = {};
        HolderType<unsigned int, false> arg4 = {};
        ok &= sevalue_to_native(args[0], &arg0, nullptr);
        ok &= sevalue_to_native(args[1], &arg1, nullptr);
        ok &= sevalue_to_native(args[2], &arg2, nullptr);
        ok &= sevalue_to_native(args[3], &arg3, nullptr);
        ok &= sevalue_to_native(args[4], &arg4, nullptr);
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        cc::scene::Model* result = EFKModelN::drawSprite(arg0.value(), arg1.value(), arg2.value(), arg3.value(), arg4.value());
        ok &= nativevalue_to_se(result, s.rval(), nullptr /*ctx*/);
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        SE_HOLD_RETURN_VALUE(result, s.thisObject(), s.rval());
        return true;
    }
    SE_REPORT_ERROR("wrong number of arguments: %d, was expecting %d", (int)argc, 5);
    return false;
}
SE_BIND_FUNC(js_effekseer_EFKModelN_drawSprite_static)

static bool js_effekseer_EFKModelN_reset_static(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    size_t argc = args.size();
    if (argc == 0) {
        EFKModelN::reset();
        return true;
    }
    SE_REPORT_ERROR("wrong number of arguments: %d, was expecting %d", (int)argc, 0);
    return false;
}
SE_BIND_FUNC(js_effekseer_EFKModelN_reset_static)
static bool js_EFKModelN_finalize(se::State& s) // NOLINT(readability-identifier-naming)
{
    return true;
}
SE_BIND_FINALIZE_FUNC(js_EFKModelN_finalize)

bool js_register_effekseer_EFKModelN(se::Object* obj) // NOLINT(readability-identifier-naming)
{
    auto* cls = se::Class::create("EFKModelN", obj, nullptr, nullptr);

#if CC_DEBUG
    cls->defineStaticProperty("isJSBClass", _SE(js_effekseer_getter_return_true), nullptr);
#endif
    cls->defineStaticFunction("addModel", _SE(js_effekseer_EFKModelN_addModel_static));
    cls->defineStaticFunction("addSprite", _SE(js_effekseer_EFKModelN_addSprite_static));
    cls->defineStaticFunction("drawModel", _SE(js_effekseer_EFKModelN_drawModel_static));
    cls->defineStaticFunction("drawSprite", _SE(js_effekseer_EFKModelN_drawSprite_static));
    cls->defineStaticFunction("reset", _SE(js_effekseer_EFKModelN_reset_static));
    cls->defineFinalizeFunction(_SE(js_EFKModelN_finalize));
    cls->install();
    JSBClassType::registerClass<EFKModelN>(cls);

    __jsb_EFKModelN_proto = cls->getProto();
    __jsb_EFKModelN_class = cls;


    se::ScriptEngine::getInstance()->clearException();
    return true;
}
se::Object* __jsb_EFKRenderN_proto = nullptr; // NOLINT
se::Class* __jsb_EFKRenderN_class = nullptr;  // NOLINT

static bool js_effekseer_EFKRenderN_render_static(se::State& s) // NOLINT(readability-identifier-naming)
{
    const auto& args = s.args();
    size_t argc = args.size();
    CC_UNUSED bool ok = true;
    if (argc == 2) {
        HolderType<std::vector<cc::scene::Camera *>, false> arg0 = {};
        HolderType<bool, false> arg1 = {};
        ok &= sevalue_to_native(args[0], &arg0, nullptr);
        ok &= sevalue_to_native(args[1], &arg1, nullptr);
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        std::map<int, std::vector<cc::scene::Model *>> result = EFKRenderN::render(arg0.value(), arg1.value());
        ok &= nativevalue_to_se(result, s.rval(), nullptr /*ctx*/);
        SE_PRECONDITION2(ok, false, "Error processing arguments");
        SE_HOLD_RETURN_VALUE(result, s.thisObject(), s.rval());
        return true;
    }
    SE_REPORT_ERROR("wrong number of arguments: %d, was expecting %d", (int)argc, 2);
    return false;
}
SE_BIND_FUNC(js_effekseer_EFKRenderN_render_static)
static bool js_EFKRenderN_finalize(se::State& s) // NOLINT(readability-identifier-naming)
{
    return true;
}
SE_BIND_FINALIZE_FUNC(js_EFKRenderN_finalize)

bool js_register_effekseer_EFKRenderN(se::Object* obj) // NOLINT(readability-identifier-naming)
{
    auto* cls = se::Class::create("EFKRenderN", obj, nullptr, nullptr);

#if CC_DEBUG
    cls->defineStaticProperty("isJSBClass", _SE(js_effekseer_getter_return_true), nullptr);
#endif
    cls->defineStaticFunction("render", _SE(js_effekseer_EFKRenderN_render_static));
    cls->defineFinalizeFunction(_SE(js_EFKRenderN_finalize));
    cls->install();
    JSBClassType::registerClass<EFKRenderN>(cls);

    __jsb_EFKRenderN_proto = cls->getProto();
    __jsb_EFKRenderN_class = cls;


    se::ScriptEngine::getInstance()->clearException();
    return true;
}
bool register_all_effekseer(se::Object* obj)    // NOLINT
{
    // Get the ns
    se::Value nsVal;
    if (!obj->getProperty("efk", &nsVal, true))
    {
        se::HandleObject jsobj(se::Object::createPlainObject());
        nsVal.setObject(jsobj);
        obj->setProperty("efk", nsVal);
    }
    se::Object* ns = nsVal.toObject();

    js_register_effekseer_EFKMaterialN(ns);
    js_register_effekseer_EFKModelN(ns);
    js_register_effekseer_EFKRenderN(ns);
    js_register_effekseer_EdgeParametersEx(ns);
    js_register_effekseer_FalloffParameterEx(ns);
    js_register_effekseer_FlipbookParametersEx(ns);
    js_register_effekseer_ModelEx(ns);
    js_register_effekseer_RenderParameter(ns);
    js_register_effekseer_ShaderEx(ns);
    js_register_effekseer_StrideBufferParameterEx(ns);
    js_register_effekseer_effekseer(ns);
    return true;
}

// clang-format on