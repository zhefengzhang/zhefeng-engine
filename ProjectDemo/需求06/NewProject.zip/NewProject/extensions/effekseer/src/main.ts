
export const methods: { [key: string]: (...any: any) => any } = {};
export function load() { }
export function unload() { }
