import { _decorator, Component, Asset, ModelRenderer, director, renderer, Node, Material, Texture2D, native, Prefab, CCBoolean } from "cc";
import { EFKModel } from "./efk_model";
import { EFKRender } from "./efk_render";
import { EDITOR, NATIVE } from "cc/env";

const { ccclass, property, executeInEditMode } = _decorator;

@ccclass('EFKComponent')
@executeInEditMode
export class EFKComponent extends ModelRenderer {
    @property({ type: Asset, serializable: true })
    _efk: Asset = null!;

    @property({ type: Asset, readonly: true })
    set efk(efk: Asset) {
        this._efk = efk;
        this.onChange();
    }
    get efk() {
        return this._efk;
    }

    @property({ type: Asset, readonly: true })
    efkModels: Asset[] = [];

    @property({ type: [Texture2D], readonly: true })
    efkTextures: Texture2D[] = [];

    @property({ type: Asset, readonly: true })
    efkMats: Asset[] = [];

    @property({ type: Prefab, readonly: true })
    efkConfig: Prefab = null!;

    @property({ type: CCBoolean})
    playOnEnable: boolean = true;

    @property
    set efkRepeat(b: boolean) {
        this.setRpeat(b);
    }
    get efkRepeat() {
        return this._repeat;
    }

    @property({ serializable: true })
    private _repeat: boolean = false;

    private _frameCount: number = 0;
    private _playing: boolean = false;
    private lastStopFrame = 0;

    public play(playAgain: boolean = false) : boolean {
        if (playAgain || !this._playing) {
            this._playing = true;
            let frameCount = EFKRender.play(this);
            if (this.lastStopFrame > 0)
                console.log("@@@@", this.lastStopFrame, director.getTotalFrames());
            
            if (frameCount == null) {
                this._playing = false;
                return false;
            }
            this._frameCount = frameCount;
            EFKRender.setWorldMatrix(this);
            return true;
        }
        return false;
    }

    public stop() {
        this._playing = false;
        EFKRender.stop(this);
        this._detachFromScene();
    }

    public setSpeed(v: number) {
        EFKRender.setSpeed(this, v);
    }

    public setPause(b: boolean) {
        EFKRender.setPause(this, b);
    }

    public setRpeat(b: boolean) {
        this._repeat = b;
        if (EDITOR && b) {
            this.play();
        }
    }

    public getFrameCount(): number {
        return this._frameCount;
    }

    public setFramePosition(n: number) {
        EFKRender.setFrame(this, n);
    }

    public update() {
        if (this._playing) {
            EFKRender.setWorldMatrix(this);
            this._detachFromScene();
        }
    }

    public onRestore() {
        if (this.enabledInHierarchy) {
            this._attachToScene();
        }
    }

    protected onRemovingCallback() {
        this._playing = false;
        this.scheduleOnce(() => {
            if (this._repeat) {
                this.play();
            }
            else {
                this.node.emit('efk_remove');
                // this.destroy();
            }
        })
    }

    protected onChange() {
        if (this.node.active && this.enabled) {
            if (!this._playing) {
                this._frameCount = EFKRender.play(this);
                EFKRender.setWorldMatrix(this);
            }
        }
        this.node.children
    }

    protected onLoad(): void {
        EFKRender.load(this);
    }

    protected onEnable() {
        if (this.playOnEnable) {
            this.play();
        }

        //this.node.on(Node.EventType.TRANSFORM_CHANGED, this.onTransformChanged, this);

        this._attachToScene();
    }

    protected onDisable() {
        this._playing = false;
        EFKRender.stop(this);
        this._detachFromScene();
        //this.node.off(Node.EventType.TRANSFORM_CHANGED, this.onTransformChanged, this);
        this.lastStopFrame = director.getTotalFrames();
    }

    protected onDestroy() {
        this._playing = false;
        EFKRender.unload(this.efk.name);
        this._detachFromScene();
    }

    protected onTransformChanged() {
        if (this._playing) {
            EFKRender.setWorldMatrix(this);
        }
    }

    protected _addModel(model: renderer.scene.Model) {
        if (!model) return;
        model.node = model.transform = this.node;
        model.visFlags = this.visibility;
        this._models.push(model);
        this._updatePriority();
        const renderScene = this._getRenderScene();
        renderScene.addModel(model);
    }

    protected _attachToScene() {
        // const renderScene = this._getRenderScene();
        // this._models.forEach((model) => {
        //     renderScene.addModel(model);
        // })
    }

    protected _detachFromScene() {
        const renderScene = this._getRenderScene();
        this._models.forEach((model) => {
            renderScene.removeModel(model);
        })
        this._models.length = 0;
    }
}
