System.register(["cc"], function (_export, _context) {
    "use strict";

    
    return {
      setters: [function (_cc) {
        window["__primitives"] = _cc.primitives;
      }],
      execute: function () {
        
      }
    };
  });