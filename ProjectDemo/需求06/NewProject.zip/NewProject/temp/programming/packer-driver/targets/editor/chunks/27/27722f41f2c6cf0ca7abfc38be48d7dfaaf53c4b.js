System.register(["cc"], function (_export, _context) {
  "use strict";

  var _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _cc, _dec, _class, _crd, cc, ccclass, property, bundleName, sceneName, entry;

  return {
    setters: [function (_cc2) {
      _cclegacy = _cc2.cclegacy;
      __checkObsolete__ = _cc2.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc2.__checkObsoleteInNamespace__;
      _cc = _cc2;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "c20d3h/8vBD2YRw4r8y3p8r", "entry", undefined);

      cc = __checkObsoleteInNamespace__(_cc);
      ({
        ccclass,
        property
      } = cc._decorator);
      bundleName = "bundleB";
      sceneName = "sceneB";

      _export("entry", entry = (_dec = ccclass('entry'), _dec(_class = class entry extends cc.Component {
        onClickChangeScene() {
          cc.assetManager.loadBundle(bundleName, (err, bundle) => {
            if (err) {
              console.log("error");
              return;
            } //成功加載


            bundle.loadScene(sceneName, function (err, scene) {
              cc.director.runScene(scene);
            });
          });
        }

      }) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=27722f41f2c6cf0ca7abfc38be48d7dfaaf53c4b.js.map