System.register(["__unresolved_0", "cc", "__unresolved_1", "cc/env"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, Asset, ModelRenderer, director, Texture2D, Prefab, CCBoolean, EFKRender, EDITOR, _dec, _dec2, _dec3, _dec4, _dec5, _dec6, _dec7, _dec8, _dec9, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _descriptor5, _descriptor6, _descriptor7, _crd, ccclass, property, executeInEditMode, EFKComponent;

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'transform-class-properties is enabled and runs after the decorators transform.'); }

  function _reportPossibleCrUseOfEFKRender(extras) {
    _reporterNs.report("EFKRender", "./efk_render", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
      Asset = _cc.Asset;
      ModelRenderer = _cc.ModelRenderer;
      director = _cc.director;
      Texture2D = _cc.Texture2D;
      Prefab = _cc.Prefab;
      CCBoolean = _cc.CCBoolean;
    }, function (_unresolved_2) {
      EFKRender = _unresolved_2.EFKRender;
    }, function (_ccEnv) {
      EDITOR = _ccEnv.EDITOR;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "1d189MYptBN74HAnWl02Xv/", "efk_component", undefined);

      __checkObsolete__(['_decorator', 'Component', 'Asset', 'ModelRenderer', 'director', 'renderer', 'Node', 'Material', 'Texture2D', 'native', 'Prefab', 'CCBoolean']);

      ({
        ccclass,
        property,
        executeInEditMode
      } = _decorator);

      _export("EFKComponent", EFKComponent = (_dec = ccclass('EFKComponent'), _dec2 = property({
        type: Asset,
        serializable: true
      }), _dec3 = property({
        type: Asset,
        readonly: true
      }), _dec4 = property({
        type: Asset,
        readonly: true
      }), _dec5 = property({
        type: [Texture2D],
        readonly: true
      }), _dec6 = property({
        type: Asset,
        readonly: true
      }), _dec7 = property({
        type: Prefab,
        readonly: true
      }), _dec8 = property({
        type: CCBoolean
      }), _dec9 = property({
        serializable: true
      }), _dec(_class = executeInEditMode(_class = (_class2 = class EFKComponent extends ModelRenderer {
        constructor() {
          super(...arguments);

          _initializerDefineProperty(this, "_efk", _descriptor, this);

          _initializerDefineProperty(this, "efkModels", _descriptor2, this);

          _initializerDefineProperty(this, "efkTextures", _descriptor3, this);

          _initializerDefineProperty(this, "efkMats", _descriptor4, this);

          _initializerDefineProperty(this, "efkConfig", _descriptor5, this);

          _initializerDefineProperty(this, "playOnEnable", _descriptor6, this);

          _initializerDefineProperty(this, "_repeat", _descriptor7, this);

          this._frameCount = 0;
          this._playing = false;
          this.lastStopFrame = 0;
        }

        set efk(efk) {
          this._efk = efk;
          this.onChange();
        }

        get efk() {
          return this._efk;
        }

        set efkRepeat(b) {
          this.setRpeat(b);
        }

        get efkRepeat() {
          return this._repeat;
        }

        play(playAgain) {
          if (playAgain === void 0) {
            playAgain = false;
          }

          if (playAgain || !this._playing) {
            this._playing = true;
            var frameCount = (_crd && EFKRender === void 0 ? (_reportPossibleCrUseOfEFKRender({
              error: Error()
            }), EFKRender) : EFKRender).play(this);
            if (this.lastStopFrame > 0) console.log("@@@@", this.lastStopFrame, director.getTotalFrames());

            if (frameCount == null) {
              this._playing = false;
              return false;
            }

            this._frameCount = frameCount;
            (_crd && EFKRender === void 0 ? (_reportPossibleCrUseOfEFKRender({
              error: Error()
            }), EFKRender) : EFKRender).setWorldMatrix(this);
            return true;
          }

          return false;
        }

        stop() {
          this._playing = false;
          (_crd && EFKRender === void 0 ? (_reportPossibleCrUseOfEFKRender({
            error: Error()
          }), EFKRender) : EFKRender).stop(this);

          this._detachFromScene();
        }

        setSpeed(v) {
          (_crd && EFKRender === void 0 ? (_reportPossibleCrUseOfEFKRender({
            error: Error()
          }), EFKRender) : EFKRender).setSpeed(this, v);
        }

        setPause(b) {
          (_crd && EFKRender === void 0 ? (_reportPossibleCrUseOfEFKRender({
            error: Error()
          }), EFKRender) : EFKRender).setPause(this, b);
        }

        setRpeat(b) {
          this._repeat = b;

          if (EDITOR && b) {
            this.play();
          }
        }

        getFrameCount() {
          return this._frameCount;
        }

        setFramePosition(n) {
          (_crd && EFKRender === void 0 ? (_reportPossibleCrUseOfEFKRender({
            error: Error()
          }), EFKRender) : EFKRender).setFrame(this, n);
        }

        update() {
          if (this._playing) {
            (_crd && EFKRender === void 0 ? (_reportPossibleCrUseOfEFKRender({
              error: Error()
            }), EFKRender) : EFKRender).setWorldMatrix(this);

            this._detachFromScene();
          }
        }

        onRestore() {
          if (this.enabledInHierarchy) {
            this._attachToScene();
          }
        }

        onRemovingCallback() {
          this._playing = false;
          this.scheduleOnce(() => {
            if (this._repeat) {
              this.play();
            } else {
              this.node.emit('efk_remove'); // this.destroy();
            }
          });
        }

        onChange() {
          if (this.node.active && this.enabled) {
            if (!this._playing) {
              this._frameCount = (_crd && EFKRender === void 0 ? (_reportPossibleCrUseOfEFKRender({
                error: Error()
              }), EFKRender) : EFKRender).play(this);
              (_crd && EFKRender === void 0 ? (_reportPossibleCrUseOfEFKRender({
                error: Error()
              }), EFKRender) : EFKRender).setWorldMatrix(this);
            }
          }

          this.node.children;
        }

        onLoad() {
          (_crd && EFKRender === void 0 ? (_reportPossibleCrUseOfEFKRender({
            error: Error()
          }), EFKRender) : EFKRender).load(this);
        }

        onEnable() {
          if (this.playOnEnable) {
            this.play();
          } //this.node.on(Node.EventType.TRANSFORM_CHANGED, this.onTransformChanged, this);


          this._attachToScene();
        }

        onDisable() {
          this._playing = false;
          (_crd && EFKRender === void 0 ? (_reportPossibleCrUseOfEFKRender({
            error: Error()
          }), EFKRender) : EFKRender).stop(this);

          this._detachFromScene(); //this.node.off(Node.EventType.TRANSFORM_CHANGED, this.onTransformChanged, this);


          this.lastStopFrame = director.getTotalFrames();
        }

        onDestroy() {
          this._playing = false;
          (_crd && EFKRender === void 0 ? (_reportPossibleCrUseOfEFKRender({
            error: Error()
          }), EFKRender) : EFKRender).unload(this.efk.name);

          this._detachFromScene();
        }

        onTransformChanged() {
          if (this._playing) {
            (_crd && EFKRender === void 0 ? (_reportPossibleCrUseOfEFKRender({
              error: Error()
            }), EFKRender) : EFKRender).setWorldMatrix(this);
          }
        }

        _addModel(model) {
          if (!model) return;
          model.node = model.transform = this.node;
          model.visFlags = this.visibility;

          this._models.push(model);

          this._updatePriority();

          var renderScene = this._getRenderScene();

          renderScene.addModel(model);
        }

        _attachToScene() {// const renderScene = this._getRenderScene();
          // this._models.forEach((model) => {
          //     renderScene.addModel(model);
          // })
        }

        _detachFromScene() {
          var renderScene = this._getRenderScene();

          this._models.forEach(model => {
            renderScene.removeModel(model);
          });

          this._models.length = 0;
        }

      }, (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "_efk", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _applyDecoratedDescriptor(_class2.prototype, "efk", [_dec3], Object.getOwnPropertyDescriptor(_class2.prototype, "efk"), _class2.prototype), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "efkModels", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return [];
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "efkTextures", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return [];
        }
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "efkMats", [_dec6], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return [];
        }
      }), _descriptor5 = _applyDecoratedDescriptor(_class2.prototype, "efkConfig", [_dec7], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor6 = _applyDecoratedDescriptor(_class2.prototype, "playOnEnable", [_dec8], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return true;
        }
      }), _applyDecoratedDescriptor(_class2.prototype, "efkRepeat", [property], Object.getOwnPropertyDescriptor(_class2.prototype, "efkRepeat"), _class2.prototype), _descriptor7 = _applyDecoratedDescriptor(_class2.prototype, "_repeat", [_dec9], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return false;
        }
      })), _class2)) || _class) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=1a09def6cd702109af303658e0fd4ed7673d0b9c.js.map