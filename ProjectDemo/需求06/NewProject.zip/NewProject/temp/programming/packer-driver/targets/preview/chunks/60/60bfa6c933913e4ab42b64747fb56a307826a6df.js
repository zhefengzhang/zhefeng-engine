System.register(["cc"], function (_export, _context) {
  "use strict";

  var _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, director, gfx, renderer, RenderingSubMesh, EFKModel, _crd, ModelVertexEx, ModelStrip, g_models;

  _export("EFKModel", void 0);

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      director = _cc.director;
      gfx = _cc.gfx;
      renderer = _cc.renderer;
      RenderingSubMesh = _cc.RenderingSubMesh;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "06350tOuqNA3Zck4HV2U1N1", "efk_model", undefined);

      __checkObsolete__(['director', 'gfx', 'Material', 'renderer', 'RenderingSubMesh']);

      ModelVertexEx = [//                  = 72
      new gfx.Attribute("Input_Pos", gfx.Format.RGB32F), // Pos      -> vec3 + 12   
      new gfx.Attribute("Input_Normal", gfx.Format.RGB32F), // Normal   -> vec3 + 12
      new gfx.Attribute("Input_Binormal", gfx.Format.RGB32F), // Binormal -> vec3 + 12
      new gfx.Attribute("Input_Tangent", gfx.Format.RGB32F), // Tangent  -> vec3 + 12
      new gfx.Attribute("Input_UV", gfx.Format.RG32F), // UV1      -> vec2 + 8
      new gfx.Attribute("Input_Color", gfx.Format.RGBA32F) // Color    -> vec4 + 16
      ];
      ModelStrip = 72; // 特效 自定义模型渲染

      g_models = {};

      _export("EFKModel", EFKModel = class EFKModel {
        static doDestroy() {
          EFKModel.m_meshs.forEach(mesh => {
            mesh.vertexBuffers.length = 0;
            mesh.destroy();
          });
          EFKModel.m_meshs = [];
          EFKModel.m_typeid_meshs = {};
          EFKModel.m_typeid_used = {};
          EFKModel.m_model_meshs = {};
          EFKModel.m_model_cache = {};
          EFKModel.m_models.forEach(model => {
            model.destroy();
          });
          EFKModel.m_models = [];
          EFKModel.m_model_used = {}; //

          EFKModel.m_buffers = {};
        } // 特效 sprite 网格数据渲染


        static updateMesh(stride, vertecies) {
          var device = gfx.deviceManager.gfxDevice;
          var buffer = EFKModel.m_buffers[stride];

          if (!buffer || buffer.vertex.size < vertecies.byteLength) {
            var vertexBuffer = buffer ? buffer.vertex : device.createBuffer(new gfx.BufferInfo(gfx.BufferUsageBit.VERTEX | gfx.BufferUsageBit.TRANSFER_DST, gfx.MemoryUsageBit.HOST | gfx.MemoryUsageBit.DEVICE, vertecies.byteLength, stride));

            if (buffer) {
              vertexBuffer.resize(vertecies.byteLength);
            } // 顶点数/4 = 多少四边形，四边形由 2 个三角形组成，三角形由 3 个顶点组成


            var indexCount = 3; // (vertexBuffer.size / stride) / 4 * 2 * 3;

            var indexBuffer = buffer ? buffer.indice : device.createBuffer(new gfx.BufferInfo(gfx.BufferUsageBit.INDEX | gfx.BufferUsageBit.TRANSFER_DST, gfx.MemoryUsageBit.DEVICE, indexCount * Uint16Array.BYTES_PER_ELEMENT, Uint16Array.BYTES_PER_ELEMENT));
            EFKModel.m_buffers[stride] = {
              vertex: vertexBuffer,
              indice: indexBuffer
            };
          }

          EFKModel.m_buffers[stride].vertex.update(vertecies);
        }

        static resizeIndice(indexBuffer, indexCount) {
          if (indexBuffer.size >= indexCount * Uint16Array.BYTES_PER_ELEMENT) {
            return;
          }

          indexBuffer.resize(indexCount * Uint16Array.BYTES_PER_ELEMENT);
          var indices = new Uint16Array(indexCount);
          var element = 0;

          for (var i = 0; i < indexCount;) {
            var baseIdx = 4 * element;
            indices[i++] = baseIdx;
            indices[i++] = baseIdx + 1;
            indices[i++] = baseIdx + 2;
            indices[i++] = baseIdx + 3;
            indices[i++] = baseIdx + 2;
            indices[i++] = baseIdx + 1;
            element++;
          }

          indexBuffer.update(indices);
        }

        static drawSprite(stride, offset, spriteCount, material, typeid) {
          var fisrtVertex = offset / stride;
          var fisrtIndex = fisrtVertex / 4 * 6;
          var buffer = EFKModel.m_buffers[stride];
          if (null == buffer) debugger; // 索引偏移 + 索引数

          EFKModel.resizeIndice(buffer.indice, fisrtIndex + spriteCount * 6);
          var iaInfo = new gfx.DrawInfo(spriteCount * 4, fisrtVertex, spriteCount * 6, fisrtIndex);
          var mesh = -1;
          var meshs = EFKModel.m_typeid_meshs[typeid] = EFKModel.m_typeid_meshs[typeid] || [];

          for (var i = 0; i < meshs.length; ++i) {
            var idx = meshs[i];

            if (!EFKModel.m_typeid_used[idx]) {
              EFKModel.m_typeid_used[idx] = true;
              mesh = idx;
              break;
            }
          }

          var subMesh = null;

          if (mesh >= 0) {
            subMesh = EFKModel.m_meshs[mesh];
            subMesh.drawInfo = iaInfo;
          } else {
            var attrs = [];
            material.passes[0].shaderInfo.attributes.forEach(attr => {
              attrs.push(new gfx.Attribute(attr.name, attr.format, attr.isNormalized, attr.stream, attr.isInstanced, attr.location));
            });
            subMesh = new RenderingSubMesh([buffer.vertex], attrs, gfx.PrimitiveMode.TRIANGLE_LIST, buffer.indice);
            mesh = EFKModel.m_meshs.length;
            EFKModel.m_meshs.push(subMesh);
            EFKModel.m_typeid_meshs[typeid].push(mesh);
            EFKModel.m_typeid_used[mesh] = true;
          }

          return EFKModel.checkModel(mesh, subMesh, material, iaInfo);
        }

        static addModel(key, vertecies, indices, frame) {
          var device = gfx.deviceManager.gfxDevice;
          g_models[key] = g_models[key] || [];
          var buffer = g_models[key][frame];

          if (!buffer || buffer.vertex.size < vertecies.byteLength) {
            var vertexBuffer = buffer ? buffer.vertex : device.createBuffer(new gfx.BufferInfo(gfx.BufferUsageBit.VERTEX | gfx.BufferUsageBit.TRANSFER_DST, gfx.MemoryUsageBit.HOST | gfx.MemoryUsageBit.DEVICE, vertecies.byteLength, ModelStrip));
            var indexBuffer = buffer ? buffer.indice : device.createBuffer(new gfx.BufferInfo(gfx.BufferUsageBit.INDEX | gfx.BufferUsageBit.TRANSFER_DST, gfx.MemoryUsageBit.DEVICE, indices.byteLength, Int32Array.BYTES_PER_ELEMENT));

            if (buffer) {
              vertexBuffer.resize(vertecies.byteLength);
              indexBuffer.resize(indices.byteLength);
            }

            g_models[key][frame] = {
              vertex: vertexBuffer,
              indice: indexBuffer,
              ia: new gfx.IndirectBuffer([new gfx.DrawInfo(vertexBuffer.count, 0, indexBuffer.count, 0)])
            }; //this.sum_count += (vertecies.byteLength + indices.byteLength)/1024/1024;
            //console.log(key, frame, (this.sum_count).toFixed(2), " mb");
          }

          g_models[key][frame].vertex.update(vertecies);
          g_models[key][frame].indice.update(indices);
        }

        static removeModel(key) {
          if (null == g_models[key]) {
            return;
          } // 清除 buffer 对象


          g_models[key].forEach(frame => {
            frame.vertex.destroy();
            frame.indice.destroy();
          });
          delete g_models[key];
          EFKModel.m_model_meshs[key].forEach(mesh => {
            // 清除 mesh 对象
            EFKModel.m_meshs[mesh].destroy();
            delete EFKModel.m_meshs[mesh]; // 清除 model 对象            

            var models = EFKModel.m_model_cache[mesh];
            models.forEach(m => {
              EFKModel.m_models[m].destroy();
              delete EFKModel.m_models[m];
            });
          });
          delete EFKModel.m_model_meshs[key];
        }

        static drawModel(id, frame, material, typeid) {
          // return;
          var meshs = EFKModel.m_model_meshs[id] = EFKModel.m_model_meshs[id] || [];
          var mesh = meshs[frame] !== undefined ? meshs[frame] : -1;
          var buffer = g_models[id][frame];
          if (null == buffer) debugger;
          var subMesh = null;

          if (mesh >= 0) {
            subMesh = EFKModel.m_meshs[mesh];
          } else {
            var attrs = [];
            material.passes[0].shaderInfo.attributes.forEach(attr => {
              attrs.push(new gfx.Attribute(attr.name, attr.format, attr.isNormalized, attr.stream, attr.isInstanced, attr.location));
            });
            subMesh = new RenderingSubMesh([buffer.vertex], ModelVertexEx, gfx.PrimitiveMode.TRIANGLE_LIST, buffer.indice);
            mesh = EFKModel.m_meshs.length;
            EFKModel.m_meshs.push(subMesh);
            EFKModel.m_model_meshs[id].push(mesh);
          }

          return EFKModel.checkModel(mesh, subMesh, material, buffer.ia.drawInfos[0]);
        }

        static checkModel(mesh_id, mesh_obj, material, info) {
          var model = null;
          var cache = EFKModel.m_model_cache[mesh_id] = EFKModel.m_model_cache[mesh_id] || [];

          for (var ii = 0; ii < cache.length; ++ii) {
            var mid = cache[ii];

            if (EFKModel.m_model_used[mid]) {
              continue;
            }

            model = EFKModel.m_models[mid];
            EFKModel.m_model_used[mid] = true;
            break;
          }

          if (null == model) {
            model = director.root.createModel(renderer.scene.Model);
            model.initSubModel(0, mesh_obj, material);
            var _mid = EFKModel.m_models.length;
            EFKModel.m_models.push(model);
            EFKModel.m_model_cache[mesh_id] = EFKModel.m_model_cache[mesh_id] || [];
            EFKModel.m_model_cache[mesh_id].push(_mid);
            EFKModel.m_model_used[_mid] = true;
          } else {
            model.setSubModelMaterial(0, material);
          }

          model.subModels[0].inputAssembler.drawInfo = info; // model.priority = EFKModel.m_priority++;

          return model;
        }

        static reset() {
          EFKModel.m_typeid_used = [];
          EFKModel.m_model_used = [];
          EFKModel.m_priority = 0;
        }

      });

      EFKModel.m_meshs = [];
      EFKModel.m_typeid_meshs = {};
      EFKModel.m_typeid_used = {};
      EFKModel.m_model_meshs = {};
      EFKModel.m_model_cache = {};
      EFKModel.m_models = [];
      EFKModel.m_model_used = {};
      // priority 决定渲染顺序
      EFKModel.m_priority = 0;
      EFKModel.m_buffers = {};
      EFKModel.sum_count = 0;

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=60bfa6c933913e4ab42b64747fb56a307826a6df.js.map