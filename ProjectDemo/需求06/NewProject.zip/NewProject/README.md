# effekseer-demo
 a demo to reproduce bugs for effekseer extension in cocos creator

在播放某些特效時（目前已知 Meteorite + Change_Light)
iOS 15 會當機並刷出錯誤訊息
iOS 17 則正常

步驟：
1. Creator build ios
2. ios build to device
3. 點擊【changeScene】
4. 點擊按鈕 【efk:Meteorite】 ，接著點擊按鈕 【efk: LIGHT】

錯誤訊息:
2024-02-25 10:08:01.666560+0800 NewProject_6-mobile[36619:1433541] Execution of the command buffer was aborted due to an error during execution. Ignored (for causing prior/excessive GPU errors) (00000004:kIOGPUCommandBufferCallbackErrorSubmissionsIgnored)

