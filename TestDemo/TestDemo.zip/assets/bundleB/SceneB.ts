import * as cc from 'cc';
import { EFKComponent } from '../../extensions/effekseer/assets/framework/efk_component';
import { director } from 'cc';
import { AppStart } from '../AppStart';
import { find } from 'cc';
const { ccclass, property } = cc._decorator;


const bundleName = "bundleC"
const sceneName = "sceneC"


@ccclass('SceneB')
export class SceneB extends cc.Component
{
    @property({ type: cc.Node, tooltip: "容器" })
    private efkNode: cc.Node = null;

    @property({ type: cc.Prefab, tooltip: "efk需要用到的設定" })
    private efkConfigPrefab: cc.Prefab = null;

    @property({ type: [cc.Prefab] })
    private effects: cc.Prefab[] = [];

    @property({ type: cc.Node, tooltip: "容器" })
    private hitNode: cc.Node = null;
    @property({ type: [cc.Prefab] })
    private hitEffects: cc.Prefab[] = [];


    private efkPools = new Map<number, cc.NodePool>();

    _appStart: AppStart = null;

    protected onLoad(): void {
        this._appStart = find("AppStart").getComponent(AppStart);
    }


    start()
    {
        const efkConfig = cc.instantiate(this.efkConfigPrefab)
        efkConfig.setParent(this.node)
    }

    onDestroy()
    {
        this.efkPools.forEach((pool, key) =>
        {
            while (pool.size() > 0)
            {
                pool.get().destroy()
            }
        })
        cc.Tween.stopAll()
    }



    private playMeteorite()
    {
        let node = this._getEfkEffect(2);
        if (node)
        {
            cc.tween(this.node)
                .delay(4)
                .call(() =>
                {
                    console.log("@@@destroy efk: ", 2)

                    node.destroy()
                })
                .start()

            // let efkNode = cc.find('efk', node);
            // if (efkNode)
            // {
            //     let efk = efkNode.getComponent(EFKComponent);
            //     if (efk)
            //     {
            //         efkNode.active = true;
            //         efk.play();
            //     }
            // }
        }
    }


    //播放moveSmoke(0) / ChangeLight(1)
    playEfks(input: any, efkno: string)
    {
        const no = parseInt(efkno)
        console.log("play efk: ", efkno)
        if (no == 2)
        {
            this.playMeteorite()
            return;
        }
        let node = this._getEfkEffect(no);
        node.active = true;
        if (node)
        {
            let efk = node.getComponent(EFKComponent);
            if (efk)
            {
                node.active = true;
                efk.play();
            }

            cc.tween(this.node)
                .delay(2)
                .call(() =>
                {
                    this._setEfkEffect(no, node);
                })
                .start()
        }
    }

    private _getEfkEffect(no: number)
    {
        if (this.efkPools.has(no) === false)
        {
            this.efkPools.set(no, new cc.NodePool());
        }

        let pool = this.efkPools.get(no)
        let node = pool.get() || cc.instantiate(this.effects[no]);

        node.setPosition(0, 0, 0);
        node.parent = this.efkNode
        return node;
    }

    private _setEfkEffect(no: number, node: cc.Node)
    {
        if (this.efkPools.has(no) === false)
        {
            node.destroy();
            return;
        }

        let pool = this.efkPools.get(no);
        if (pool.size() >= 5)
        {
            console.log("@@@destroy efk: ", no)
            node.destroy();
            return;
        }

        node.active = false;

        cc.Tween.stopAllByTarget(node);
        pool.put(node);
    }

    bulletHitEffect(input: any, no: string)
    {
        console.log("bullets: ", no)

        let node = cc.instantiate(this.hitEffects[no])
        if (node)
        {
            node.setPosition(0, 0, 0);
            node.parent = this.hitNode;

            {
                cc.tween(node)
                    .delay(3)
                    .call(() => node.destroy())
                    .start();
            }
        }
    }

    loadSceneLogin () {
        director.loadScene("login");
    }

    loadSceneA () {
        this._appStart.loadSceneByRemoteBundle("bundleA", "sceneA");
    }

    loadSceneB () {
        director.loadScene("sceneB");
    }

}
