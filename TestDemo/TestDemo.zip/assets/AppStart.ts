import { EditBox, Settings, Label, AudioSource, Enum, assetManager, director, game } from 'cc';
import { ZipLoader } from 'cc';

import { settings, zipLoader } from 'cc';
// import ZipLoader from './lib/ZipLoader';

const BundlesName = Enum({
    INTERNAL: "internal",
    MAIN: "main",
    BUNDLE_A: "bundleA",
    BUNDLE_B: "bundleB"
});
var loadFinishZips: string[] = [];
window["sceneAssetsMap"] = new Map<string, any>();

import { _decorator, Button, Component, Node, SkeletalAnimation } from 'cc';
import { DEV, HTML5, PREVIEW } from 'cc/env';

const { ccclass, property } = _decorator;

@ccclass('AppStart')
export class AppStart extends Component {

    @property(AudioSource)
    bgm: AudioSource = null;

    @property(EditBox)
    editbox: EditBox = null;

    @property(Label)
    acount: Label = null;

    remoteUrl: string = "";

    onLoad () {
        window["AppStart"] = this;

        this.remoteUrl = settings.querySettings(Settings.Category.ASSETS, "server");
        director.addPersistRootNode(this.node);
    }

    loadSceneLogin () {
        director.loadScene("login");
    }

    loadSceneA () {
        this.loadSceneByRemoteBundle(BundlesName.BUNDLE_A, "sceneA");
    }

    loadSceneB () {
        this.loadSceneByRemoteBundle(BundlesName.BUNDLE_B, "sceneB");
    }

    playBGM () {
        this.bgm.play();
    }

    editboxInputing (editText: string) {
        this.acount.string = editText;
    }

    async loadSceneByRemoteBundle(bundleName: string, sceneName: string)
    {
        if (!DEV && !PREVIEW && HTML5) {
            if (this.remoteUrl === "")
            {
                console.error("remote server url is empty, can not load remote zip bundles");
                return;
            }
    
            if (ZipLoader._ins.loadFinishZips.indexOf(bundleName) < 0)
            {
                const loadZip = ZipLoader._ins.loadZip(`${this.remoteUrl}remote/${bundleName}`);
    
                ZipLoader._ins.loadFinishZips.push(bundleName);
                await Promise.all([loadZip]);
            }
        }

        console.log("start bundle");
        var startTime = performance.now();
        assetManager.loadBundle(bundleName, (err, bundle) =>
        {
            if (err)
            {
                console.log("error")
                return
            }
            console.log("load bundle success");

            // bundle.preloadScene(sceneName, function (finish, total, item) {
            //     console.log(`preload scene progress: ${finish / total * 100}%`);
            // }, function () {
            //     console.log(`preload scene finish`);
            // });

            bundle.loadScene(sceneName, function (finish, total, item) {
                console.log(`load scene progress: ${finish / total * 100}%`);
            }, function (err, scene)
            {
                director.runScene(scene, ()=>{
                    var endTime = performance.now();
                    console.log(`launched scene, all used time: ${endTime - startTime} ms`);
                });
            });
        });
    }

    releaseBundle () {

    }

    protected onDestroy(): void {
        console.error("onDestroy");
    }
}