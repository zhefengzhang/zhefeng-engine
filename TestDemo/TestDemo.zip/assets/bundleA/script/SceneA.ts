import { EditBox } from 'cc';
import { Label, Enum } from 'cc';
import { AudioSource } from 'cc';
import { _decorator, Button, Component, Node, SkeletalAnimation } from 'cc';
import { AppStart } from '../../AppStart';
import { find } from 'cc';
import { director } from 'cc';
const BundlesName = Enum({
    START_SCENE: "start-scene",
    BUNDLE_A: "bundleA",
    BUNDLE_B: "bundleB"
});
const { ccclass, property } = _decorator;

@ccclass('SceneA')
export class SceneA extends Component {

    @property(Node)
    testNode1: Node = null;

    @property(SkeletalAnimation)
    testAnima1: SkeletalAnimation = null;

    @property(Node)
    testNode2: Node = null;

    @property(SkeletalAnimation)
    testAnima2: SkeletalAnimation = null;

    _appStart: AppStart = null;

    protected onLoad(): void {
        this._appStart = find("AppStart").getComponent(AppStart);
    }

    switchShowNode (btn: Button, customData: string) {
        switch (customData) {
            case '1':
                this.testNode1.active = true;
                this.testAnima1.play();
                this.testNode2.active = false;
                this.testAnima2.stop();
                break;
            case '2':
                this.testNode1.active = false;
                this.testAnima1.stop();
                this.testNode2.active = true;
                this.testAnima2.play();
                break;
        }
    }

    playBGM () {
        this._appStart && this._appStart.playBGM();
    }

    loadSceneLogin () {
        director.loadScene("login");
    }

    loadSceneA () {
        director.loadScene(BundlesName.BUNDLE_A);
    }

    loadSceneB () {
        this._appStart.loadSceneByRemoteBundle(BundlesName.BUNDLE_B, "sceneB");
    }
}


