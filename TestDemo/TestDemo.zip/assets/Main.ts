import { Button } from 'cc';
import { _decorator, Component, Node } from 'cc';
import { AppStart } from './AppStart';
import { EventHandheld } from 'cc';
import { EventHandler } from 'cc';
const { ccclass, property } = _decorator;

@ccclass('Main')
export class Main extends Component {

    @property(Button)
    loginBtn: Button = null;

    @property(Button)
    sceneABtn: Button = null;

    @property(Button)
    sceneBBtn: Button = null;

    @property(Button)
    playBGMBtn: Button = null;

    protected onLoad(): void {
        const _appStart: AppStart = window["AppStart"];
        if (_appStart) {
            this.loginBtn.node.on(Node.EventType.TOUCH_END, _appStart.loadSceneLogin.bind(_appStart));
            this.sceneABtn.node.on(Node.EventType.TOUCH_END, _appStart.loadSceneA.bind(_appStart));
            this.sceneBBtn.node.on(Node.EventType.TOUCH_END, _appStart.loadSceneB.bind(_appStart));
            this.playBGMBtn.node.on(Node.EventType.TOUCH_END, _appStart.playBGM.bind(_appStart));
        }
        
    }

    update(deltaTime: number) {
        
    }
}


