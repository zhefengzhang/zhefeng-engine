declare module 'vue/dist/vue.js' {
    import Vue from 'vue';
    export default Vue;
    export * from 'vue';
}
