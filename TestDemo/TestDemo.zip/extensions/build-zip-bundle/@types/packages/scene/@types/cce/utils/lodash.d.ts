export declare function get(object: any, path: any, value?: any): any;
export declare function set(object: any, path: any, value: any): any;
//# sourceMappingURL=lodash.d.ts.map