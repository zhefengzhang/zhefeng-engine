import { Node, Component } from 'cc';
export declare class TestComponent extends Component {
    test: Node | null;
    update(deltaTime: number): void;
}
export declare function test(): void;
//# sourceMappingURL=test.d.ts.map