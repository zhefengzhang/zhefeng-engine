import Utils from './3d';
export default Utils;
//# sourceMappingURL=index.d.ts.map