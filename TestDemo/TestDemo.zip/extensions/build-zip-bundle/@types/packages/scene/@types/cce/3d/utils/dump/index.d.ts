import DumpUtil from '../../../export/dump';
export default DumpUtil;
//# sourceMappingURL=index.d.ts.map