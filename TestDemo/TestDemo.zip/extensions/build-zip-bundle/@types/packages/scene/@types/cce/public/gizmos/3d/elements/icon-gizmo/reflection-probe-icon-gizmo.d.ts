import IconGizmoBase from './icon-gizmo-base';
declare class ReflectionProbeIconGizmo extends IconGizmoBase {
    createController(): void;
    updateController(): void;
}
export default ReflectionProbeIconGizmo;
//# sourceMappingURL=reflection-probe-icon-gizmo.d.ts.map