import { Asset } from 'cc';
export declare function serializeSafe(asset: Asset, options?: any): string | object;
export declare function serialize(asset: any, options?: any): string | object;
//# sourceMappingURL=index.d.ts.map