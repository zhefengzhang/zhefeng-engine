declare function check(): void;
export { check };
//# sourceMappingURL=preview.d.ts.map