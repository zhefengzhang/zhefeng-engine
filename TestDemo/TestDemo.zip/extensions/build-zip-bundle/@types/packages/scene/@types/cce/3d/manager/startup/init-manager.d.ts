export {};
//# sourceMappingURL=init-manager.d.ts.map