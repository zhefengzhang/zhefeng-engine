import type GizmoBase from './gizmo-base';
/**
 * 检查gizmo的类型是否应该显示
 * @param ctor
 * @returns
 */
export declare function gizmoVisibilityCheck(ctor: GizmoBase | typeof GizmoBase): boolean;
//# sourceMappingURL=gizmo-utils.d.ts.map