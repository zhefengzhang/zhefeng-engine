import { Node } from 'cc';
declare const _default: (node: Node) => any;
export default _default;
//# sourceMappingURL=get-component-function-of-node.d.ts.map