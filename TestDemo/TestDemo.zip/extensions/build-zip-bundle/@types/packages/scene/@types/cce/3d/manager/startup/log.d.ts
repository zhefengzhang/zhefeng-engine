declare class Logger {
    changePrefix(str: string): void;
    setLevel(level: number): void;
    init(): void;
}
declare const _default: Logger;
export default _default;
//# sourceMappingURL=log.d.ts.map