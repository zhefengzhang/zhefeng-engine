declare module 'vue/dist/vue.js' {
    import Vue from 'vue';
    export * from 'vue';
    export default Vue;
}
