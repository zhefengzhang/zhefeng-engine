import { BuildPlugin } from '../@types';

export const load: BuildPlugin.load = function() {
    console.debug(`${PACKAGE_NAME} load`);
};

export const unload: BuildPlugin.load = function() {
    console.debug(`${PACKAGE_NAME} unload`);
};

const PACKAGE_NAME = 'build-zip-bundle';

export const configs: BuildPlugin.Configs = {
    'web-mobile': {
        options: {
            loadZipBundle: {
                label: 'LoadZipBundle',
                description: 'The build tool will package the remote bundles in your project into zip files. You need to fill in the remoteServerUrl for loading these resources, and then start the build process. After the build is completed, you need to upload the remote folder to the remoteServer.',
                default: false,
                render: {
                    ui: 'ui-checkbox',
                }
            }
        },
        hooks: './hooks',
    },
    'web-desktop': {
        options: {
            loadZipBundle: {
                label: 'LoadZipBundle',
                description: 'The build tool will package the remote bundles in your project into zip files. You need to fill in the remoteServerUrl for loading these resources, and then start the build process. After the build is completed, you need to upload the remote folder to the remoteServer.',
                default: false,
                render: {
                    ui: 'ui-checkbox',
                }
            }
        },
        hooks: './hooks',
    },
};
