import * as fs from "fs";
import JSZip from "jszip";
import JSZIP from "jszip";
var fileBeforeZipPath : string[] = [];

//读取目录及文件
function readDir(zip: JSZip, nowPath: string) {
    const files = fs.readdirSync(nowPath);
    files.forEach(function (fileName, index) {//遍历检测目录中的文件
        // console.log(fileName, index);//打印当前读取的文件名
        const filePath = nowPath + "/" + fileName;
        const file = fs.statSync(filePath);//获取一个文件的属性
        if (file.isDirectory()) {//如果是目录的话，继续查询
            const dirlist = zip.folder(fileName)!;//压缩对象中生成该目录
            readDir(dirlist, filePath);//重新检索目录文件
        } else {
            // 排除图片、字体、bundle 配置文件等资源，因它们都不是通过引擎的 downloadFile 方法加载的
            if (fileName.indexOf("index.") >= 0 || fileName.indexOf("config.") >= 0 || fileName.endsWith(".png") || fileName.endsWith(".jpg") || fileName.endsWith(".ttf")) {
                return;
            }
            zip.file(fileName, fs.readFileSync(filePath));//压缩目录添加文件
            
            fileBeforeZipPath.push(filePath);
        }
    });
}

//开始压缩文件
export function zipDir(name: string, dir: string, dist: string) {
    return new Promise<void>((resolve, reject) => {
        const zip = new JSZIP();
        readDir(zip, dir);
        zip.generateAsync({//设置压缩格式，开始打包
            type: "nodebuffer",//nodejs用
            compression: "DEFLATE",//压缩算法
            compressionOptions: {//压缩级别
                level: 9
            }
        }).then(function (content) {
            fs.writeFileSync(`${dist}/${name}.zip`, content, "utf-8");
            resolve();
        });
    });
}

export function deleteBeforeZipFile() {
    const fileCount = fileBeforeZipPath.length;
    for (let i = 0; i < fileCount; i++) {
        var path = fileBeforeZipPath.pop();
        fs.unlinkSync(path);
    }
}