import { BuildHook } from '../@types';
import * as fs from "fs";
import { deleteBeforeZipFile, zipDir } from './zip';

const PACKAGE_NAME = 'build-zip-bundle';

export const throwError: BuildHook.throwError = true;

export const load: BuildHook.load = async function() {
    console.log(PACKAGE_NAME,load);
};

// export const onBeforeBuild: BuildHook.onBeforeBuild = async function(options) {
//     // Todo some thing
//     console.log(PACKAGE_NAME,'onBeforeBuild');
// };

// export const onBeforeCompressSettings: BuildHook.onBeforeCompressSettings = async function(options, result) {
//     // Todo some thing
//     console.log(PACKAGE_NAME,'onBeforeCompressSettings');
// };

// export const onAfterCompressSettings: BuildHook.onAfterCompressSettings = async function(options, result) {
//     // Todo some thing
//     console.log(PACKAGE_NAME, 'onAfterCompressSettings');
// };

export const onAfterBuild: BuildHook.onAfterBuild = async function(options, result) {
    if (options.platform !== "web-mobile" && options.platform !== "web-desktop" || !options.packages[PACKAGE_NAME].loadZipBundle) return;
    console.log(`Start make bundle zip files for ${PACKAGE_NAME}`);
    if (fs.existsSync(result.dest + "/remote")) {
        await Promise.all(
            fs.readdirSync(result.dest + "/remote/").map(async (dirName) => {
                return zipDir(dirName, result.dest + "/remote/" + dirName, result.dest + "/remote/");
            })
        ).then(()=>{
            deleteBeforeZipFile();
        })
    }
    
};

// export const unload: BuildHook.unload = async function() {
//     console.log(PACKAGE_NAME, 'unload');
// };