如果文件夹内没有包含 node_modules 文件夹，则运行以下命令安装依赖
```bash
npm install
```
运行以下命令编译 typeScript 代码
```bash
npm run build
```