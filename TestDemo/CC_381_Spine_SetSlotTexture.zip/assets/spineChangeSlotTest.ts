import { _decorator, Component, EventTouch, Node, resources, sp, SpriteAtlas, SpriteFrame, Texture2D, Toggle } from 'cc';
const { ccclass, property } = _decorator;

@ccclass('spineChangeSlotTest')
export class spineChangeSlotTest extends Component {

    @property(sp.Skeleton)
    testSkeleton: sp.Skeleton = null;

    @property(sp.Skeleton)
    testAttachmentSkeleton: sp.Skeleton = null;

    @property(Texture2D)
    miniTextureA: Texture2D = null;

    @property(Texture2D)
    miniTextureB: Texture2D = null;

    @property(SpriteFrame)
    autoAtlasSPFA: SpriteFrame = null;

    @property(SpriteFrame)
    autoAtlasSPFB: SpriteFrame = null;

    @property(SpriteAtlas)
    testPlist: SpriteAtlas = null;

    _usePropertyAsset: boolean = true;

    changeSlotTextureByMiniTexture(e: EventTouch, eventCustomData: string) {
        var slotName = '';
        var texture = null;
        switch (eventCustomData) {
            case "Text_1":
                slotName = "HP_TEXT1";
                if (this._usePropertyAsset) {
                    texture = this.miniTextureA;
                } else {
                    resources.load("images/FG_Compliment_Text_1/texture", Texture2D, (error, textureRes: Texture2D)=>{
                        if (error) {
                            console.error(error);
                        } else {
                            texture = textureRes;
                            this.testSkeleton.setSlotTexture(slotName, texture, true);
                        }
                    })
                }
                
                break;
            case "Text_2":
                slotName = "HP_TEXT2";
                if (this._usePropertyAsset) {
                    texture = this.miniTextureB;
                } else {
                    resources.load("images/FG_Compliment_Text_2/texture", Texture2D, (error, textureRes: Texture2D)=>{
                        if (error) {
                            console.error(error);
                        } else {
                            texture = textureRes;
                            this.testSkeleton.setSlotTexture(slotName, texture, true);
                        }
                    })
                }

                break;
        }
        texture && this.testSkeleton.setSlotTexture(slotName, texture, true);
    }

    changeSlotTextureByAtlasTexture(e: EventTouch, eventCustomData: string) {
        var spriteFrame: SpriteFrame = null;
        var slotName = '';
        if (!this._usePropertyAsset) {
            resources.load("plist/PlistAtlas", SpriteAtlas, (error, atlasRes: SpriteAtlas)=>{
                if (error) {
                    console.error(error);
                } else {
                    switch (eventCustomData) {
                        case "Text_1":
                            spriteFrame = atlasRes.getSpriteFrame("FG_Compliment_Text_1");
                            slotName = "HP_TEXT1";
                            break;
                        case "Text_2":
                            spriteFrame = atlasRes.getSpriteFrame("FG_Compliment_Text_2");
                            slotName = "HP_TEXT2";
                            break;
                    }
                    spriteFrame && this.testSkeleton.setSlotTexture(slotName, spriteFrame, true);
                }
            })
            return;
        }
        switch (eventCustomData) {
            case "Text_1":
                spriteFrame = this.testPlist.getSpriteFrame("FG_Compliment_Text_1");
                slotName = "HP_TEXT1";
                break;
            case "Text_2":
                spriteFrame = this.testPlist.getSpriteFrame("FG_Compliment_Text_2");
                slotName = "HP_TEXT2";
                break;
        }
        spriteFrame && this.testSkeleton.setSlotTexture(slotName, spriteFrame, true);
    }

    changeSlotTextureByAutoAtlas(e: EventTouch, eventCustomData: string) {
        var slotName = '';
        var spriteFrame: SpriteFrame  = null;
        switch (eventCustomData) {
            case "Text_1":
                slotName = "HP_TEXT1";
                spriteFrame = this.autoAtlasSPFA;
                break;
            case "Text_2":
                slotName = "HP_TEXT2";
                spriteFrame = this.autoAtlasSPFB;
                break;
        }
        spriteFrame && this.testSkeleton.setSlotTexture(slotName, spriteFrame, true);
    }

    changeAttachmentTexture() {
        var slotName = "FG_Compliment/_Misc";
        this.testSkeleton.setSlotTexture(slotName, this.miniTextureA, true);
        this.testAttachmentSkeleton.setSlotTexture(slotName, this.miniTextureA, true);
    }

    onClickedChangeToggle(e: Toggle) {
        if (e.node.name === 'Toggle1' && e.isChecked) {
            this._usePropertyAsset = true;
        } else if (e.node.name === 'Toggle2' && e.isChecked) {
            this._usePropertyAsset = false;
        }
    }

    update(deltaTime: number) {
        
    }
}


